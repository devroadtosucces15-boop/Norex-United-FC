#!/usr/bin/python3
"""Local control surface. Only two fixed system units and loopback backends."""
import json,os,threading,time,secrets,subprocess,urllib.request,urllib.error
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
ROOT=Path('/mnt/DEV_WORK/projects/norex-controller-lab-backbone')
STATE=Path('/var/lib/norex-master/state.json')
UNITS={'controller':'norex-controller-managed.service','network':'norex-network-managed.service'}
PORTS={'controller':8791,'network':8792}
DEFAULT={'prefer_local':False,'preferred_region':'southwest','latency_watch':False,'automatic_qos':False,'auto_rollback':True,'idle_capture_stop':False,'download_mbps':0,'upload_mbps':0,'probe_target':'1.1.1.1','regional_route':'direct','play_state':'auto'}
lock=threading.RLock();token=secrets.token_urlsafe(32)
data={'cache':{},'network_saved':None,'errors':{},'revision':0}
def load_state():
    if STATE.exists():data.update(json.loads(STATE.read_text()))
def save():
    STATE.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    tmp=STATE.with_suffix('.tmp');tmp.write_text(json.dumps(data));tmp.chmod(0o600);tmp.replace(STATE)
def unit(name,action):
    result=subprocess.run(['/usr/bin/systemctl',action,UNITS[name]],capture_output=True,text=True,timeout=45)
    if result.returncode:raise ValueError(result.stderr.strip() or result.stdout.strip())
def active(name):
    return subprocess.run(['/usr/bin/systemctl','is-active','--quiet',UNITS[name]],capture_output=True).returncode==0
def call(name,path,body=None):
    host=f'127.0.0.1:{PORTS[name]}'
    headers={'Origin':'http://'+host,'Content-Type':'application/json'}
    if name=='network' and body is not None:
        import re
        with urllib.request.urlopen('http://'+host+'/network',timeout=5) as r:page=r.read().decode()
        headers['X-CSRF-Token']=re.search(r'name="csrf-token" content="([^"]+)"',page).group(1)
    req=urllib.request.Request('http://'+host+path,None if body is None else json.dumps(body).encode(),headers)
    try:
        with urllib.request.urlopen(req,timeout=35) as r:return r.read(),r.status
    except urllib.error.HTTPError as e:return e.read(),e.code

def ready(name):
    path='/api/center' if name=='controller' else '/api/automation'
    until=time.monotonic()+15
    while time.monotonic()<until:
        try:
            body,code=call(name,path)
            if code==200:return
        except OSError:pass
        time.sleep(.2)
    raise ValueError('Service did not become ready. Check the local service log.')

VIEWS={'controller':['/api/center','/api/state','/api/v2/skills','/api/v2/helpers','/api/v2/fc27','/api/v2/effective','/api/telemetry'], 'network':['/api/live','/api/automation','/api/events','/api/experience','/api/storage','/api/gateway/api/status','/api/gateway/api/history','/api/gateway/api/jobs','/api/gateway/api/captures']}
def cache_views(name):
    for path in VIEWS[name]:
        try:
            body,code=call(name,path)
            if code==200:data['cache'][path]=json.loads(body)
        except (OSError,ValueError):pass
    save()
def snapshot():
    with lock:
        if not active('controller') and data['cache'].get('/api/state',{}).get('master_enabled'):
            data['cache'].update(data.get('off_cache',{}));mark_off('controller')
            data['errors']['controller']='Controller service stopped. Turn ON to reconnect.';save()
        return {'controller':active('controller'),'network':active('network'),'errors':data['errors'],'revision':data['revision']}

def power(name,enabled):
    if type(enabled) is not bool:raise ValueError('Expected true or false')
    with lock:
        if enabled and active(name):return snapshot()
        data['errors'].pop(name,None)
        try:
            if enabled:
                unit(name,'start');ready(name)
                cache_views(name)
                if name=='controller':data['off_cache']={p:data['cache'][p] for p in VIEWS[name] if p in data['cache']};save()
                if name=='controller':
                    # Wait for physical discovery without emitting input.
                    until=time.monotonic()+4
                    while time.monotonic()<until:
                        state=json.loads(call(name,'/api/state')[0])
                        if state['status']=='Connected':break
                        time.sleep(.1)
                    body,code=call(name,'/api/action',{'action':'master_power','enabled':True})
                    if code!=200:raise ValueError(json.loads(body).get('error','Controller could not start'))
                elif data['network_saved'] is not None:
                    body,code=call(name,'/api/automation',data['network_saved'])
                    if code!=200:raise ValueError(json.loads(body).get('error','Saved network settings could not be applied'))
                cache_views(name)
            else:
                if active(name):
                    if name=='controller':
                        body,code=call(name,'/api/action',{'action':'master_power','enabled':False})
                        if code!=200:raise ValueError(json.loads(body).get('error','Cleanup failed'))
                    else:
                        data['network_saved']=json.loads(call(name,'/api/automation')[0])['settings'];save()
                        body,code=call(name,'/api/automation',DEFAULT)
                        if code!=200:raise ValueError('Could not restore default network settings')
                    cache_views(name)
                unit(name,'stop')
                mark_off(name)
        except Exception as e:
            unit(name,'stop');mark_off(name)
            data['errors'][name]=str(e);save();raise ValueError(str(e))
        data['revision']+=1;save();return snapshot()
def mark_off(name):
    if name=='controller':
        for path in ('/api/center','/api/state'):
            c=data['cache'].get(path)
            if not c:continue
            s=c['state'] if path=='/api/center' else c
            s.update(master_enabled=False,custom_enabled=False,chiaki_running=False,status='OFF',revision=s.get('revision',0)+1)
            if path=='/api/center':c['effective']['output']['active']=False
    else:
        c=data['cache'].get('/api/automation')
        if c:c.update(settings=dict(DEFAULT),owned_queue=None,owned_route=None,queue_phase='off',route_phase='direct',samples=[])
        c=data['cache'].get('/api/live')
        if c:c.update(endpoints=[],collector='off',capture=False,ps5_online=False,rate=None,error='Network Console is OFF')
        experience=data['cache'].get('/api/experience')
        if experience:
            experience.update(active=None,error='Network Console is OFF',diagnoses=[])
            experience['controller']=data['cache'].get('/api/automation',experience['controller'])
            experience['live']=data['cache'].get('/api/live',experience['live'])
            for row in experience.get('readiness',[]):row.update(ready=False,detail='Turn Network Console ON to run current checks.')
        c=data['cache'].get('/api/gateway/api/status')
        if c:c.update(collector='off',capture=False,online=False,flows=[])
    save()
def network_path(path):
    return path.startswith(('/api/gateway/','/gateway/capture/')) or path in VIEWS['network'] or path in ('/api/play','/api/preset')
ASSETS={}
for folder,prefix in [('ui','/ui/'),('network','/')]:
    for p in (ROOT/folder).iterdir():
        if p.is_file():ASSETS[prefix+p.name]=p
ASSETS.update({'/':ROOT/'home.html','/lab':ROOT/'console.html','/network':ROOT/'network/livebox.html','/help':ROOT/'help.html','/master.js':ROOT/'ui/master.js'})
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def reply(self,body,code=200,kind='application/json'):
        if not isinstance(body,bytes):body=json.dumps(body).encode()
        self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def allowed(self):
        host=self.headers.get('Host','')
        return host in ('127.0.0.1:8790','localhost:8790') and self.headers.get('Origin','http://'+host)=='http://'+host
    def do_GET(self):
        if not self.allowed():return self.reply({'error':'Local origin required'},403)
        path=self.path.split('?',1)[0]
        if path=='/api/master':return self.reply(snapshot())
        if path in ASSETS:
            p=ASSETS[path];body=p.read_bytes()
            if path in ('/','/lab','/network','/help'):
                body=body.replace(b'__TOKEN__',token.encode()).replace(b'</head>',b'<script src="/master.js" defer></script></head>')
            import mimetypes
            return self.reply(body,kind=mimetypes.guess_type(str(p))[0] or 'application/octet-stream')
        name='network' if network_path(path) else 'controller'
        with lock:
            if active(name):
                try:
                    body,code=call(name,self.path)
                    if code==200 and path.startswith('/api/'):
                        data['cache'][self.path]=json.loads(body)
                    return self.reply(body,code)
                except OSError:pass
            if self.path in data['cache']:return self.reply(data['cache'][self.path])
        return self.reply({'error':f'Turn {name} ON to use this view'},409)
    def do_POST(self):
        if not self.allowed():return self.reply({'error':'Local origin required'},403)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=262144:raise ValueError('Invalid request length')
            body=json.loads(self.rfile.read(size))
            if not isinstance(body,dict):raise ValueError('Expected an object')
            with lock:
                if self.path=='/api/master':
                    if self.headers.get('X-CSRF-Token')!=token:raise ValueError('Reload this page to reconnect')
                    name=body.get('tool')
                    if name not in UNITS:raise ValueError('Unknown tool')
                    return self.reply(power(name,body.get('enabled')))
                if self.path=='/api/action' and body.get('action') in ('master_power','custom_power','output_start','output_stop','emergency_stop'):
                    enabled=body.get('enabled') if body['action'] in ('master_power','custom_power') else body['action']=='output_start'
                    power('controller',enabled)
                    return self.reply(data['cache'].get('/api/state',{'master_enabled':enabled}))
                name='network' if network_path(self.path) or self.path=='/api/automation' else 'controller'
                if name=='network' and self.headers.get('X-CSRF-Token')!=token:raise ValueError('Reload this page to reconnect')
                if not active(name):raise ValueError('Turn this tool ON before changing settings')
                response,code=call(name,self.path,body)
                return self.reply(response,code)
        except (ValueError,OSError,TimeoutError) as e:return self.reply({'error':str(e)},400)

def watch():
    while True:
        time.sleep(2)
        with lock:
            if active('controller'):
                try:
                    state=json.loads(call('controller','/api/state')[0])
                    if not state['master_enabled'] or not state['chiaki_running']:
                        cache_views('controller');unit('controller','stop');mark_off('controller')
                        data['errors']['controller']=state.get('output_error') or state.get('error') or 'Controller disconnected or Remote Play closed. Turn ON to retry.';save()
                except OSError:pass
if __name__=='__main__':
    # Control page restarts do not stop healthy workers; boot starts with workers OFF.
    load_state()
    for name in UNITS:
        if not active(name):mark_off(name)
    threading.Thread(target=watch,daemon=True).start()
    ThreadingHTTPServer(('127.0.0.1',8790),Handler).serve_forever()
