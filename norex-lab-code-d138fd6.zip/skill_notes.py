"""Review marks for each move: 'correct' or 'check', with an optional short note. Local notes only."""
import json,time
from profile_store import write_atomic

STATUSES=('correct','check')

def _path(data):return data/'skill-notes.json'

def read(data):
    p=_path(data)
    if not p.exists():return {'notes':{}}
    row=json.loads(p.read_text())
    if not isinstance(row,dict) or not isinstance(row.get('notes'),dict):raise ValueError('Invalid skill notes file')
    return {'notes':row['notes']}

def save(data,name,status,note=''):
    from skills import CATALOG
    if name not in CATALOG:raise ValueError('Unknown move')
    if status is not None and status not in STATUSES:raise ValueError('Status must be correct or check')
    note=str(note or '').strip()[:200]
    notes=read(data)['notes']
    if status is None and not note:notes.pop(name,None)
    else:notes[name]={'status':status,'note':note,'at':time.strftime('%Y-%m-%dT%H:%M:%S%z')}
    write_atomic(_path(data),{'notes':notes})
    return {'notes':notes}
