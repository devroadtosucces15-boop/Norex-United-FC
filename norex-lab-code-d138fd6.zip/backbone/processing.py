"""Authoritative processing chain; adapters propose, resolver owns final frame.

Legacy engines remain implementation adapters to preserve tested behavior. No
stage writes a device. Runtime alone records/emits the returned final frame.
"""
import math
from copy import deepcopy
from pipeline import normalized, transform, BUTTONS, ControllerFrame
from .engine import BackboneEngine
from .resolver import ConflictResolver, Intent, PRIORITY, frame_intents

class ProcessingPipeline:
    def __init__(self):
        self.engine=BackboneEngine();self.resolver=ConflictResolver();self.canonical_previous=set();self.metadata={}
    def reset(self):
        self.engine.reset();self.canonical_previous=set();self.metadata={}
    def prime(self,r):
        from play_tools import PlayTools
        a=normalized(r.raw,r.bounds,r.profile)
        self.canonical_previous={row['trigger'] for row in r.profile['backbone_skills']['bindings']
                                 if PlayTools.matches(row['trigger'],a,r.buttons)}
    def process(self,r,now):
        original_axes=normalized(r.raw,r.bounds,r.default_inputs)
        original_buttons={key:bool(r.buttons.get(key,False)) for key in BUTTONS.values()}
        physical=ControllerFrame(now,deepcopy(original_axes),deepcopy(original_buttons),'physical',r.frames)
        mode='NOREX' if r.custom_enabled and r.compare_state.mode=='NOREX' else 'RAW'
        escape=original_buttons.get('L1') and original_buttons.get('R1') and original_axes['L2']>.8 and original_axes['R2']>.8
        self.engine.set_mode(mode)
        if mode=='RAW' or escape:
            r.assist_engine.reset();r.advanced_engine.reset();r.helper_engine.reset();r.play_tools.reset();self.engine.reset()
            # Prime held inputs on every bypass frame so returning to NOREX
            # does not interpret an already held trigger as a synthetic edge.
            r.assist_engine.prime(original_buttons,original_axes);r.advanced_engine.prime(original_buttons,original_axes)
            r.play_tools.prime(original_axes,original_buttons);self.prime(r)
            r.input_context='physical escape' if escape else 'RAW'
            axes,buttons,_=self.resolver.resolve(original_axes,original_buttons,[])
            stages=[(r.input_context,deepcopy(axes),deepcopy(buttons))]
            meta={'mode':mode,'trace':[r.input_context],'conflicts':[], 'physical_escape':bool(escape)}
            self.metadata=meta
            return axes,buttons,physical,stages,meta
        r.assist_engine.observe_movement(original_axes)
        raw_axes=normalized(r.raw,r.bounds,r.profile);physical_buttons=deepcopy(original_buttons)
        stages=[];activated=[];context_conflicts=[]
        if r.assists_armed and not r.replay:
            selected_mode,consumed=r.play_tools.mode_combo(raw_axes,r.mode_bank,now)
            if selected_mode:
                from conflict_rules import validate_global
                try:validate_global(r.mode_bank.profiles[selected_mode],r.mode_bank,r.profile)
                except ValueError as error:
                    r.audit.note(str(error));selected_mode=None
            if selected_mode:
                r.active_mode=selected_mode; r.defending=selected_mode=='Defender'; r.profile=deepcopy(r.mode_bank.profiles[selected_mode]); r.assist_engine.reset(); r.advanced_engine.reset();self.engine.reset()
                raw_axes=normalized(r.raw,r.bounds,r.profile)
            if consumed:
                activated.append('Mode activation combination')
                raw_axes=dict(raw_axes); raw_axes.update(DX=0,DY=0,L2=0,R2=0);physical_buttons['L2 button']=False;physical_buttons['R2 button']=False
            skill,chords=r.play_tools.skill_edges(raw_axes,physical_buttons,r.profile,now)
            if skill and not r.assist_engine.active_recipe:
                from skill_lists import is_list,pick
                if is_list(skill):
                    chosen_move=pick(skill,{n for n,x in r.skill_library.recipes.items() if x.get('steps')})
                    if chosen_move:skill_label=skill+' → '+chosen_move;r.assist_engine.pending_list=skill;skill=chosen_move
                    else:skill_label=skill+' (no ready moves)';skill=None;r.assist_engine.message=skill_label
                else:skill_label=skill
                if skill:r.assist_engine.start_recipe(skill,r.skill_library.recipes[skill]['steps'],now,config=r.profile['assists'],relative=r.skill_library.recipes[skill].get('relative',False))
            else:skill_label=skill
            if chords:
                activated.append('Skill mapping: '+(skill_label or r.assist_engine.recipe_name or 'held trigger'))
                raw_axes=dict(raw_axes)
                for chord in chords:
                    if ' + D-pad ' in chord:
                        raw_axes.update(DX=0,DY=0)
                        modifier=chord.split(' + ')[0]
                        if modifier in ('L2','R2'):raw_axes[modifier]=0;physical_buttons[modifier+' button']=False
                        else:physical_buttons[modifier]=False
                    else:
                        physical_buttons[chord]=False
        if r.assists_armed and not r.replay:
            from play_tools import PlayTools
            rows=r.profile['backbone_skills']['bindings']
            held={row['trigger'] for row in rows if PlayTools.matches(row['trigger'],raw_axes,physical_buttons)}
            rising=held-self.canonical_previous
            self.canonical_previous=held
            chosen=next((row for row in rows if row['trigger'] in rising),None)
            if chosen and not r.assist_engine.active_recipe:
                name=chosen['skill'];recipe=r.profile['backbone_skills']['recipes'][name]
                r.assist_engine.start_recipe(name,recipe['steps'],now,config=r.profile['assists'],relative=recipe.get('relative',False))
                activated.append('Canonical local recipe: '+name)
            for chord in held:
                modifier=chord.split(' + ')[0]
                raw_axes=dict(raw_axes);raw_axes.update(DX=0,DY=0)
                if modifier in ('L2','R2'):
                    raw_axes[modifier]=0;physical_buttons[modifier+' button']=False
                else:physical_buttons[modifier]=False
        stages.append(('Mode / skill combination',dict(raw_axes),dict(physical_buttons)))
        raw_axes=r.play_tools.shape_input(raw_axes,r.profile['play_tools'])
        stages.append(('Outer stick response',dict(raw_axes),dict(physical_buttons)))
        axes,buttons,r.input_context=r.advanced_engine.apply(raw_axes,physical_buttons,r.profile,r.assists_armed and not r.replay,r.defending,now)
        stages.extend(r.advanced_engine.trace_steps)
        activated.extend(label for label,_,_ in r.advanced_engine.trace_steps[1:])
        if axes!=raw_axes or any(bool(buttons.get(k))!=bool(physical_buttons.get(k)) for k in set(buttons)|set(physical_buttons)):activated.append(r.advanced_engine.trace_steps[0][0])
        if r.input_context!='movement':activated.append(r.input_context+' aiming response')
        helper_profile={'helpers':deepcopy(r.profile['helpers'])}
        aliases={'through_pass_response':'through_pass','controlled_dribble_response':'controlled_dribble',
                 'jockey_response':'jockey','sprint_response':'sprint','goalkeeper_stick':'goalkeeper'}
        for key,old in aliases.items():
            if r.profile['backbone_helpers'][key]['enabled']:
                if helper_profile['helpers']['contexts'][old]['enabled']:
                    context_conflicts.append({'helper':old,'winner':key,'reason':'v2 owns equivalent legacy response'})
                helper_profile['helpers']['contexts'][old]['enabled']=False
        for key in ('smoothing','direction_stability'):
            if r.profile['backbone_helpers'][key]['enabled']:
                helper_profile['helpers']['smoothing']['enabled']=False
                helper_profile['helpers']['direction_stability']['enabled']=False
        axes=r.helper_engine.apply(axes,buttons,original_axes,helper_profile,r.assists_armed and not r.replay,now,r.input_context)
        stages.extend(r.helper_engine.trace)
        activated.extend(label for label,_,_ in r.helper_engine.trace)
        cfg=r.profile['backbone_helpers'] if r.assists_armed and not r.replay else {}
        axes,buttons,v2meta=self.engine.process(axes,buttons,cfg,now,original_axes,original_buttons,r.input_context)
        context_conflicts.extend(v2meta['conflicts']);activated.extend(v2meta['trace'])
        stages.append(('V2 response helpers',dict(axes),dict(buttons)))
        if r.assists_armed and not r.replay:
            config=r.profile['assists']
            if r.profile['advanced']['defense_only_jockey'] and not r.defending:
                config={**config,'auto_jockey':False}
            before_a,before_b=dict(axes),dict(buttons)
            axes,buttons=r.assist_engine.apply(axes,buttons,config,now,{**r.skill_library.recipes,**r.profile['backbone_skills']['recipes']},physical_axes=original_axes)
            activated.extend(label for label,_,_ in r.assist_engine.trace_steps)
            activated.extend(r.assist_engine.activations)
            if r.assist_engine.recipe_name:activated.append('Recipe: '+r.assist_engine.recipe_name)
            stages.extend(r.assist_engine.trace_steps)
            held_actions=[k for k in ('Cross','Circle','Square','Triangle') if original_buttons.get(k)]
            mapped_single={row['trigger'] for row in r.profile['play_tools']['skill_bindings'] if ' + D-pad ' not in row['trigger']}
            held_actions=[k for k in held_actions if k not in mapped_single]
            recipe_steps=r.assist_engine.active_recipe or []
            recipe_buttons={k for step in recipe_steps for k in step.get('buttons',{})}
            recipe_axes={k for step in recipe_steps for k in step.get('axes',{})}
            # Unrelated held actions coexist with an explicitly activated skill.
            # Keep manual priority when the recipe overrides the held action or
            # injects attack modifiers that would change that physical action.
            recipe_action_conflict=bool(set(held_actions)&recipe_buttons or
                (held_actions and (recipe_buttons&{'L1','R1','L2 button','R2 button'} or recipe_axes&{'L2','R2'})))
            if r.profile['play_tools']['manual_action_priority'] and held_actions and (recipe_action_conflict or (not recipe_steps and not (chords or held))):
                if r.assist_engine.timers or r.assist_engine.active_recipe or r.assist_engine.followup:context_conflicts.append({'control':'manual action','settings':['Generated action sequence','Physical '+ '/'.join(held_actions)],'winner':'Manual action priority'})
                r.assist_engine.cancel();r.advanced_engine.reset()
                for k in recipe_axes:axes[k]=raw_axes.get(k,original_axes.get(k,0))
                # A physical face-button action suppresses generated button holds/combinations.
                # Restore the complete physical button frame so X/Cross cannot inherit helper modifiers.
                buttons.update({k:bool(v) for k,v in original_buttons.items()})
                for ch in {*chords,*held}:
                    if ' + D-pad ' not in ch:buttons[ch]=False  # mapped skill triggers are never forwarded
                axes['L2']=original_axes.get('L2',0);axes['R2']=original_axes.get('R2',0)
                activated.append('Manual face-button priority');stages.append(('Manual action priority',dict(axes),dict(buttons)))
            action=r.profile['assists']['action_buttons'];held_contexts=[k for k in ('shoot','cross','pass') if original_buttons.get(action['shot' if k=='shoot' else k]) and (r.profile['advanced']['contexts'][k]['enabled'] or (k=='shoot' and r.profile['play_tools']['shot_response']['enabled']))]
            if len(held_contexts)>1:context_conflicts.append({'control':'left-stick aim','settings':held_contexts,'winner':held_contexts[0]})
        # Physical intent owns digital output. Response helpers may shape analog
        # movement, but may not silently add gameplay buttons. Explicit mapped
        # recipes are the only exception while their sequence is active.
        explicit_recipe=bool(r.assist_engine.active_recipe)
        generated={k for k,v in buttons.items() if v and not original_buttons.get(k,False)}
        if generated and not explicit_recipe:
            # Digital controls are physical-first globally: response helpers may
            # reshape analog values, but only an explicit mapped recipe may
            # create a new button press. This also protects analog-only jogging.
            context_conflicts.append({'control':'digital output','settings':sorted(generated),'winner':'Physical intent gate'})
            for k in generated:buttons[k]=False
            stages.append(('Physical intent gate',dict(axes),dict(buttons)))
            activated.append('Physical intent gate')
        # Adapter checkpoints become immutable proposals. Stage ordering is
        # explicit and stable; unchanged controls always preserve physical input.
        intents=[];prev_a,prev_b=original_axes,original_buttons
        for index,(label,a,b) in enumerate(stages):
            priority=min(79,PRIORITY['BASE']+index)
            if label=='Recipe sequence':priority=PRIORITY['SKILL']
            if label in ('Manual action priority','Physical intent gate'):priority=PRIORITY['PHYSICAL_ESCAPE']
            intents.extend(frame_intents(f'{index:02d}:{label}',priority,prev_a,prev_b,a,b))
            prev_a,prev_b=a,b
        # Cover adapters which emitted no checkpoint for an unchanged label.
        intents.extend(frame_intents('final adapter delta',79,prev_a,prev_b,axes,buttons))
        axes,buttons,decisions=self.resolver.resolve(original_axes,original_buttons,intents)
        context_conflicts.extend(decisions)
        self.metadata={'mode':mode,'trace':activated,'conflicts':context_conflicts,
                       'physical_escape':False,'intent_count':len(intents)}
        return axes,buttons,physical,stages,self.metadata
