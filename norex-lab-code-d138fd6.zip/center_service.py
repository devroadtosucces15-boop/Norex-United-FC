#!/usr/bin/python3
"""Supervise the local UI and constrained network broker as one service."""
import os, signal, subprocess, time, fcntl
from pathlib import Path
ROOT=Path('/mnt/DEV_WORK/projects/norex-controller-lab-backbone')
owner=open("/run/norex-center-owner.lock","a+")
fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
children=[]
stopping=False
def stop(*_):
    global stopping
    stopping=True
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
try:
    children.append(subprocess.Popen(['/usr/bin/python3','/opt/norex-gateway/agent.py']))
    for _ in range(100):
        if children[0].poll() is not None:raise RuntimeError('Network helper could not start')
        if Path('/run/norex-gateway/control.sock').exists():break
        time.sleep(.1)
    else:raise RuntimeError('Network helper timed out')
    children.append(subprocess.Popen(['/usr/sbin/runuser','-u','mrsuccess','--','/usr/bin/env','NOREX_CENTER_OWNED=1','DISPLAY=:0','XAUTHORITY=/home/mrsuccess/.Xauthority','XDG_SESSION_TYPE=x11','XDG_RUNTIME_DIR=/run/user/1000','DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus','/usr/bin/python3',str(ROOT/'lab.py'),'--port','8790']))
    while not stopping:
        if any(p.poll() is not None for p in children):raise RuntimeError('A center component stopped')
        time.sleep(.5)
finally:
    for p in reversed(children):
        if p.poll() is None:
            p.terminate()
            try:p.wait(timeout=12)
            except subprocess.TimeoutExpired:p.kill();p.wait()
