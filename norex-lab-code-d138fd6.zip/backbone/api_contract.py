"""Stable v2 JSON envelopes. v2 routes use schema 1 and API version 2."""
from copy import deepcopy
from .fc27_data import CONTROLS,SKILLS,JUGGLING,SIMPLIFIED_SKILLS,COMBOS,MECHANICS,SOURCE_METADATA,CATALOG_NOTES
from .helper_contract import HELPERS,CATEGORIES,effective_config

API_VERSION=2
SCHEMA=1

def envelope(**values):return {'schema':SCHEMA,'api_version':API_VERSION,**deepcopy(values)}
def catalog_payload():
    return envelope(controls=CONTROLS,skills=SKILLS,juggling=JUGGLING,simplified_skills=SIMPLIFIED_SKILLS,
                    combos=COMBOS,mechanics=MECHANICS,sources=SOURCE_METADATA,notes=CATALOG_NOTES,
                    counts={'established_skills':73,'tba_skills':4,'normal_records':len(SKILLS),'juggling_records':len(JUGGLING)})
def helpers_payload():return envelope(categories=CATEGORIES,helpers=HELPERS,context_priority=['shot_response','cross_response','through_pass_response','controlled_dribble_response','jockey_response','sprint_response'])
def effective_payload(mode,profile,helpers,output_local=False,ps5_receipt='UNVERIFIED'):
    if mode not in ('RAW','NOREX'):raise ValueError('Invalid mode')
    # No caller is permitted to assert receipt without a verifying transport.
    if ps5_receipt!='UNVERIFIED':raise ValueError('No verified PS5 receipt backend is available')
    return envelope(mode=mode,profile=profile,helpers=helpers,
        output={'local_virtual':bool(output_local),'ps5_receipt':'UNVERIFIED','game_receipt':'UNVERIFIED'})

def runtime_effective_payload(r):
    mode='NOREX' if r.custom_enabled and r.compare_state.mode=='NOREX' else 'RAW'
    _,effective,suppressed=effective_config(r.profile['backbone_helpers'],r.assists_armed and mode=='NOREX' and not r.replay)
    payload=effective_payload(mode,r.profile['name'],r.profile['helpers'],bool(r.output))
    payload.update(configuration=deepcopy(r.profile),
        helpers_v2={'configured':deepcopy(r.profile['backbone_helpers']),'effective':effective,'suppressed':suppressed},
        processing=deepcopy(r.processing_pipeline.metadata),active_mode=r.active_mode,
        arming={'helpers_armed':r.assists_armed,'custom_enabled':r.custom_enabled,'startup_pending':r.startup_arm_pending},
        comparison=r.compare_state.status(),profile_result=deepcopy(r.profile_result))
    from virtual import UInputOutput
    output=r.output.status() if r.output else {'backend':'uinput','destination':UInputOutput.destination,'transport':UInputOutput.transport,'transport_connected':False}
    payload['output'].update(active=bool(r.output),local_virtual=bool(r.output) and output['backend']=='uinput',backend=output['backend'],destination=output['destination'],transport=output['transport'],
        source=r.output_source,frames=r.output_frames,error=r.output_error,last_stop_reason=r.output_last_stop,
        local_write_acknowledged=r.last_output_ns is not None,last_local_write_ns=r.last_output_ns,
        transport_connected=bool(output['transport_connected']),
        receipt_basis='A successful emit acknowledges only a local backend write; no PS5 or gameplay telemetry exists.')
    from .save_status import save_status
    payload['save_status']=save_status(r)
    payload['physical_frame']=deepcopy(r.compare_state.last_pair['physical']) if r.compare_state.last_pair else None
    payload['final_frame']=r.physical_frame.to_dict()
    from conflict_rules import status
    payload['global_rules']=status(r.profile,r.mode_bank)
    return payload

ROUTES={
 'GET /api/v2/fc27':'Canonical reference facts, provenance, simplified controls and combinations',
 'GET /api/v2/helpers':'Benefit groups, parameter limits and education',
 'GET /api/v2/skills':'Canonical skills; q, stars, status, kind and ready filters',
 'GET /api/v2/effective':'Configured and effective state, final-frame decisions and output truth',
 'GET /api/v2/comparison':'Bounded RAW/NOREX samples and subjective results',
 'GET /api/v2/profiles':'Profile inventory and last operation',
 'GET /api/v2/contracts':'Versioned route and action definitions',
 'POST /api/v2/action':'Validated local mutation; success envelope includes effective configuration',
}
ACTIONS={
 'set_mode':['mode'], 'helpers_configure':['helpers'], 'comparison_start':['mode'],
 'comparison_stop':[], 'comparison_choose':['winner','notes?'],
 'skill_recipe_save':['skill_id','recipe','local_only'], 'skill_recipe_remove':['skill_id'],
 'skill_bindings':['bindings','local_only'], 'skill_run':['skill_id','local_only'],
 'profile_save':['name','profile?'], 'profile_load':['name'],
 'configure':['profile'], 'arm_assists':['local_only'], 'disarm_assists':[],
 'emergency_stop':[],
}

def contracts_payload():
    return envelope(routes=ROUTES,actions=ACTIONS,profile_schema=2,snapshot_schema=2,
        error={'schema':1,'api_version':2,'ok':False,'error':{'code':'INVALID_REQUEST','message':'Readable reason'}},
        bounds={'request_bytes':262144,'recipe_steps':128,'recipe_duration_ms':10000,'comparison_results':32},
        receipt_states=['UNVERIFIED'],raw_basis='Normalized hardware bounds; calibration/curves/remaps/helpers/sequences are bypassed',
        comparison_basis='Processing samples and subjective feedback; not hardware polling rate, latency or game outcomes',
        physical_escape='L1 + R1 + physical L2/R2 above 0.8 cancels generated work and preserves the complete physical frame')
