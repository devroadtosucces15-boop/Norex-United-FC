import unittest
from pathlib import Path
import tempfile
from approved_video_recipes import recipes
from skills import seeds,SkillLibrary,validate_recipe
from assists import AssistEngine,defaults
from pipeline import neutral_frame

class ApprovedVideoRecipeTests(unittest.TestCase):
 def test_complete_sequences_are_playable_but_ambiguous_ones_remain_unconfigured(self):
  s=seeds()
  for name in ('Ramp Flick Up','Knee Akka','Fancy Pass','McGeady Spin','Malouda Flick'):
   self.assertTrue(s[name]['steps'],name)
  for name in ('1 Foot Spin','Step Over Ball','V Drag'):
   self.assertFalse(s[name]['steps'],name)
 def test_right_facing_source_is_rotated_into_forward_up_recipe_space(self):
  # The reviewed first Body Feint example moves the overlay stick down.
  # With the player facing screen-right that is relative player-right.
  r=recipes()['Body Feint']
  self.assertGreater(max(s['axes'].get('RX',0) for s in r['steps']),.8)
  self.assertLess(max(abs(s['axes'].get('RY',0)) for s in r['steps']),.15)
  self.assertEqual(r['overlay_capture']['fps'],30)
 def test_curved_stick_path_is_retained(self):
  r=recipes()['Step Over'];points={(s['axes'].get('RX',0),s['axes'].get('RY',0)) for s in r['steps']}
  self.assertGreater(len(points),8)
  self.assertTrue(any(abs(x)>.3 and abs(y)>.3 for x,y in points))
 def test_every_added_recipe_validates_and_releases_on_completion(self):
  for name,r in recipes().items():
   with self.subTest(name=name):
    validate_recipe(r);self.assertTrue(r['relative']);self.assertIn('AFjd0Y29HAc',r['source'])
    self.assertIn('30 fps',r['source']);self.assertFalse(r['overlay_capture']['game_execution_verified'])
    f=neutral_frame();e=AssistEngine();cfg=defaults();e.start_recipe(name,r['steps'],1_000_000_000,config=cfg,relative=True)
    end=sum(s['ms'] for s in r['steps'])
    for t in range(0,int(end)+101,10):a,b=e.apply(f.axes,f.buttons,cfg,1_000_000_000+t*1_000_000,{name:r})
    self.assertIsNone(e.active_recipe);self.assertFalse(any(b.values()));self.assertFalse(any(a.values()))
 def test_builtin_timing_provenance_survives_storage_reload(self):
  with tempfile.TemporaryDirectory() as d:
   a=SkillLibrary(Path(d));b=SkillLibrary(Path(d))
   self.assertEqual(a.recipes['Ramp Flick Up'],b.recipes['Ramp Flick Up'])
 def test_video_frames_survive_the_real_processing_pipeline_and_release(self):
  import lab,copy
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as d:
   with patch.object(lab,'DATA',Path(d)):r=lab.Lab()
   r.status='Connected';r.custom_enabled=True
   r.raw={k:0 for k in ('LX','LY','RX','RY','L2','R2','DX','DY')}
   r.bounds={k:([0,1] if k in ('L2','R2') else [-1,1]) for k in r.raw}
   r.buttons=copy.deepcopy(neutral_frame().buttons)
   for name,recipe in recipes().items():
    with self.subTest(pipeline=name):
     r.assist_engine.reset();r.processing_pipeline.reset();r.arm_current()
     r.assist_engine.start_recipe(name,recipe['steps'],1_000_000_000,config=r.profile['assists'],relative=True)
     elapsed=0;phase_end=recipe['steps'][0]['ms'];index=0
     duration=sum(s['ms'] for s in recipe['steps'])
     while elapsed<duration:
      while elapsed>=phase_end and index<len(recipe['steps'])-1:
       index+=1;phase_end+=recipe['steps'][index]['ms']
      axes,buttons,*_=r.processing_pipeline.process(r,1_000_000_000+int(elapsed*1e6))
      for k,v in recipe['steps'][index]['axes'].items():self.assertAlmostEqual(axes[k],v,places=5)
      for k,v in recipe['steps'][index]['buttons'].items():self.assertEqual(buttons[k],v)
      elapsed+=10
     axes,buttons,*_=r.processing_pipeline.process(r,1_000_000_000+int((duration+20)*1e6))
     self.assertFalse(any(axes.values()));self.assertFalse(any(buttons.values()))
     self.assertIsNone(r.assist_engine.active_recipe)
