"""Filterable facts about each move: rating, where it is done, buttons, sticks, fake shot, side, pace.

Everything comes from data already in the Lab: the recorded menu (ui/fc27-canonical.json), the guide
cross-check (ui/fc27-guides.json) and the move's own recipe. Nothing here changes how a move plays.
"""
import json,re
from pathlib import Path

UI=Path(__file__).with_name('ui')
def _norm(n):return re.sub(r'[^a-z0-9]','',re.sub(r'\s+while\s+(standing|running|jogging)\b','',str(n).lower().replace('&','and').replace('kneel header','kneeling header')))
_cache={}
def _load():
    if _cache:return _cache
    canon={};guides={}
    try:
        for r in json.loads((UI/'fc27-canonical.json').read_text()).get('records',[]):
            if r.get('kind')=='skill':canon[_norm(r['name'])]=r
    except Exception:pass
    try:
        for m in json.loads((UI/'fc27-guides.json').read_text()).get('moves',[]):guides[_norm(m['name'])]=m
    except Exception:pass
    _cache.update(canon=canon,guides=guides);return _cache

def _stick(steps,prefix):
    """flick / hold / arc for one stick (prefix 'R' or 'L'), read from the recipe itself."""
    keys=(prefix+'X',prefix+'Y')
    xs=[s for s in steps if any(s['axes'].get(k) for k in keys)]
    if not xs:return None
    if len(xs)>=4 and sum(1 for s in xs if s['ms']<=40)>=3:return 'arc'
    if any(s['ms']>=150 for s in xs):return 'hold'
    return 'flick'

def facets(name,recipe,in_menu):
    c=_load();k=_norm(name);rec=c['canon'].get(k);g=c['guides'].get(k)
    steps=(recipe or {}).get('steps') or []
    ctx_text=' '.join(filter(None,[(rec or {}).get('context',''),(g or {}).get('context','')])).lower()
    stars=(rec or {}).get('stars') or (g or {}).get('stars')
    air=bool(rec and rec.get('menu_category')=='Juggling Tricks') or bool(g and g.get('juggling'))
    where=['in air' if air else 'on the ground']
    situation=[w for w,t in (('standing','standing'),('running','running'),('jogging','jog')) if t in ctx_text] or ['any situation']
    btn=sorted({b for s in steps for b,v in s['buttons'].items() if v}|{a for s in steps for a,v in s['axes'].items() if a in ('L2','R2') and v})
    mods=[b for b in ('L1','R1','L2','R2','R3') if b in btn]
    fake=('Square' in btn or 'Circle' in btn) and 'Cross' in btn
    rs=_stick(steps,'R');ls=_stick(steps,'L')
    stick=([f'right stick {rs}'] if rs else [])+([f'left stick {ls}'] if ls else [])
    low=name.lower();side='left' if re.search(r'\bleft\b',low) else 'right' if re.search(r'\bright\b',low) else 'either'
    ps=['Trickster'] if ('trickster' in low or 'kneel' in low or 'trickster' in ctx_text) else []
    dur=sum(s['ms'] for s in steps);pace=[] if not steps else ['quick'] if dur<=300 else ['medium'] if dur<=600 else ['long']
    out={'rating':[f'{stars} star'] if stars else (['juggling'] if air else ['unrated']),'where':where,'situation':situation,
         'buttons':mods or (['no buttons'] if steps else []),'fake':['fake shot'] if fake else ['no fake shot'],
         'stick':stick,'side':[side],'playstyle':ps,'pace':pace,'menu':['in the FC27 menu'] if in_menu else ['older game']}
    return out
