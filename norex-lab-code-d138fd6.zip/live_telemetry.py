"""Read-only, bounded controller snapshots; successful local writes only."""
from copy import deepcopy
import time

def telemetry(r):
    pair=r.compare_state.last_pair
    physical=deepcopy(pair['physical']) if pair else None
    now=time.monotonic_ns()
    output=deepcopy(r.last_emitted_frame) if r.output else None
    if output and r.last_output_ns and now-r.last_output_ns>300_000_000:output={**output,'axes':{},'buttons':{}}
    return {'schema':1,'server_ns':now,'revision':r.revision,'input':physical,'output':output,
            'skill_orientation':r.assist_engine.orientation_status(r.profile['assists']),
            'output_active':bool(r.output),'output_frames':r.output_frames,
            'last_write_ns':r.last_output_ns,'input_age_ms':max(0,(now-physical['t_ns'])/1e6) if physical else None,
            'output_age_ms':max(0,(now-r.last_output_ns)/1e6) if r.last_output_ns else None,
            'skill':skill_block(r),
            'input_connected':r.status=='Connected' and r.master_enabled,
            'receipt':'Successful local virtual-device write; PS5/game receipt remains unverified.'}


def skill_block(r):
    """What the move viewer needs: the move playing now, the one before it, and (for a list) the one coming up."""
    e=r.assist_engine;now=time.monotonic_ns();hist=list(e.history);cur=None
    if e.active_recipe:
        steps=e.active_recipe;elapsed=(now-e.recipe_started)/1e6;acc=0;idx=len(steps)-1
        for i,s in enumerate(steps):
            acc+=s['ms']
            if elapsed<acc:idx=i;break
        cur={'name':e.recipe_name,'step':idx,'steps':len(steps),'elapsed_ms':round(elapsed),'duration_ms':round(sum(s['ms'] for s in steps)),
             'list':hist[-1]['list'] if hist else None}
    prev=(hist[-2] if cur else hist[-1]) if len(hist)>(1 if cur else 0) else None
    nxt=None
    if e.list_ctx:
        import skill_lists
        nxt=skill_lists.upcoming(e.list_ctx,{n for n,x in r.skill_library.recipes.items() if x.get('steps')})
    return {'now':cur,'previous':prev,'next':nxt,'list':e.list_ctx}
