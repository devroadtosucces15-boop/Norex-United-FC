"""Versioned complete snapshots and crash-safe atomic document replacement."""
import copy,json,os,tempfile
from pathlib import Path
from datetime import datetime,timezone
from pipeline import validate_profile
from skills import seeds,validate_recipe
from play_tools import MODES

SNAPSHOT_SCHEMA=2
SCOPE={'calibration':'profile-scoped centers/ranges',
       'included':'response, remapping, legacy and v2 helpers, legacy and canonical recipes, bindings, modes, UI selections',
       'excluded':'device discovery, transport/media, Lab power, live arming, RAW comparison session, output and replay'}

def snapshot(runtime,profile):
    return {'snapshot_schema':SNAPSHOT_SCHEMA,'saved_at':datetime.now(timezone.utc).isoformat(),
            'profile':validate_profile(profile),'skill_recipes':copy.deepcopy(runtime.skill_library.recipes),
            'mode_bank':{'enabled':runtime.mode_bank.enabled,'bindings':copy.deepcopy(runtime.mode_bank.bindings),
                         'profiles':copy.deepcopy(runtime.mode_bank.profiles)},
            'selection':{'active_mode':runtime.active_mode,'base_profile':copy.deepcopy(runtime.base_profile)},
            'scope':copy.deepcopy(SCOPE)}

def migrate(document):
    """Flat schemas 1/2 -> complete profile defaults; snapshot 1 -> snapshot 2."""
    if not isinstance(document,dict):raise ValueError('Invalid profile document')
    doc=copy.deepcopy(document)
    if 'snapshot_schema' not in doc:return doc
    version=doc['snapshot_schema']
    if type(version) is not int or version not in (1,SNAPSHOT_SCHEMA):raise ValueError('Unsupported snapshot schema')
    if version==1:
        doc['snapshot_schema']=SNAPSHOT_SCHEMA
        doc['scope']=copy.deepcopy(SCOPE)
    return doc

def validate_snapshot(document,bank,previous=None):
    doc=migrate(document)
    if 'snapshot_schema' not in doc:
        from conflict_rules import validate_global
        p=validate_profile(doc);validate_global(p,bank,previous)
        return p,None,None,None
    if set(doc)!={'snapshot_schema','saved_at','profile','skill_recipes','mode_bank','selection','scope'}:
        raise ValueError('Incomplete or unknown snapshot fields')
    if not isinstance(doc['saved_at'],str):raise ValueError('Invalid saved timestamp')
    try:
        stamp=datetime.fromisoformat(doc['saved_at'])
        if stamp.tzinfo is None:raise ValueError('Timestamp needs a timezone')
    except ValueError as e:raise ValueError('Invalid saved timestamp') from e
    if doc['scope']!=SCOPE:raise ValueError('Invalid snapshot scope')
    p=validate_profile(doc['profile']);recipes=seeds();saved=doc['skill_recipes']
    if isinstance(saved,dict):  # drop built-in rows for names the catalog no longer carries (e.g. renamed duplicates)
        saved={k:v for k,v in saved.items() if k in recipes or not (isinstance(v,dict) and str(v.get('status','')).startswith(('Training template','Menu-notation recipe','Recipe required')))}
    if not isinstance(saved,dict) or not set(saved)<=set(recipes):raise ValueError('Incomplete skill snapshot')
    for name,row in saved.items():  # names added after a snapshot was saved keep their built-in recipe
        if not isinstance(row,dict) or row.get('name')!=name:raise ValueError('Invalid snapshot recipe name')
        if str(row.get('status','')).startswith(('Training template','Menu-notation recipe')) or (not row.get('steps') and row.get('status')=='Recipe required'):continue  # built-in, never user-edited
        if row.get('steps'):
            validated=validate_recipe(row)
            recipes[name]=copy.deepcopy(recipes[name]) if row['steps']==recipes[name]['steps'] and row['relative']==recipes[name]['relative'] else validated
        elif row!=recipes[name]:raise ValueError('Invalid empty recipe')
    modes=doc['mode_bank']
    if not isinstance(modes,dict) or set(modes)!={'enabled','bindings','profiles'} or not isinstance(modes['profiles'],dict) or set(modes['profiles'])!=set(MODES):
        raise ValueError('Incomplete mode snapshot')
    candidate=copy.copy(bank);candidate.configure(modes['enabled'],modes['bindings'],persist=False)
    candidate.profiles={k:validate_profile(v) for k,v in modes['profiles'].items()}
    selection=doc['selection']
    if not isinstance(selection,dict) or set(selection)!={'active_mode','base_profile'} or selection['active_mode'] not in (*MODES,'None'):
        raise ValueError('Invalid saved mode')
    selection={'active_mode':selection['active_mode'],'base_profile':validate_profile(selection['base_profile'])}
    from backbone.skills import validate_bindings
    for profile in [p,selection['base_profile'],*candidate.profiles.values()]:
        validate_bindings(profile,candidate)
        if previous is not None:
            from conflict_rules import validate_global
            validate_global(profile,candidate,previous,bank)
        assigned=[row['skill'] for row in profile['play_tools']['skill_bindings']]
        assigned += [row['skill'] for row in profile['assists']['button_skills'].values() if row['skill']!='Disabled']
        assigned += [name for group in ('skills','flex') for name in profile['assists'][group].values() if name!='Disabled']
        for name in assigned:
            if name.startswith('List: '):continue
            if not recipes[name]['steps']:raise ValueError('Saved skill binding needs a recipe')
    return p,recipes,candidate,selection

def restore(runtime,validated):
    """Install a fully validated snapshot; never restores arming or transport."""
    p,recipes,bank,selection=validated
    if getattr(runtime,'command_center',False):
        from section_controls import enforce
        p=enforce(runtime,p)
    runtime.startup_arm_pending=False;runtime.assists_armed=False
    runtime.assist_engine.reset();runtime.advanced_engine.reset();runtime.helper_engine.reset();runtime.play_tools.reset()
    runtime.processing_pipeline.reset();runtime.compare_state.finish('profile restored');runtime.compare_state.set_mode('NOREX')
    runtime.profile=copy.deepcopy(p);runtime.active_mode='None';runtime.base_profile=copy.deepcopy(p);runtime.defending=False
    if recipes is not None:
        runtime.skill_library.recipes=recipes;runtime.mode_bank=bank
        runtime.active_mode=selection['active_mode'];runtime.base_profile=selection['base_profile']
        runtime.defending=runtime.active_mode=='Defender'
    if getattr(runtime,'command_center',False) and not runtime.sections['Modes']:
        runtime.mode_bank.enabled=False;runtime.active_mode='None';runtime.defending=False

def write_atomic(path,document):
    """Unique same-directory temp files avoid parallel saves clobbering each other.

    All pre-rename failures leave the old document intact. A directory-fsync
    failure occurs after the commit point and explicitly reports uncertain
    durability; the renamed document is already visible.
    """
    path=Path(path);tmp=None
    # Serialize before opening a file; reject nonfinite values and invalid keys.
    payload=json.dumps(document,indent=2,allow_nan=False)+'\n'
    try:
        fd,name=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.tmp',dir=path.parent)
        tmp=Path(name)
        with os.fdopen(fd,'w') as f:
            f.write(payload);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path);tmp=None
        fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        if tmp is not None:tmp.unlink(missing_ok=True)


def prepare_save(runtime,profile,name):
    p=validate_profile(profile);p['name']=name
    document=snapshot(runtime,p)
    if runtime.active_mode=='None':document['selection']['base_profile']=copy.deepcopy(p)
    else:document['mode_bank']['profiles'][runtime.active_mode]=copy.deepcopy(p)
    validated=validate_snapshot(document,runtime.mode_bank,previous=runtime.profile)
    return document,validated


def commit_save(data,path,document):
    """A complete named snapshot is the save commit point.

    A durable intent allows startup selection to recover after interruption
    between the two atomic replacements. Readers run under the runtime lock.
    Pre-commit errors abort; after-commit selection errors are surfaced as a
    pending-startup warning, never as a falsely failed profile save.
    """
    journal=Path(data)/'pending-profile-save.json'
    write_atomic(journal,{'schema':1,'file':Path(path).name,'document':document})
    try:write_atomic(path,document)
    except OSError:
        # If rename succeeded but directory fsync failed, the committed bytes
        # are visible. Preserve the recovery intent and report uncertain durability.
        try:committed=json.loads(Path(path).read_text())==document
        except (OSError,ValueError):committed=False
        if not committed:journal.unlink(missing_ok=True)
        raise
    try:
        write_atomic(Path(data)/'startup-profile.json',document)
        journal.unlink(missing_ok=True)
        return None
    except OSError as e:
        return 'Profile saved; startup selection recovery pending: '+str(e)


def recover_save(data):
    """Idempotent recovery before reading startup; never runs recipes or output."""
    journal=Path(data)/'pending-profile-save.json'
    if not journal.exists():return
    row=json.loads(journal.read_text())
    import re
    if not isinstance(row,dict) or set(row)!={'schema','file','document'} or row['schema']!=1 or not isinstance(row['file'],str) or not re.fullmatch(r'profile-[A-Za-z0-9_-]{1,40}\.json',row['file']):
        raise ValueError('Invalid profile save recovery journal')
    path=Path(data)/row['file']
    if path.exists() and json.loads(path.read_text())==row['document']:
        write_atomic(Path(data)/'startup-profile.json',row['document'])
    journal.unlink()
