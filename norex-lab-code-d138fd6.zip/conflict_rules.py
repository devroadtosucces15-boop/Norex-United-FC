"""Page-independent configuration rules. Pure checks: never edit a profile.

Existing profiles remain intact. Mutations may resolve old conflicts but cannot
introduce new ones; strict validation is available for new/imported profiles.
"""
from copy import deepcopy
from itertools import combinations

def get(profile,path):
    for key in path.split('.'):
        profile=profile[key]
    return profile

def option_rows():
    from backbone.helper_contract import HELPERS
    from assists import TOGGLES
    rows=[]
    for key,h in HELPERS.items():
        if h['kind']!='UTILITY':rows.append({'id':'backbone_helpers.'+key+'.enabled','name':h['name'],'section':'Helpers','description':h['what_it_does']})
    for key in TOGGLES:rows.append({'id':'assists.'+key,'name':key.replace('_',' ').title(),'section':'Actions','description':'Stored input behavior; game effects depend on controls and context.'})
    for key in ('shoot','pass','cross','switching'):rows.append({'id':'advanced.contexts.'+key+'.enabled','name':key.title()+' context response','section':'Responses','description':'Changes response while the configured input context is active.'})
    for key in ('smoothing','direction_stability'):rows.append({'id':'helpers.'+key+'.enabled','name':'Legacy '+key.replace('_',' '),'section':'Responses','description':'Retained existing response implementation.'})
    for key in ('through_pass','controlled_dribble','jockey','sprint','goalkeeper'):rows.append({'id':'helpers.contexts.'+key+'.enabled','name':'Legacy '+key.replace('_',' ')+' response','section':'Responses','description':'Retained existing context implementation.'})
    rows.extend([{'id':'play_tools.outer.enabled','name':'Legacy outer response','section':'Controller','description':'Scales outer stick travel.'},{'id':'play_tools.shot_response.enabled','name':'Shot-type response','section':'Responses','description':'Uses configured normal, finesse and power response values.'},{'id':'advanced.sprint_toggle','name':'Sprint toggle','section':'Actions','description':'Retained sprint toggle setting.'}])
    return rows

def groups():
    result=[['backbone_helpers.smoothing.enabled','backbone_helpers.direction_stability.enabled','helpers.smoothing.enabled','helpers.direction_stability.enabled'],['backbone_helpers.outer_response.enabled','play_tools.outer.enabled'],['assists.low_driven','assists.perfect_lowdrive'],['assists.finesse_finish','assists.auto_power_shot'],['backbone_helpers.shot_response.enabled','assists.timed_shot']]
    for modern,old in [('through_pass_response','through_pass'),('controlled_dribble_response','controlled_dribble'),('jockey_response','jockey'),('sprint_response','sprint'),('goalkeeper_stick','goalkeeper')]:
        result.append(['backbone_helpers.'+modern+'.enabled','helpers.contexts.'+old+'.enabled'])
    return result

def trigger_owners(p,bank=None):
    owners=[]
    for key,value in p['advanced']['shortcuts'].items():
        if value!='Disabled':owners.append(('advanced.shortcuts.'+key,value))
    for key,row in p['assists']['button_skills'].items():
        if row['button']!='Disabled':owners.append(('assists.button_skills.'+key,row['button']))
    if p['assists']['lock_button']!='Disabled':owners.append(('assists.lock_button',p['assists']['lock_button']))
    for root in ('play_tools','backbone_skills'):
        for row in p[root]['skill_bindings' if root=='play_tools' else 'bindings']:
            owners.append((root+'.binding.'+row['trigger'],row['trigger']))
    if bank is not None and bank.enabled:
        for name,row in bank.bindings.items():
            if row['trigger']=='both':
                for modifier in ('L2','R2'):owners.append(('mode.'+name,modifier+' + D-pad '+row['direction']))
            else:owners.append(('mode.'+name,row['trigger']+' + D-pad '+row['direction']))
    return owners

def configuration_conflicts(p,bank=None):
    rows=option_rows();names={r['id']:r['name'] for r in rows};found=[]
    def add(a,b,reason):
        members=sorted([a,b]);found.append({'id':'|'.join(members),'options':members,'names':[names.get(k,k) for k in members],'reason':reason})
    for group in groups():
        active=[key for key in group if get(p,key)]
        for a,b in combinations(active,2):add(a,b,'These mechanisms own the same response or action. Choose one.')
    for (a,ta),(b,tb) in combinations(trigger_owners(p,bank),2):
        if a==b:continue
        if ta==tb or (' + ' not in ta and tb.split(' + ')[0]==ta) or (' + ' not in tb and ta.split(' + ')[0]==tb):
            add(a,b,'Activation overlap: '+ta+' / '+tb+'. Choose separate bindings.')
    # Legacy shot shortcuts already have validation; include them in the shared
    # report so the Builder uses the same limits as direct API requests.
    for key in ('finesse','chip','power','low_driven'):
        if p['advanced']['shortcuts'][key]!='Disabled':
            for legacy in ('timed_shot','low_driven','perfect_lowdrive','auto_power_shot','finesse_finish'):
                if p['assists'][legacy]:add('advanced.shortcuts.'+key,'assists.'+legacy,'Shot shortcut overlaps an existing shot sequence.')
    return sorted({r['id']:r for r in found}.values(),key=lambda r:r['id'])

def validate_global(p,bank=None,previous=None,previous_bank=None):
    existing={r['id'] for r in configuration_conflicts(previous,previous_bank if previous_bank is not None else bank)} if previous is not None else set()
    new=[r for r in configuration_conflicts(p,bank) if r['id'] not in existing]
    if new:raise ValueError('Global conflict: '+'; '.join(' + '.join(r['names'])+': '+r['reason'] for r in new))
    return p

def status(p,bank=None):
    active=configuration_conflicts(p,bank);rows=option_rows();blocked={}
    for row in rows:
        row['enabled']=bool(get(p,row['id']))
        if not row['enabled']:
            candidate=deepcopy(p);node=candidate;parts=row['id'].split('.')
            for key in parts[:-1]:node=node[key]
            node[parts[-1]]=True
            before={r['id'] for r in active};introduced=[r for r in configuration_conflicts(candidate,bank) if r['id'] not in before]
            if introduced:blocked[row['id']]=introduced
    return {'scope':'entire configuration, all pages and API mutation paths','policy':'Existing overlaps are preserved; new overlaps are rejected. Disable one existing selection to resolve it.','options':rows,'conflicts':active,'blocked':blocked,'trigger_owners':[{'owner':a,'trigger':b} for a,b in trigger_owners(p,bank)]}
