import copy,tempfile,unittest,json,time
from pathlib import Path
from unittest.mock import patch
from pipeline import default_profile,neutral_frame
import lab
from conflict_rules import validate_global,configuration_conflicts,status
from live_telemetry import telemetry
from backbone.actions import act
from profile_store import snapshot,validate_snapshot
from section_controls import toggle

class GlobalRulesTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.addCleanup(self.tmp.cleanup)
        with patch.object(lab,'DATA',Path(self.tmp.name)):self.r=lab.Lab()
        self.r.raw={'LX':.4,'LY':0,'RX':0,'RY':0,'L2':0,'R2':0,'DX':0,'DY':0}
        self.r.bounds={k:[-1,1] if k not in ('L2','R2') else [0,1] for k in self.r.raw}
        self.r.buttons=copy.deepcopy(neutral_frame().buttons);self.r.status='Connected'
    def test_conflict_across_legacy_and_modern_pages(self):
        p=copy.deepcopy(self.r.profile);p['helpers']['contexts']['jockey']['enabled']=True
        self.r.apply_profile(p);before=copy.deepcopy(self.r.profile)
        p['backbone_helpers']['jockey_response']['enabled']=True
        with self.assertRaisesRegex(ValueError,'Global conflict'):self.r.apply_profile(p)
        self.assertEqual(before,self.r.profile)
        self.assertIn('backbone_helpers.jockey_response.enabled',status(before)['blocked'])
    def test_direct_v2_action_cannot_bypass_page_blocks(self):
        p=copy.deepcopy(self.r.profile);p['backbone_helpers']['smoothing']['enabled']=True
        self.r.apply_profile(p);conf=copy.deepcopy(p['backbone_helpers']);conf['direction_stability']['enabled']=True
        with self.assertRaisesRegex(ValueError,'Global conflict'):act(self.r,{'action':'helpers_configure','helpers':conf})
        self.assertFalse(self.r.profile['backbone_helpers']['direction_stability']['enabled'])
    def test_existing_overlap_preserved_and_can_be_resolved(self):
        p=copy.deepcopy(self.r.profile)
        for k in ('smoothing','direction_stability'):p['backbone_helpers'][k]['enabled']=True
        self.r.profile=copy.deepcopy(p)
        p['deadzone']=.1;self.r.apply_profile(p)
        self.assertEqual(len(configuration_conflicts(self.r.profile)),1)
        p['backbone_helpers']['smoothing']['enabled']=False;self.r.apply_profile(p)
        self.assertFalse(configuration_conflicts(self.r.profile))
    def test_legacy_binding_conflicts_with_shortcut(self):
        p=copy.deepcopy(self.r.profile);p['advanced']['shortcuts']['precision_clutch']='L3'
        p['play_tools']['skill_bindings']=[{'trigger':'L3','skill':'Elastico'}]
        with self.assertRaisesRegex(ValueError,'Activation overlap'):validate_global(p)
    def test_both_trigger_mode_blocks_legacy_chord(self):
        p=copy.deepcopy(self.r.profile);p['play_tools']['skill_bindings']=[{'trigger':'L2 + D-pad left','skill':'Elastico'}]
        self.r.mode_bank.enabled=True
        with self.assertRaisesRegex(ValueError,'Activation overlap'):validate_global(p,self.r.mode_bank)
    def test_snapshot_import_cannot_add_conflict(self):
        p=copy.deepcopy(self.r.profile)
        for k in ('smoothing','direction_stability'):p['backbone_helpers'][k]['enabled']=True
        doc=snapshot(self.r,p)
        with self.assertRaisesRegex(ValueError,'Global conflict'):validate_snapshot(doc,self.r.mode_bank,previous=self.r.profile)
    def test_section_restore_is_transactional_when_other_page_claims_control(self):
        self.r.command_center=True;self.r.master_enabled=True
        p=copy.deepcopy(self.r.profile);p['helpers']['contexts']['jockey']['enabled']=True
        self.r.section_saved['Helpers']={('helpers',):p['helpers']};self.r.sections['Helpers']=False
        self.r.profile['backbone_helpers']['jockey_response']['enabled']=True
        before=copy.deepcopy(self.r.section_saved)
        with self.assertRaisesRegex(ValueError,'Global conflict'):toggle(self.r,'Helpers',True)
        self.assertEqual(before,self.r.section_saved);self.assertFalse(self.r.sections['Helpers'])
    def test_telemetry_is_last_successful_write_not_computed_frame(self):
        class Sink:
            def emit(self,f):pass
        self.r.output=Sink();self.r.master_enabled=True;self.r.on_frame()
        self.assertIsNone(telemetry(self.r)['output'])
        self.r.emit_output(self.r.physical_frame)
        written=telemetry(self.r)['output']
        self.r.physical_frame=neutral_frame()
        self.assertEqual(telemetry(self.r)['output'],written)
    def test_failed_emit_does_not_falsely_acknowledge(self):
        class Sink:
            def emit(self,f):raise OSError('test')
            def close(self):pass
        self.r.output=Sink();self.r.emit_output(neutral_frame())
        self.assertIsNone(telemetry(self.r)['output'])
    def test_registry_reports_scope_and_existing_conflicts(self):
        p=default_profile();p['helpers']['smoothing']['enabled']=True;p['backbone_helpers']['direction_stability']['enabled']=True
        result=status(p)
        self.assertEqual(len(result['conflicts']),1);self.assertIn('all pages',result['scope'])
