import copy,json,os,subprocess,sys,tempfile,threading,unittest,urllib.request,urllib.error
from pathlib import Path
from unittest.mock import patch
import lab
from command_center import Owner,OwnedSessions,power
from pipeline import default_profile
from test_backbone_runtime_v2 import Sink

class MasterTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.addCleanup(self.tmp.cleanup)
        with patch.object(lab,'DATA',Path(self.tmp.name)):self.r=lab.Lab()
        self.r.command_center=True;self.r.status='Connected';self.sink=Sink();self.r.output_factory=lambda:self.sink
        self.block=patch('command_center.conflicts',return_value=[]);self.block.start();self.addCleanup(self.block.stop)
    def test_on_idempotent_one_sink_and_arms(self):
        with patch.object(self.r,'output_factory',return_value=self.sink) as create:
            power(self.r,True);power(self.r,True)
            self.assertEqual(create.call_count,1);self.assertTrue(self.r.master_enabled);self.assertTrue(self.r.assists_armed)
    def test_off_resets_stops_and_preserves_archives(self):
        archive=self.r.data/'profile-keep.json';archive.write_text('preserved')
        power(self.r,True);self.r.profile['deadzone']=.4;self.r.profile['assists']['fast_dribble']=True
        power(self.r,False);power(self.r,False)
        self.assertFalse(self.r.master_enabled);self.assertFalse(self.r.assists_armed);self.assertIsNone(self.r.output);self.assertTrue(self.sink.closed)
        self.assertEqual(self.r.profile,default_profile());self.assertEqual(json.loads((self.r.data/'startup-profile.json').read_text()),default_profile());self.assertEqual(archive.read_text(),'preserved')
    def test_failed_output_rolls_back(self):
        self.r.output_factory=lambda:(_ for _ in ()).throw(OSError('denied'))
        with self.assertRaises(ValueError):power(self.r,True)
        self.assertFalse(self.r.master_enabled);self.assertFalse(self.r.assists_armed);self.assertIsNone(self.r.output)
    def test_disconnect_turns_master_off(self):
        power(self.r,True);self.r.disconnect_runtime('unplug');self.assertFalse(self.r.master_enabled);self.assertTrue(self.sink.closed)
    def test_conflict_does_not_open_or_kill(self):
        with patch('command_center.conflicts',return_value=['123: chiaki']):
            with self.assertRaises(ValueError):power(self.r,True)
        self.assertIsNone(self.r.output)
    def test_off_blocks_bypass(self):
        power(self.r,False)
        for a in ('arm_assists','delivery_test_start','replay','remoteplay_connect','skill_run'):
            with self.assertRaises(ValueError):self.r.action({'action':a})
    def test_center_two_clients_and_stale_write(self):
        server=lab.ThreadingHTTPServer(('127.0.0.1',0),lab.Handler);server.lab=self.r
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        self.addCleanup(server.server_close);self.addCleanup(server.shutdown)
        base=f'http://127.0.0.1:{server.server_port}'
        def get():
            with urllib.request.urlopen(base+'/api/center') as response:return json.load(response)
        one=get();two=get();self.assertEqual(one['state']['revision'],two['state']['revision'])
        body={'action':'master_power','enabled':True,'expected_revision':one['state']['revision']}
        req=urllib.request.Request(base+'/api/action',json.dumps(body).encode(),{'Content-Type':'application/json'})
        with urllib.request.urlopen(req) as response:self.assertTrue(json.load(response)['master_enabled'])
        self.assertTrue(get()['state']['master_enabled'])
        with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(req)
        power(self.r,False);self.assertFalse(get()['state']['master_enabled'])
    def test_overrun_resync_rearms_under_master(self):
        power(self.r,True);self.r.resync_input();self.assertFalse(self.r.assists_armed)
        self.r._dropping=True;self.r.feed(0,0,0,0,0)
        self.assertTrue(self.r.master_enabled);self.assertTrue(self.r.assists_armed);self.assertIs(self.r.output,self.sink)
    def test_output_emit_failure_turns_master_off(self):
        power(self.r,True)
        self.sink.emit=lambda frame:(_ for _ in ()).throw(OSError('write failed'))
        self.r.on_frame();self.assertFalse(self.r.master_enabled);self.assertIsNone(self.r.output);self.assertFalse(self.r.assists_armed)
    def test_lock_excludes_second_process(self):
        path=self.r.data/'owner.lock';owner=Owner(path);self.addCleanup(owner.close)
        result=subprocess.run([sys.executable,'-c','from command_center import Owner;Owner(__import__("sys").argv[1])',str(path)],capture_output=True)
        self.assertNotEqual(result.returncode,0)
    def test_installed_gateway_process_is_detected(self):
        self.block.stop()
        from command_center import conflicts
        # Never advertise a fake conflict in the real process table: a running
        # Lab watchdog would correctly shut down the user's active session.
        with tempfile.TemporaryDirectory() as tmp:
            proc_root=Path(tmp);entry=proc_root/'99999999';entry.mkdir()
            (entry/'comm').write_text('python3\n')
            (entry/'cmdline').write_bytes(b'/usr/bin/python3\0/opt/norex-gateway/app.py\0')
            (entry/'cwd').symlink_to(proc_root,target_is_directory=True)
            real_path=Path
            with patch('command_center.Path',side_effect=lambda value:proc_root if value=='/proc' else real_path(value)):
                self.assertEqual(conflicts(),['99999999: python3'])
    def test_cleanup_only_own_child(self):
        unrelated=subprocess.Popen(['sleep','30']);owned=OwnedSessions();child=owned.start(['sleep','30'])
        try:
            self.assertEqual(owned.close(),[]);self.assertIsNotNone(child.poll());self.assertIsNone(unrelated.poll())
        finally:unrelated.terminate();unrelated.wait();owned.close()
