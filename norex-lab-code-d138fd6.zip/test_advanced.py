import copy
import math
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from advanced import AdvancedEngine, SHORTCUTS
from pipeline import default_profile, validate_profile, transform
import lab
from test_output_backend import FakeBackend

class AdvancedInputs(unittest.TestCase):
    def setUp(self):
        self.p=default_profile();self.p['deadzone']=0;self.e=AdvancedEngine()
        self.a={'LX':.3,'LY':.4,'RX':.3,'RY':-.4,'L2':0.,'R2':0.}
    def apply(self,buttons=None,now=0,armed=True,defending=False):
        return self.e.apply(self.a,buttons or {},validate_profile(self.p),armed,defending,now)
    def test_old_profiles_migrate_without_input_changes(self):
        p=copy.deepcopy(self.p);p.pop('advanced');p=validate_profile(p)
        self.assertEqual(self.e.apply(self.a,{},p,False,False,0)[:2],transform(self.a,{},p))
    def test_shooting_curve_preserves_direction_and_releases(self):
        self.p['advanced']['contexts']['shoot']={'enabled':True,'exponent':2}
        a,b,context=self.apply({'Circle':True})
        self.assertAlmostEqual(math.hypot(a['LX'],a['LY']),.25);self.assertAlmostEqual(a['LY']/a['LX'],4/3);self.assertEqual(context,'shoot')
        a,_,context=self.apply({},10_000_000);self.assertEqual(context,'movement');self.assertAlmostEqual(math.hypot(a['LX'],a['LY']),.5)
        a,_,_=self.apply({'Circle':True},20_000_000,False);self.assertAlmostEqual(math.hypot(a['LX'],a['LY']),.5)
    def test_context_priority_and_button_remapping(self):
        self.p['button_map']['Triangle']='Circle'
        for k,exp in [('shoot',2),('pass',.5),('cross',1)]:self.p['advanced']['contexts'][k]={'enabled':True,'exponent':exp}
        self.assertEqual(self.apply({'Triangle':True,'Cross':True})[2],'shoot')
        self.assertEqual(self.apply({'Square':True,'Cross':True})[2],'cross')
        self.assertEqual(self.apply({'Cross':True})[2],'pass')
    def test_switching_only_in_manual_defending_mode(self):
        self.p['advanced']['contexts']['switching']={'enabled':True,'exponent':2}
        self.assertAlmostEqual(self.apply(defending=True)[0]['RX'],.15)
        self.assertAlmostEqual(self.apply(defending=False)[0]['RX'],.3)
    def test_separate_dead_zones_with_permuted_axes(self):
        self.p['advanced']['stick_deadzone']={'enabled':True,'left':.5,'right':0}
        self.p['axis_map']={'LX':'RX','LY':'RY','RX':'LX','RY':'LY'}
        a,_,_=self.apply();self.assertEqual(a['RX'],0);self.assertAlmostEqual(a['LX'],.3)
    def test_independent_trigger_and_hysteresis_both_channels(self):
        t=self.p['advanced']['triggers']['R2'];t.update(enabled=True,digital=True,press=.3,release=.1,deadzone=0,exponent=1)
        self.a['L2']=.5
        for now,value,expected in [(0,.4,1),(10_000_000,.2,1),(20_000_000,.09,0),(30_000_000,.2,0)]:
            self.a['R2']=value;a,b,_=self.apply(now=now);self.assertEqual(a['R2'],expected);self.assertEqual(b['R2 button'],bool(expected));self.assertAlmostEqual(a['L2'],(.5-.02)/.98)
        self.a['R2']=.2;a,_,_=self.apply(armed=False);self.assertAlmostEqual(a['R2'],.2)
    def test_shot_shortcuts_follow_manual_hold_and_release(self):
        for kind,mods in [('finesse',{'R1'}),('chip',{'L1'}),('power',{'L1','R1'})]:
            with self.subTest(kind=kind):
                self.e.reset();self.p['advanced']['shortcuts']={k:'Disabled' for k in SHORTCUTS};self.p['advanced']['shortcuts'][kind]='Create'
                _,b,_=self.apply({'Create':True});self.assertTrue(b['Circle']);self.assertFalse(b['Create'])
                for key in ('L1','R1'):self.assertEqual(b[key],key in mods)
                _,b,_=self.apply({},10_000_000);self.assertFalse(b['Circle']);self.assertFalse(b['L1']);self.assertFalse(b['R1'])
    def test_tapped_run_follow_lock_are_bounded_without_repetition(self):
        for kind,expected in [('curved_run',{'L1','R1'}),('pass_follow',{'L1','R1','Cross'}),('player_lock',{'L3','R3'})]:
            with self.subTest(kind=kind):
                self.e.reset();self.p['advanced']['shortcuts']={k:'Disabled' for k in SHORTCUTS};self.p['advanced']['shortcuts'][kind]='Create'
                _,b,_=self.apply({'Create':True});self.assertEqual({k for k,v in b.items() if v},expected)
                _,b,_=self.apply({'Create':True},80_000_000);self.assertFalse(any(b.values()))
    def test_low_driven_single_followup_and_reset(self):
        self.p['advanced']['shortcuts']['low_driven']='Create'
        self.assertTrue(self.apply({'Create':True})[1]['Circle'])
        self.assertFalse(self.apply({},10_000_000)[1]['Circle'])
        self.assertTrue(self.apply({},90_000_000)[1]['Circle'])
        self.assertFalse(self.apply({},130_000_000)[1]['Circle'])
        self.assertFalse(self.apply({},140_000_000)[1]['Circle'])
        self.e.reset();self.assertFalse(self.apply({},0)[1]['Circle'])
    def test_sprint_hold_toggle_expiry_and_disarm(self):
        c=self.p['advanced'];c['shortcuts']['controlled_sprint']='Create'
        self.assertTrue(self.apply({'Create':True})[1]['R1']);self.assertFalse(self.apply({},10_000_000)[1]['R1'])
        c['sprint_toggle']=True;self.e.reset();self.apply({'Create':True})
        self.assertTrue(self.apply({},10_000_000)[1]['R1'])
        self.assertFalse(self.apply({'Create':True},20_000_000)[1]['R1'])
        self.e.reset();self.apply({'Create':True});self.assertFalse(self.apply({},10_000_000,False)[1]['R1'])
    def test_arming_held_shortcut_and_scheduler_gap_do_not_tap(self):
        self.p['advanced']['shortcuts']['curved_run']='Create';self.e.prime({'Create':True})
        self.assertFalse(self.apply({'Create':True})[1]['R1'])
        self.apply({},10_000_000);self.assertFalse(self.apply({'Create':True},300_000_000)[1]['R1'])
    def test_precision_clutch_changes_curve_without_shooting(self):
        self.p['advanced']['shortcuts']['precision_clutch']='Create'
        self.p['advanced']['contexts']['shoot']={'enabled':True,'exponent':2}
        a,b,context=self.apply({'Create':True});self.assertEqual(context,'shoot');self.assertAlmostEqual(a['LX'],.15);self.assertFalse(b['Circle']);self.assertFalse(b['Create'])
        a,b,context=self.apply({},10_000_000);self.assertEqual(context,'movement');self.assertAlmostEqual(a['LX'],.3)
    def test_invalid_conflicts_and_values_rejected(self):
        for mutate in [lambda c:c['shortcuts'].update(finesse='Create',chip='Create'),lambda c:c['shortcuts'].update(power='Circle'),lambda c:c['triggers']['L2'].update(press=.1,release=.2),lambda c:c['contexts']['shoot'].update(exponent=float('nan')),lambda c:c.update(defense_only_jockey='false')]:
            p=copy.deepcopy(self.p);mutate(p['advanced'])
            with self.assertRaises(ValueError):validate_profile(p)
        self.p['assists']['timed_shot']=True;self.p['advanced']['shortcuts']['power']='Create'
        with self.assertRaises(ValueError):validate_profile(self.p)

class AdvancedRuntime(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        with patch.object(lab,'DATA',Path(self.temp.name)):self.l=lab.Lab()
        self.l.status='Connected';self.sink=FakeBackend();self.l.output_factory=lambda:self.sink
    def test_jockey_gate_and_mode_change_neutralization(self):
        self.l.profile['assists']['auto_jockey']=True;self.l.profile['advanced']['defense_only_jockey']=True
        self.l.new_output('physical');self.l.arm_current();self.l.on_frame();self.assertEqual(self.sink.sent[-1].axes['L2'],0)
        self.l.runtime_action({'action':'defending_mode','enabled':True});self.assertEqual(self.sink.sent[-1].axes['L2'],1)
        self.l.runtime_action({'action':'defending_mode','enabled':False});self.assertEqual(self.sink.sent[-1].axes['L2'],0)
        self.l.runtime_action({'action':'disarm_assists'});self.assertFalse(self.sink.closed)
    def test_advanced_toggle_cleared_on_disarm_and_disconnect(self):
        self.l.profile['advanced']['shortcuts']['controlled_sprint']='Create';self.l.profile['advanced']['sprint_toggle']=True
        self.l.arm_current();self.l.buttons={'Create':True};self.l.on_frame();self.assertFalse(self.l.physical_frame.buttons['R1'])
        self.assertTrue(any(c.get('winner')=='Physical intent gate' for c in self.l.processing_pipeline.metadata['conflicts']))
        self.l.runtime_action({'action':'disarm_assists'});self.assertFalse(self.l.physical_frame.buttons['R1'])
        self.l.defending=True;self.l.disconnect_runtime('unplug');self.assertFalse(self.l.defending);self.assertEqual(self.l.advanced_engine.sprint_until,0)
    def test_comparison_summary_deduplicates_ticks_and_is_bounded(self):
        self.l.runtime_action({'action':'comparison_start','label':'A'});self.l.on_frame();self.l.on_frame()
        self.assertEqual(self.l.comparison['samples'],1)
        self.l.frames+=1;self.l.on_frame();self.l.runtime_action({'action':'comparison_stop'})
        self.assertEqual(self.l.comparison_results[0]['samples'],2);self.assertFalse(self.l.comparison_status()['active'])
    def test_config_change_stops_comparison(self):
        self.l.runtime_action({'action':'comparison_start','label':'A'});self.l.profile['deadzone']=.1;self.l.on_frame()
        self.assertIsNone(self.l.comparison);self.assertEqual(self.l.comparison_results[-1]['samples'],0)
    def test_delivery_test_rejects_modes_and_shortcuts(self):
        self.l.runtime_action({'action':'delivery_test_start','local_only':True})
        with self.assertRaises(ValueError):self.l.runtime_action({'action':'defending_mode','enabled':True})
        with self.assertRaises(ValueError):self.l.runtime_action({'action':'set_assist_enabled','key':'auto_jockey','enabled':True})

class SavedAdvancedProfiles(unittest.TestCase):
    setUp=AdvancedRuntime.setUp
    def test_save_load_preserves_advanced_and_disarms(self):
        cfg=copy.deepcopy(self.l.profile);cfg['advanced']['triggers']['L2']['enabled']=True;cfg['advanced']['contexts']['shoot']['exponent']=1.3
        with patch.object(lab,'DATA',self.l.data):
            self.l.action({'action':'save','name':'fixture','profile':cfg})
            self.l.arm_current();self.l.defending=True
            self.l.action({'action':'load','name':'fixture'})
        self.assertEqual(self.l.profile['advanced'],cfg['advanced']);self.assertFalse(self.l.assists_armed);self.assertFalse(self.l.defending)
    def test_clutch_schema_migrates_missing_binding_off(self):
        cfg=copy.deepcopy(self.l.profile);cfg['advanced']['shortcuts'].pop('precision_clutch')
        self.assertEqual(validate_profile(cfg)['advanced']['shortcuts']['precision_clutch'],'Disabled')
