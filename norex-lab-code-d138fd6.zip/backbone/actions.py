"""v2 local mutation API; all mutations are executed under the Lab lock."""
from copy import deepcopy
from .api_contract import ACTIONS,runtime_effective_payload,envelope
from .helper_contract import validate_config
from .skills import validate_recipe,validate_bindings


def act(r,body):
    from section_controls import check_action
    check_action(r,body.get('action'))
    if getattr(r,'command_center',False) and not r.master_enabled and body.get('action')!='emergency_stop':
        raise ValueError('Turn Custom + Chiaki ON before changing settings')
    if getattr(r,'command_center',False) and body.get('action')=='skill_run' and not r.master_enabled:
        raise ValueError('Turn virtual controller ON first')
    if not isinstance(body,dict) or body.get('action') not in ACTIONS:raise ValueError('Unknown v2 action')
    name=body['action'];declared=ACTIONS[name]
    required={key for key in declared if not key.endswith('?')}
    allowed={key.rstrip('?') for key in declared}|{'action'}
    if not required<=set(body) or set(body)-allowed:raise ValueError('Missing or unknown action fields')
    if name in ('profile_save','profile_load','configure','arm_assists','disarm_assists','emergency_stop'):
        legacy={**body,'action':{'profile_save':'save','profile_load':'load'}.get(name,name)}
        r.action(legacy)
    else:
        if r.replay or r.frame_rec or r.delivery_test_until or r.cal:
            raise ValueError('Stop replay, recording, calibration or delivery test before changing v2 settings')
        if name=='set_mode':
            r.set_processing_mode(body['mode'])
        elif name=='helpers_configure':
            p=deepcopy(r.profile);p['backbone_helpers']=validate_config(body['helpers']);r.apply_profile(p)
        elif name=='comparison_start':
            if r.status!='Connected':raise ValueError('Connect the controller first')
            r.compare_state.start(body['mode'],{'profile':deepcopy(r.profile),'armed':r.assists_armed,'custom_enabled':r.custom_enabled})
            r.set_processing_mode(body['mode'],finish_sample=False)
        elif name=='comparison_stop':r.compare_state.finish()
        elif name=='comparison_choose':
            if r.compare_state.active:raise ValueError('Finish the current sample first')
            if set(r.compare_state.samples)!= {'RAW','NOREX'} or any(row['frames']==0 for row in r.compare_state.samples.values()):
                raise ValueError('Capture both RAW and NOREX samples before choosing')
            r.compare_state.choose(body['winner'],body.get('notes',''))
        elif name in ('skill_recipe_save','skill_recipe_remove','skill_bindings'):
            if r.assists_armed and not getattr(r,'command_center',False):raise ValueError('Disarm helpers before editing local recipes or bindings')
            p=deepcopy(r.profile)
            if name=='skill_recipe_save':
                if body['local_only'] is not True:raise ValueError('Confirm local/single-player recipe use')
                p['backbone_skills']['recipes'][body['skill_id']]=validate_recipe(body['skill_id'],body['recipe'])
            elif name=='skill_recipe_remove':
                key=body['skill_id']
                if key not in p['backbone_skills']['recipes']:raise ValueError('Recipe not configured')
                if any(row['skill']==key for row in p['backbone_skills']['bindings']):raise ValueError('Remove its bindings first')
                del p['backbone_skills']['recipes'][key]
            else:
                if body['local_only'] is not True:raise ValueError('Confirm local/single-player binding use')
                p['backbone_skills']['bindings']=deepcopy(body['bindings'])
            r.apply_profile(p)
        elif name=='skill_run':
            if body['local_only'] is not True:raise ValueError('Confirm local/single-player recipe use')
            if not r.assists_armed or r.status!='Connected' or not r.custom_enabled or r.compare_state.mode=='RAW':
                raise ValueError('Connect and arm local helpers in NOREX mode first')
            row=r.profile['backbone_skills']['recipes'].get(body['skill_id'])
            if row is None:raise ValueError('Canonical recipe not configured; reference facts are not executable')
            from pipeline import normalized
            r.assist_engine.observe_movement(normalized(r.raw,r.bounds,r.default_inputs))
            r.assist_engine.start_recipe(body['skill_id'],row['steps'],__import__('time').monotonic_ns(),config=r.profile['assists'],relative=row.get('relative',False));r.on_frame()
    if getattr(r,'command_center',False) and r.master_enabled and not r.assists_armed:
        r.arm_current();r.on_frame()
    return envelope(ok=True,action=name,effective=runtime_effective_payload(r))
