"""FC27 reference facts with per-record provenance; never compiled into macros."""
from pathlib import Path
from copy import deepcopy
import json,re

SOURCES={
 'ea_gameplay':'https://www.ea.com/games/ea-sports-fc/fc-27/news/pitch-notes-fc27-gameplay-deep-dive',
 'skycoach_skills':'https://skycoach.gg/blog/ea-fc/articles/fc-27-skill-moves-guide',
 'driffle_controls':'https://driffle.com/blog/ea-fc-27-controls-guide-ps-xbox-pc/',
 'driffle_skills':'https://driffle.com/blog/all-ea-fc-27-skill-moves-and-controls-guide/',
}
SOURCE_METADATA={k:{'url':url,'publisher':'EA' if k=='ea_gameplay' else 'Skycoach' if k=='skycoach_skills' else 'Driffle',
    'kind':'PRIMARY' if k=='ea_gameplay' else 'COMMUNITY_GUIDE','checked_on':'2026-10-06',
    'supports':'Mechanics and explicitly named controls' if k=='ea_gameplay' else 'Reported control reference; game not verified'} for k,url in SOURCES.items()}
SOURCE_METADATA['research_20261010']={'kind':'COMMUNITY_GUIDE','checked_on':'2026-10-10','supports':'Per-record source URLs, conflicting inputs and carry-over references; no automatic recipes'}
FACING='Directions are relative to player facing; NOREX cannot infer on-screen facing.'
FACTS=json.loads(Path(__file__).with_name('catalog_facts.json').read_text())

def _id(name):return re.sub('[^a-z0-9]+','_',name.lower()).strip('_')
def _display(value):
    if value is None:return None
    text=value
    for a,b in [('■','Square'),('▢','Square'),('○','Circle'),('◯','Circle'),('△','Triangle')]:text=text.replace(a,b)
    text=re.sub(r'\bX\b','Cross',text)
    text=re.sub(r'\bR\b','RS',text);text=re.sub(r'\bL\b','LS',text)
    return text

def _skill(row,kind='normal'):
    name=row['name'];input_value=row['ps'];tba=input_value is None
    # Keep source ambiguity visible; a guide's text cannot supply timing or facing.
    notes=[FACING,'No sourced millisecond timing; no automatic recipe is derived.']
    if row['differences']:notes.append('Sources disagree: '+str(row['differences']))
    if name=='Stutter Feint':notes.append('Reported fake-shot sequence is incomplete; requires in-game control confirmation.')
    context='Juggling; exact player-rating requirement differs between guides' if kind=='juggling' else 'Standing' if 'standing' in name else 'Running' if 'running' in name else 'Context not specified by source'
    return {'id':('juggling_' if kind=='juggling' else '')+_id(name),'name':name,'stars':row['stars'],
        'kind':kind,'status':'FC27_REPORTED','ps5_input':_display(input_value),'xbox_input':row['xbox'],
        'input_status':'TBA' if tba else 'AMBIGUOUS' if row['differences'] or name=='Stutter Feint' else 'reported',
        'context':context,'direction_reference':'PLAYER_FACING','playstyle_dependency':None,
        'playstyle_dependency_status':'NOT_ESTABLISHED','recipe':None,'recipe_status':'Recipe not configured',
        'executable':False,'shortcut':None,'verification':{'source':'partial' if tba else 'cross_reported' if row['corroborated'] else 'single_reported','implementation':'not_tested','game':'not_tested'},
        'sources':[SOURCES['skycoach_skills']]+([SOURCES['driffle_skills']] if row['corroborated'] or row['differences'] else []),
        'provenance':{'primary':'skycoach_skills','section':f"{row['stars']}-star skills" if kind=='normal' else 'Juggling tricks','checked_on':'2026-10-06','reported_input':input_value,'source_differences':row['differences']},
        'notes':' '.join(notes)}
SKILLS=[_skill(row) for row in FACTS['skills']]
JUGGLING=[_skill(row,'juggling') for row in FACTS['juggling']]
RESEARCH=json.loads(Path(__file__).with_name('skill_research.json').read_text())
ALL_SKILLS=SKILLS+JUGGLING+RESEARCH
# Stable IDs are preserved. Conflicting reports never silently rewrite controls.
kneel=next(r for r in ALL_SKILLS if r['id']=='kneel_header')
kneel.update(kind='trickster',playstyle_dependency='Trickster',playstyle_dependency_status='REPORTED',
 input_status='AMBIGUOUS',ps5_input='Reports differ: L2 + R1 + RS forward / L2 + R2 + RS forward',
 rating_alternatives=[1],context='Standing with ball at feet')
kneel['sources']+=[r for r in [RESEARCH[0]['sources'][0], 'https://dotesports.com/ea-sports-fc/guides/ea-sports-fc-27-skills'] if r not in kneel['sources']]
kneel['notes']+=' New research: sources disagree on one/five stars and R1/R2. Grouped under Trickster; executable input remains blocked.'
for row in ALL_SKILLS:
 if row['id']=='quick_ball_rolls':
  row['rating_alternatives']=[2];row['notes']+=' Some newer guides place this at two stars; existing four-star metadata retained.'
 if row['id']=='stepover_combo':
  row['rating_alternatives']=[5];row['notes']+=' Newer sources place this at five stars; conservative display group is five.'
 row['display_group']='trickster' if row.get('playstyle_dependency') else str(max([row['stars']]+row.get('rating_alternatives',[]))) if row.get('stars') else '5'
 row['rating_unconfirmed']=row.get('stars') is None

for key,command,note in [
 ('fake_turn','Fake shot + LS opposite direction while jogging','Newer guides supply an input; earlier sources had TBA. Exact sequence remains ambiguous.'),
 ('ball_roll_spin','Hold RS direction then flick forward','Sources differ on whether L1 is required.'),
 ('stepover_combo','Hold L2 + RS forward / chain stepovers','Sources disagree on the sequence and four/five-star rating.')]:
 row=next(r for r in ALL_SKILLS if r['id']==key)
 row.update(input_status='AMBIGUOUS',ps5_input=command)
 row['sources']+=['https://www.fifplay.com/fc-27-skill-moves/','https://games.gg/ea-sports-fc-27/guides/ea-fc-27-skill-moves-complete-guide/']
 row['notes']+=' '+note
SKILL_BY_ID={r['id']:r for r in ALL_SKILLS}
SIMPLIFIED_SKILLS=[]
for rating,forward,sides,back in FACTS['simplified']:
    for direction,name in [('forward',forward),('left_or_right',sides),('back',back)]:
        SIMPLIFIED_SKILLS.append({'id':_id(rating+' '+direction),'name':name,'stars':rating,
            'ps5_input':'RS flick '+direction,'direction_reference':'PLAYER_FACING',
            'requires':'Simplified Skill Moves enabled in game; mode availability not established by this source',
            'selection':'Game selects the contextual move from player rating; Lab cannot choose or detect it.',
            'sources':[SOURCES['skycoach_skills']],'input_status':'reported','recipe':None,'executable':False,
            'verification':{'source':'single_reported','implementation':'not_tested','game':'not_tested'}})
CONTROLS={}
for row in FACTS['controls']:
    key=_id(row['context']+' '+row['name'])
    CONTROLS[key]={'id':key,'name':row['name'],'category':row['context'],'context':row['context'],
        'ps5_input':_display(row['ps']),'xbox_input':row['xbox'],'source':SOURCES['driffle_controls'],
        'sources':[SOURCES['driffle_controls']],'input_status':'reported','executable':False,'recipe':None,
        'verification':{'source':'single_reported','implementation':'not_tested','game':'not_tested'},
        'provenance':{'primary':'driffle_controls','section':row['context'],'checked_on':'2026-10-06'},
        'notes':'Default game layout only; verify in-game controls. Touchpad has no supported Lab output channel.'}
# Preserve existing stable IDs while keeping the complete context-specific table.
_ALIASES={'ground_pass':'attacking_ground_pass_header','through_pass':'attacking_through_pass',
 'cross':'attacking_lob_pass_cross_header','shoot':'attacking_shoot_volley_header',
 'finesse_shot':'attacking_finesse_shot','power_shot':'attacking_power_shot','chip_shot':'attacking_chip_shot',
 'low_driven_shot':'attacking_low_driven_shot','low_driven_finesse':'attacking_low_driven_finesse_shot',
 'low_driven_power':'attacking_low_driven_power_shot','fake_shot':'attacking_fake_shot','fake_pass':'attacking_fake_pass',
 'driven_through_pass':'attacking_driven_through_pass','driven_ground_pass':'advanced_attacking_driven_ground_pass',
 'lofted_ground_pass':'advanced_attacking_lofted_ground_pass','lofted_through_pass':'advanced_attacking_lofted_through_pass',
 'lobbed_through_pass':'advanced_attacking_lobbed_through_pass','driven_cross':'advanced_attacking_driven_lob_pass_driven_cross',
 'ground_cross':'advanced_attacking_ground_cross','controlled_sprint':'movement_controlled_sprint',
 'strafe_dribble':'movement_strafe_dribble','sprint':'movement_sprint','jockey':'movement_shield_jockey',
 'sprint_jockey':'defending_sprint_jockey'}
for alias,key in _ALIASES.items():
    row=deepcopy(CONTROLS[key]);row.update(id=alias,alias_of=key);CONTROLS[alias]=row
CONTROLS['sprint_jockey']['ps5_input']='L2 + R2'
for key,name,command,context in [
 ('corner_avoidance','Corner Avoidance','Hold R1','Corner delivery positioning window'),
 ('triggered_curved_run','Triggered Curved Run','Tap L1 + R1','Attacking'),
 ('pass_follow','Pass & Follow Run','L1 + R1 + Cross','Attacking')]:
    CONTROLS[key]={'id':key,'name':name,'category':'New FC27','context':context,'ps5_input':command,
        'source':SOURCES['ea_gameplay'],'sources':[SOURCES['ea_gameplay']],'input_status':'official',
        'recipe':None,'executable':False,'verification':{'source':'primary','implementation':'not_tested','game':'not_tested'},
        'provenance':{'primary':'ea_gameplay','section':name,'checked_on':'2026-10-06'}}
COMBOS=[{'id':r['id'],'name':r['name'],'ps5_input':r['ps5_input'],'context':r['context'],
         'sources':r['sources'],'input_status':r['input_status'],'executable':False,'recipe':None,
         'timing_status':'No sourced millisecond timing','verification':deepcopy(r['verification'])}
        for r in CONTROLS.values() if 'alias_of' not in r and any(token in r['ps5_input'] for token in (' + ',' then '))]
MECHANICS={}
for key,summary,section in [
 ('manual_control','EA emphasizes deliberate manual defending and attacking control.','Gameplay'),
 ('through_passes','Through passes track directional input; controller processing cannot select teammates.','Through Passes Update'),
 ('crossing','Cross direction and power determine delivery into space.','Crossing Rework'),
 ('manual_defending','Manual jockeying and tackles are emphasized; Lab cannot detect defending.','Manual Defending Improvements'),
 ('dinked_passes','Dinked ground and through passes use manual aim and power.','Dinked Passes Update'),
 ('off_balance_dribbling','Off-balance dribbling depends on Balance, Agility and Dribbling attributes; no controller setting raises them.','Off-Balance Dribbling'),
 ('corner_positioning','Move and shield manually during the corner delivery window.','Corner Kick Improvements'),
 ('limited_runs','Manually triggered runs cover a limited distance; Lab cannot detect when a run ends.','Limited Distance for Manually Triggered Runs'),
 ('playstyles_attributes','PlayStyles and core attributes determine game behavior; controller input cannot assign them.','PlayStyles and Attributes')]:
    MECHANICS[key]={'summary':summary,'source':SOURCES['ea_gameplay'],'section':section,
        'verification':'PRIMARY_REPORTED_GAME_UNVERIFIED','checked_on':'2026-10-06','executable':False}
MECHANICS['attributes']={'summary':'Controller processing cannot raise player attributes.','source':None,'basis':'Controller-side scope; not an EA claim','verification':'LOCAL_SCOPE_LIMITATION','executable':False}
CATALOG_NOTES=['Tables contain 73 established normal moves plus four TBA new moves (77 records), and nine juggling records. The Driffle FAQ counts 73 plus nine while listing the new names separately; source counts must not be mistaken for verified in-game completeness.',
 'Juggling rating differs: Skycoach calls the group five-star; Driffle says not tied to a rating. Individual requirement remains unknown.',
 'Reference inputs are human-readable facts; no exact timing or inferred facing is executable.',
 'Legacy Lab templates remain separate and explicitly unverified.',
 'Research on 2026-10-10 adds 29 missing reference entries, including Trickster families. Counts include directional variants and carry-over/disputed references; this is not a verified in-game total.']

def search_skills(query='',stars=None,status=None,kind=None):
    rows=ALL_SKILLS
    if stars is not None:
        if type(stars) is not int or stars not in range(1,6):raise ValueError('stars must be 1–5')
        rows=[r for r in rows if r['stars']==stars]
    if status is not None:
        if status not in ('TBA','reported','AMBIGUOUS'):raise ValueError('Unknown input status')
        rows=[r for r in rows if r['input_status']==status]
    if kind is not None:
        if kind not in ('normal','juggling','trickster'):raise ValueError('Unknown skill kind')
        rows=[r for r in rows if r['kind']==kind]
    if not isinstance(query,str) or len(query)>200:raise ValueError('Invalid search query')
    return deepcopy([r for r in rows if query.casefold() in (r['name']+' '+r['notes']).casefold()])
