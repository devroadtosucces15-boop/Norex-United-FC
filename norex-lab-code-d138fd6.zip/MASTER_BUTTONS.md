# Master buttons — operator guide and verification

Installed on ME2001, 2026-10-11 (America/Phoenix).

Open **NOREX Network Console** or **NOREX Controller Lab** from the application menu. Direct addresses: http://127.0.0.1:8790/network and http://127.0.0.1:8790/lab.

1. For Controller Lab, connect the DualSense to Kali, preferably with USB, and turn on the registered PS5. Click **Controller + Remote Play: OFF** to turn it ON. Your saved controller setup returns, one managed service starts, and one owned Chiaki session opens. A missing controller/console produces a message and returns OFF.
2. For Network Console, click **Network Console: OFF**. One managed service starts and restores your saved network preferences. Save preferences while ON. Automatic trials still honor measured-speed requirements and match protections.
3. Click the same button again for OFF. The other tool keeps its own state. Controller OFF destroys the virtual controller and closes its own Remote Play session. Network OFF stops packet readers/captures and returns the tool-owned queue/VPN changes to normal.
4. Refresh or open another tab freely. Tabs share server state. The control page stays available while the tool services are stopped. A control-page restart may require a browser reload before changing settings again.
5. If a controller/session stops or disconnects, the Lab stops safely. Reconnect the controller, wake the PS5, and click ON. Network worker crashes recover automatically. After turning Controller Lab OFF, press PS if you want direct console control; automatic Bluetooth reconnection is not guaranteed.

## Results observed on the actual machine

| Check | Result |
|---|---|
| Network UI ON/OFF | Passed; actual service active/inactive, top button updates |
| Controller UI ON/OFF | Repeated live ON/OFF operations passed; DualSense connected, uinput output active and owned Chiaki running; OFF removed virtual device and owned Chiaki |
| Tool independence | Passed; Network OFF left live Controller running; Controller OFF left Network running |
| Network refresh and two tabs | Passed; second tab showed ON, first tab received OFF, refresh retained OFF |
| Controller refresh and two tabs | Passed for shared OFF state after the verified live cycle |
| Four concurrent ON requests, each tool | Passed for both Network and Controller; each retained its existing service MainPID |
| Network saved settings across OFF/ON | Passed; temporary 123/45 Mbps restored, then original preferences restored |
| Network supervisor forced crash | Passed; a new single supervisor recovered and saved preferences returned |
| Controller ON without physical device | Passed twice; explicit error, service stopped, no virtual device/session left |
| Controller service crash during startup while output OFF | Passed; control page remained available and reported OFF |
| Controller forced crash while output and Chiaki were active | Passed; master became OFF, owned Chiaki terminated and the virtual device disappeared |
| Controller ON retry after active-output crash | Correctly failed OFF because the physical DualSense had disconnected from Kali; reconnect it before clicking ON |
| Owned-process isolation | Actual unrelated test process survived Network OFF/crash; Controller unit tests separately verify only its owned child is closed |
| Controller disk persistence | Automated tests passed for a new runtime, repeated OFF and disabled-section restoration |
| Local Python regression suite | 274 tests plus 63 subtests passed |
| Existing browser-interaction regression checks | Both Controller and Network checks passed |
| PS5 / FC27 receipt | Unverified; local output and a running Chiaki process do not prove console/game receipt |

Final state: both managed tool services OFF; the local master control service remains active. Network default queue/policy state was checked: ordinary `fq_codel` on eth0 and only the standard local/main/default policy routing rules. Saved profiles, history and original network preferences are retained.

## Services and recovery

- Always-available local page: `norex-master-portal.service`.
- Controller work and owned Remote Play: `norex-controller-managed.service`.
- Network work and owned broker/captures: `norex-network-managed.service`.
- Historical combined service name `norex-center.service` aliases the control page. Previous Gateway and user-controller units remain masked.

The engines are separate services so either button can stop its entire owned process group while keeping the other tool and the control page reachable. One managed service per button does not mean one operating-system process: its owned helpers are contained within that service.

Controller setup: `data/master-saved.json` (atomic complete snapshot). Network saved preferences and inactive-page state: root-private `/var/lib/norex-master/state.json`. Named profile archives and Gateway history remain at their existing paths.

The source and old combined unit are backed up in `work/master-20261011/`. Restore those files and the old unit only after stopping the two managed engines and control page; do not enable the old combined worker alongside this installation.
