import tempfile,unittest,json
from pathlib import Path
from unittest.mock import patch
from assists import AssistEngine,defaults,validate
from pipeline import neutral_frame,validate_profile,default_profile
from skills import seeds,validate_recipe,SkillLibrary,CATALOG
import lab

class AssistTests(unittest.TestCase):
 def setUp(self):
  self.e=AssistEngine();self.c=defaults(); f=neutral_frame();self.a=f.axes;self.b=f.buttons;self.recipes=seeds()
 def apply(self,ms): return self.e.apply(self.a,self.b,self.c,int(ms*1e6),self.recipes)
 def test_timed_pass_releases_while_physical_held_and_does_not_repeat(self):
  self.c['timed_pass']=True;self.b['Cross']=True
  self.assertTrue(self.apply(1000)[1]['Cross']);self.assertTrue(self.apply(1100)[1]['Cross']);self.assertFalse(self.apply(1210)[1]['Cross'])
  self.assertFalse(self.apply(1250)[1]['Cross']);self.b['Cross']=False;self.apply(1300);self.b['Cross']=True;self.assertTrue(self.apply(1350)[1]['Cross'])
 def test_low_followup_one_tap_and_chip_exclusion(self):
  self.c.update(timed_shot=True,perfect_lowdrive=True);self.b['Circle']=True;self.apply(1000)
  self.b['Circle']=False;self.assertTrue(self.apply(1100)[1]['Circle']);self.assertFalse(self.apply(1155)[1]['Circle'])
  self.assertTrue(self.apply(1235)[1]['Circle']);self.assertFalse(self.apply(1290)[1]['Circle']);self.assertIsNone(self.e.followup)
  self.e.reset();self.b['L1']=True;self.b['Circle']=True;self.apply(2000);self.b['Circle']=False;self.apply(2160);self.assertIsNone(self.e.followup)
 def test_modifiers_and_sprint(self):
  self.c.update(auto_jockey=True,fast_dribble=True,precision_pass=True,perfect_sprint=True,sprint_strength=60)
  self.a['LX']=.5;a,b=self.apply(1000);self.assertEqual(a['L2'],1);self.assertTrue(b['R1'])
  self.b['Cross']=True;a,b=self.apply(1010);self.assertEqual(a['L2'],0);self.assertTrue(b['R1'])
  self.b['Cross']=False;self.a['R2']=1;a,b=self.apply(1020);self.assertEqual(a['R2'],.6);self.assertFalse(b['R1'])
 def test_power_aim_and_speed_boost(self):
  self.c.update(auto_power_shot=True,aim_angle=90,speed_boost=True);self.b['Circle']=True
  a,b=self.apply(1000);self.assertTrue(b['L1'] and b['R1']);self.assertAlmostEqual(a['LY'],1)
  self.b['Circle']=False;self.a['R2']=1;self.a['LX']=1;a,b=self.apply(1010);self.assertEqual(a['RX'],1)
  a,b=self.apply(1110);self.assertEqual(a['RX'],0)
 def test_skill_flick_latches_and_requires_recipe(self):
  self.c['skills']['left']='Ball Roll Left';self.a['RX']=-1
  self.apply(1000);self.assertEqual(self.e.recipe_name,'Ball Roll Left');self.apply(1100);self.apply(1275);self.assertIsNone(self.e.active_recipe)
  self.apply(1300);self.assertIsNone(self.e.active_recipe)
  self.a['RX']=0;self.apply(1310);self.a['RX']=-1;self.apply(1320);self.assertIsNotNone(self.e.active_recipe)
 def test_recipe_completion_restores_held_physical_controls(self):
  self.a['RX']=.4;self.b['R1']=True
  self.e.start_recipe('release',[{'ms':50,'axes':{'RX':-1},'buttons':{'R1':False}}],1_000_000_000,config=self.c,relative=False)
  self.assertEqual(self.apply(1000)[0]['RX'],-1)
  a,b=self.apply(1050)
  self.assertEqual(a['RX'],.4);self.assertTrue(b['R1'])
  self.assertIsNone(self.e.recipe_name)
 def test_recipe_completion_releases_synthetic_controls_for_many_frames(self):
  self.e.start_recipe('release',[{'ms':50,'axes':{'L2':1,'RX':-1},'buttons':{'R1':True}}],1_000_000_000,config=self.c,relative=False)
  self.assertTrue(self.apply(1000)[1]['R1'])
  for ms in range(1050,1500,10):
   a,b=self.apply(ms)
   self.assertEqual(a['L2'],0);self.assertEqual(a['RX'],0);self.assertFalse(b['R1'])
 def test_scheduler_gap_clears_recipe_identity(self):
  self.e.start_recipe('release',[{'ms':500,'axes':{'RX':1},'buttons':{}}],1_000_000_000,config=self.c,relative=False)
  self.apply(1000);a,b=self.apply(1300)
  self.assertIsNone(self.e.active_recipe);self.assertIsNone(self.e.recipe_name)
  self.assertEqual(a['RX'],0)
 def test_scheduler_gap_cancels_pending_actions(self):
  self.c['timed_pass']=True;self.b['Cross']=True;self.apply(1000);self.apply(2000)
  self.assertFalse(self.e.timers);self.assertIn('cancelled',self.e.message)
 def test_all_seeded_recipes_valid_and_missing_slots_truthful(self):
  self.assertEqual(len(self.recipes),len(CATALOG))
  for name,row in self.recipes.items():
   if row['steps']: validate_recipe(row)
   else:self.assertEqual(row['status'],'Recipe required')
  bad={'name':'Ball Roll Left','relative':True,'steps':[{'ms':100,'axes':{'RX':2},'buttons':{}}]}
  with self.assertRaises(ValueError):validate_recipe(bad)
 def test_recipe_provenance_survives_restart(self):
  with tempfile.TemporaryDirectory() as d:
   l=SkillLibrary(Path(d)); l2=SkillLibrary(Path(d));self.assertTrue(any(w in l2.recipes['Ball Roll Left']['status'] for w in ('Training template','Menu-notation recipe')))
 def test_import_recorded_recipe(self):
  from types import SimpleNamespace
  from pipeline import ControllerFrame
  with tempfile.TemporaryDirectory() as d:
   library=SkillLibrary(Path(d));a=dict(self.a);a['RX']=-1
   frames=[neutral_frame(0),ControllerFrame(50_000_000,a,dict(self.b)),neutral_frame(250_000_000)]
   row=library.from_capture('Ball Roll Left',SimpleNamespace(frames=frames),0,250)
   self.assertFalse(row['relative']);self.assertEqual(row['steps'][1]['axes']['RX'],-1)
   self.assertEqual(sum(s['ms'] for s in row['steps']),250)
 def test_arm_held_controls_does_not_create_flick_or_boost(self):
  self.c['speed_boost']=True;self.c['skills']['left']='Ball Roll Left';self.a['RX']=-1;self.a['R2']=1;self.a['LX']=1
  self.e.prime(self.b,self.a);self.apply(1000)
  self.assertIsNone(self.e.boost);self.assertIsNone(self.e.active_recipe)
 def test_profile_settings_validation(self):
  p=default_profile();p['assists']['shot_ms']=1000
  with self.assertRaises(ValueError):validate_profile(p)
  p=default_profile();p['assists']['flex']['up']='Elastico'
  with self.assertRaises(ValueError):validate_profile(p)
 def test_runtime_arm_is_session_only_and_emergency_stop_disarms(self):
  with tempfile.TemporaryDirectory() as d,patch.object(lab,'DATA',Path(d)):
   l=lab.Lab();l.status='Connected'
   with self.assertRaises(ValueError):l.action({'action':'arm_assists'})
   l.action({'action':'arm_assists','local_only':True});self.assertTrue(l.assists_armed)
   l.action({'action':'emergency_stop'});self.assertFalse(l.assists_armed);self.assertIsNone(l.assist_engine.active_recipe)
   l2=lab.Lab();self.assertFalse(l2.assists_armed)
 def test_button_slot_consumes_trigger_and_latches(self):
  self.c['button_skills']['1']={'button':'Create','skill':'Ball Roll Left'};self.b['Create']=True
  a,b=self.apply(1000);self.assertFalse(b['Create']);self.assertEqual(a['RX'],-1)
  self.apply(1100);self.apply(1275);self.apply(1300);self.assertIsNone(self.e.active_recipe)
  self.b['Create']=False;self.apply(1310);self.b['Create']=True;self.apply(1320);self.assertIsNotNone(self.e.active_recipe)
 def test_player_lock_releases_and_does_not_repeat_on_hold(self):
  self.c['lock_button']='Create';self.b['Create']=True
  a,b=self.apply(1000);self.assertTrue(b['L3'] and b['R3']);self.assertFalse(b['Create'])
  self.assertFalse(self.apply(1090)[1]['L3']);self.assertFalse(self.apply(1120)[1]['R3'])
 def test_finesse_followup_and_conflicts(self):
  self.c.update(finesse_finish=True,timed_shot=True);self.b['Circle']=True;self.b['R1']=True
  self.assertTrue(self.apply(1000)[1]['R1']);self.b['Circle']=False;self.apply(1100);self.apply(1160)
  self.assertFalse(self.apply(1300)[1]['Circle']);b=self.apply(1340)[1];self.assertTrue(b['Circle'] and b['R1'])
  self.assertFalse(self.apply(1390)[1]['Circle']);self.c['low_driven']=True;self.c['auto_power_shot']=True;validate(self.c)
  self.e.reset();self.b['Circle']=True;b=self.apply(2000)[1];self.assertTrue(b['R1']);self.assertFalse(b['L1']);self.assertFalse(self.e.low_pending)
 def test_duplicate_button_triggers_rejected(self):
  self.c['button_skills']['1']={'button':'Create','skill':'Ball Roll Left'};self.c['lock_button']='Create'
  with self.assertRaises(ValueError):validate(self.c)
 def test_apply_preserves_arm_and_composes_remap_curve_with_assists(self):
  with tempfile.TemporaryDirectory() as d,patch.object(lab,'DATA',Path(d)):
   l=lab.Lab();l.status='Connected';p=default_profile();p['assists']['timed_pass']=True;p['button_map']['Square']='Cross'
   l.action({'action':'arm_assists','local_only':True,'profile':p});self.assertTrue(l.assists_armed)
   p['curves']['left']['kind']='power';p['curves']['left']['exponent']=2
   l.action({'action':'configure','profile':p});self.assertTrue(l.assists_armed);self.assertEqual(l.profile['curves']['left']['exponent'],2)
   l.buttons['Square']=True;l.on_frame();self.assertFalse(l.physical_frame.buttons['Cross']);self.assertTrue(l.physical_frame.buttons['Square'])
   l.action({'action':'save','name':'fc27','profile':p});self.assertTrue(l.assists_armed)
 def test_startup_arm_once_and_emergency_stop_stays_off(self):
  with tempfile.TemporaryDirectory() as d,patch.object(lab,'DATA',Path(d)):
   p=default_profile();p['arm_on_startup']=True;(Path(d)/'profile-fc27.json').write_text(json.dumps(p))
   l=lab.Lab();l.status='Connected';l.first_connection();self.assertTrue(l.assists_armed)
   l.action({'action':'emergency_stop'});l.first_connection();self.assertFalse(l.assists_armed)
if __name__=='__main__' :unittest.main()
