import unittest
from tools.chiaki_touchpad_mapping import touchpad_only

class TouchpadMappingTests(unittest.TestCase):
 def test_physical_mapping_cannot_duplicate_gamepad_controls(self):
  original='0300abcd,PS5 Controller,a:b0,b:b1,guide:b5,leftx:a0,righttrigger:a5,touchpad:b11,misc1:b12,crc:abcd,platform:Linux,'
  result=touchpad_only(original)
  self.assertEqual(result,'0300abcd,NOREX DualSense Touchpad Only,touchpad:b11,crc:abcd,platform:Linux,')
  self.assertNotIn('leftx:',result);self.assertNotIn('guide:',result)
 def test_evdev_without_native_touchpad_is_rejected(self):
  with self.assertRaises(ValueError):touchpad_only('guid,PS5 Controller,a:b0,platform:Linux,')
 def test_malformed_mapping_is_rejected(self):
  with self.assertRaises(ValueError):touchpad_only('broken')
