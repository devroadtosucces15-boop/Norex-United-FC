import copy,tempfile,unittest,json,time,threading,math
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
import lab
from pipeline import neutral_frame,ControllerFrame
from backbone.actions import act
from backbone.api_contract import runtime_effective_payload
from output_backend import OutputBackend

ROOT=Path(__file__).parent
class Sink(OutputBackend):
    backend_id='test';destination='memory';transport='test'
    def __init__(self):self.frames=[];self.closed=False
    def emit(self,frame):self.frames.append(copy.deepcopy(frame))
    def neutralize(self):self.frames.append(neutral_frame())
    def close(self):self.neutralize();self.closed=True

class RuntimeV2Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'work');self.addCleanup(self.tmp.cleanup)
        with patch.object(lab,'DATA',Path(self.tmp.name)):self.r=lab.Lab()
        self.r.status='Connected';self.r.raw={'LX':.4,'LY':0,'L2':0,'RX':0,'RY':0,'R2':0,'DX':0,'DY':0}
        self.r.bounds={k:[-1,1] if k in ('LX','LY','RX','RY','DX','DY') else [0,1] for k in self.r.raw}
        self.r.buttons=copy.deepcopy(neutral_frame().buttons)
    def action(self,**body):return act(self.r,body)
    def test_raw_bypasses_calibration_remaps_helpers_and_sequences(self):
        p=copy.deepcopy(self.r.profile);p['centers']['LX']=.2;p['ranges']['LX']=[-1,1];p['curves']['left']['kind']='power';p['curves']['left']['exponent']=3;p['button_map']['Cross']='Circle'
        p['backbone_helpers']['precision_stick']['enabled']=True;p['assists']['auto_jockey']=True
        self.r.apply_profile(p);self.r.arm_current();self.r.buttons['Cross']=True;self.r.on_frame()
        self.assertNotEqual(self.r.physical_frame.axes['LX'],.4)
        before=copy.deepcopy(self.r.profile)
        self.action(action='set_mode',mode='RAW')
        self.assertEqual(self.r.physical_frame.axes['LX'],.4);self.assertTrue(self.r.physical_frame.buttons['Cross']);self.assertFalse(self.r.physical_frame.buttons['Circle'])
        self.assertEqual(self.r.physical_frame.axes['L2'],0);self.assertEqual(self.r.profile,before)
        self.action(action='set_mode',mode='NOREX');self.assertNotEqual(self.r.physical_frame.axes['LX'],.4)
    def test_physical_escape_cancels_generated_input_and_no_retrigger(self):
        self.r.profile['assists']['auto_jockey']=True;self.r.arm_current()
        self.r.assist_engine.start_recipe('Elastico',[{'ms':500,'axes':{'RX':1},'buttons':{'Circle':True}}],time.monotonic_ns())
        self.r.buttons.update(L1=True,R1=True);self.r.raw.update(L2=1,R2=1);self.r.on_frame()
        f=self.r.physical_frame;self.assertEqual(f.axes['RX'],0);self.assertEqual(f.axes['L2'],1);self.assertFalse(f.buttons['Circle'])
        self.assertIsNone(self.r.assist_engine.active_recipe);self.assertTrue(self.r.processing_pipeline.metadata['physical_escape'])
        self.r.raw.update(L2=0,R2=0);self.r.buttons.update(L1=False,R1=False);self.r.on_frame()
        self.assertIsNone(self.r.assist_engine.active_recipe)
    def test_manual_priority_beats_recipe_and_restores_trigger_channels(self):
        self.r.arm_current();self.r.assist_engine.start_recipe('Elastico',[{'ms':500,'axes':{'L2':1},'buttons':{'Circle':False,'R1':True}}],time.monotonic_ns())
        self.r.buttons['Circle']=True;self.r.on_frame()
        self.assertTrue(self.r.physical_frame.buttons['Circle']);self.assertFalse(self.r.physical_frame.buttons['R1']);self.assertEqual(self.r.physical_frame.axes['L2'],0)
        self.assertIsNone(self.r.assist_engine.active_recipe)
    def test_v2_helpers_applied_once_and_physical_modifier_required(self):
        p=copy.deepcopy(self.r.profile);p['helpers']['contexts']['controlled_dribble'].update(enabled=True,exponent=2)
        p['backbone_helpers']['controlled_dribble_response'].update(enabled=True,exponent=2,strength=100)
        # New duplicate selections are rejected globally; previously stored
        # duplicates retain deterministic v2 ownership during migration.
        with self.assertRaisesRegex(ValueError,'Global conflict'):self.r.apply_profile(p)
        self.r.profile=copy.deepcopy(p)
        self.r.arm_current();self.r.buttons['R1']=True;self.r.on_frame()
        # legacy calibrated deadzone remains; v2 shapes only once.
        base=(.4-.08)/.92;self.assertAlmostEqual(self.r.physical_frame.axes['LX'],base**2)
        self.assertTrue(any(c.get('winner')=='controlled_dribble_response' for c in self.r.processing_pipeline.metadata['conflicts']))
        self.r.buttons['R1']=False;self.r.profile['assists']['fast_dribble']=True;self.r.on_frame()
        self.assertAlmostEqual(self.r.physical_frame.axes['LX'],base);self.assertFalse(self.r.physical_frame.buttons['R1'])
        self.r.buttons['R1']=True;self.r.on_frame()
        self.assertAlmostEqual(self.r.physical_frame.axes['LX'],base**2)
    def test_output_status_only_acknowledges_actual_local_emit(self):
        sink=Sink();self.r.output_factory=lambda:sink;self.r.new_output('physical')
        before=runtime_effective_payload(self.r);self.assertFalse(before['output']['local_write_acknowledged'])
        self.r.on_frame();state=runtime_effective_payload(self.r)
        self.assertTrue(state['output']['local_write_acknowledged']);self.assertEqual(state['output']['ps5_receipt'],'UNVERIFIED');self.assertEqual(state['output']['game_receipt'],'UNVERIFIED')
        self.assertEqual(sink.frames[-1],self.r.physical_frame)
        self.r.close_output();self.assertFalse(runtime_effective_payload(self.r)['output']['local_write_acknowledged'])
    def test_disconnect_clears_filters_sequences_sample_and_output(self):
        self.r.profile['backbone_helpers']['smoothing']['enabled']=True;self.r.arm_current();self.r.on_frame()
        self.action(action='comparison_start',mode='NOREX');sink=Sink();self.r.output_factory=lambda:sink;self.r.new_output('physical')
        self.r.disconnect_runtime('test unplug')
        self.assertFalse(self.r.assists_armed);self.assertIsNone(self.r.output);self.assertTrue(sink.closed)
        self.assertIsNone(self.r.processing_pipeline.engine.previous);self.assertIsNone(self.r.compare_state.active)
        self.assertFalse(any(self.r.physical_frame.buttons.values()))
        self.r.first_connection();self.assertFalse(self.r.assists_armed)
    def test_raw_norex_pair_keeps_identical_configuration(self):
        self.r.arm_current();profile=copy.deepcopy(self.r.profile)
        self.action(action='comparison_start',mode='RAW');self.r.frames+=1;self.r.on_frame();self.action(action='comparison_stop')
        self.action(action='comparison_start',mode='NOREX');self.r.frames+=1;self.r.on_frame();self.action(action='comparison_stop')
        result=self.action(action='comparison_choose',winner='CANNOT_TELL',notes='Local test')
        samples=result['effective']['comparison']['results'][-1]['samples']
        self.assertEqual(set(samples),{'RAW','NOREX'});self.assertEqual(samples['RAW']['configuration'],samples['NOREX']['configuration']);self.assertEqual(self.r.profile,profile)
    def test_comparison_rejects_result_without_two_samples(self):
        with self.assertRaises(ValueError):self.action(action='comparison_choose',winner='RAW')
    def test_failed_action_no_mutation(self):
        before=copy.deepcopy(self.r.profile)
        with self.assertRaises(ValueError):self.action(action='helpers_configure',helpers={'precision_stick':{'enabled':True,'strength':float('nan')}})
        self.assertEqual(self.r.profile,before)
        for mode in ('UNKNOWN',None,1):
            with self.assertRaises(ValueError):self.action(action='set_mode',mode=mode)
        self.assertEqual(self.r.compare_state.mode,'NOREX')
    def recipe(self):return {'relative':True,'steps':[{'ms':100,'axes':{'RX':.5,'RY':0},'buttons':{}},{'ms':50,'axes':{'RX':0,'RY':0},'buttons':{}}]}
    def test_canonical_user_recipe_run_is_local_gated_and_bounded(self):
        with self.assertRaises(ValueError):self.action(action='skill_run',skill_id='ball_roll_left',local_only=True)
        self.action(action='skill_recipe_save',skill_id='ball_roll_left',recipe=self.recipe(),local_only=True)
        with self.assertRaises(ValueError):self.action(action='skill_run',skill_id='ball_roll_left',local_only=True)
        self.r.arm_current();self.action(action='skill_run',skill_id='ball_roll_left',local_only=True)
        angle=math.radians(self.r.assist_engine.recipe_angle-270)
        self.assertAlmostEqual(self.r.physical_frame.axes['RX'],.5*math.cos(angle))
        self.assertAlmostEqual(self.r.physical_frame.axes['RY'],.5*math.sin(angle))
        self.assertEqual(self.r.assist_engine.recipe_direction_source,'last_left_stick')
        self.action(action='set_mode',mode='RAW');self.assertIsNone(self.r.assist_engine.active_recipe)
    def test_canonical_binding_conflict_rejected_without_reassignment(self):
        self.action(action='skill_recipe_save',skill_id='ball_roll_left',recipe=self.recipe(),local_only=True)
        self.r.profile['play_tools']['skill_bindings']=[{'trigger':'R1 + D-pad up','skill':'Elastico'}]
        before=copy.deepcopy(self.r.profile)
        with self.assertRaises(ValueError):self.action(action='skill_bindings',bindings=[{'trigger':'R1 + D-pad up','skill':'ball_roll_left'}],local_only=True)
        self.assertEqual(self.r.profile,before)
    def test_canonical_binding_latches_and_consumes_only_assigned_chord(self):
        self.action(action='skill_recipe_save',skill_id='ball_roll_left',recipe=self.recipe(),local_only=True)
        self.action(action='skill_bindings',bindings=[{'trigger':'R1 + D-pad up','skill':'ball_roll_left'}],local_only=True)
        self.r.arm_current();self.r.buttons.update(R1=True,Cross=True);self.r.raw['DY']=-1;self.r.on_frame()
        started=self.r.assist_engine.recipe_started;self.assertEqual(self.r.assist_engine.recipe_name,'ball_roll_left')
        self.assertFalse(self.r.physical_frame.buttons['R1']);self.assertTrue(self.r.physical_frame.buttons['Cross']);self.assertEqual(self.r.physical_frame.axes['DY'],0)
        self.r.on_frame();self.assertEqual(self.r.assist_engine.recipe_started,started)
    def test_arm_while_canonical_chord_held_does_not_fire(self):
        self.action(action='skill_recipe_save',skill_id='ball_roll_left',recipe=self.recipe(),local_only=True)
        self.action(action='skill_bindings',bindings=[{'trigger':'R1 + D-pad up','skill':'ball_roll_left'}],local_only=True)
        self.r.buttons['R1']=True;self.r.raw['DY']=-1;self.r.arm_current();self.r.on_frame()
        self.assertIsNone(self.r.assist_engine.active_recipe)

class StateTransitionsV2Tests(unittest.TestCase):
    setUp=RuntimeV2Tests.setUp
    action=RuntimeV2Tests.action
    recipe=RuntimeV2Tests.recipe
    def test_hotkey_activation_keeps_valid_processing_mode(self):
        self.r.mode_bank.configure(True,self.r.mode_bank.bindings,persist=False)
        self.r.arm_current();self.r.raw.update(L2=1,R2=1,DX=-1)
        now=time.monotonic_ns();self.r.processing_pipeline.process(self.r,now)
        _,_,_,_,meta=self.r.processing_pipeline.process(self.r,now+260_000_000)
        self.assertEqual(self.r.active_mode,'Defender');self.assertEqual(meta['mode'],'NOREX')
    def test_live_mode_hotkey_conflict_preserves_memory_and_disk(self):
        self.action(action='skill_recipe_save',skill_id='ball_roll_left',recipe=self.recipe(),local_only=True)
        self.action(action='skill_bindings',bindings=[{'trigger':'L2 + D-pad left','skill':'ball_roll_left'}],local_only=True)
        disk=self.r.mode_bank.path.read_bytes();before=copy.deepcopy(self.r.mode_bank.bindings)
        with self.assertRaises(ValueError):self.r.runtime_action({'action':'mode_hotkeys','enabled':True,'bindings':self.r.mode_bank.bindings})
        self.assertEqual(self.r.mode_bank.bindings,before);self.assertFalse(self.r.mode_bank.enabled);self.assertEqual(self.r.mode_bank.path.read_bytes(),disk)
    def test_configuration_change_ends_sample_before_counting_new_frame(self):
        self.r.arm_current();self.action(action='comparison_start',mode='NOREX')
        before=self.r.compare_state.active['frames'];self.r.profile['deadzone']=.2;self.r.on_frame()
        self.assertIsNone(self.r.compare_state.active);self.assertEqual(self.r.compare_state.samples['NOREX']['frames'],before)
    def test_normal_frame_reports_norex_mode(self):
        self.r.on_frame();self.assertEqual(self.r.processing_pipeline.metadata['mode'],'NOREX')

    def test_input_overrun_keeps_physical_output_registered_and_neutral(self):
        sink=Sink();self.r.output=sink;self.r.output_source='physical';self.r.assists_armed=True
        self.r.feed(1,0,0,3,0)
        self.assertIs(self.r.output,sink);self.assertFalse(sink.closed)
        self.assertFalse(self.r.assists_armed);self.assertEqual(self.r.dropped,1)
        self.assertEqual(sink.frames[-1].axes,neutral_frame().axes)
        with patch.object(self.r,'sync') as sync:
            self.r.feed(1,1,0,0,0,fd=12);sync.assert_called_once_with(12)
        self.assertIs(self.r.output,sink);self.assertFalse(self.r._dropping)
        self.r.disconnect_runtime('Cable removed')
        self.assertTrue(sink.closed);self.assertIsNone(self.r.output)
        self.assertEqual(self.r.output_last_stop,'Cable removed')

    def test_overrun_neutralization_failure_closes_output(self):
        sink=Sink();self.r.output=sink;self.r.output_source='physical'
        with patch.object(sink,'neutralize',side_effect=OSError('write failed')):
            self.r.feed(1,0,0,3,0)
        self.assertIsNone(self.r.output);self.assertIn('Neutralization failed',self.r.output_last_stop)
