import copy,json,tempfile,unittest
from pathlib import Path
from input_audit import InputAudit
from pipeline import default_profile,normalized
import test_advanced

class ConsoleRuntimeTests(unittest.TestCase):
 setUp=test_advanced.AdvancedRuntime.setUp
 def test_power_off_bypasses_curves_remaps_and_helpers_without_closing_output(self):
  self.l.profile['curves']['left']={'kind':'power','exponent':4};self.l.profile['button_map']['Circle']='Disabled';self.l.profile['assists']['auto_jockey']=True
  self.l.raw.update(LX=210,LY=127.5);self.l.buttons['Circle']=True;self.l.new_output('physical');self.l.arm_current();saved=copy.deepcopy(self.l.profile)
  self.l.runtime_action({'action':'custom_power','enabled':False})
  self.assertFalse(self.sink.closed);self.assertTrue(self.sink.sent[-1].buttons['Circle']);self.assertEqual(self.sink.sent[-1].axes['L2'],0);self.assertEqual(self.l.profile,saved)
  self.assertAlmostEqual(self.sink.sent[-1].axes['LX'],(210-127.5)/127.5)
  with self.assertRaises(ValueError):self.l.arm_current()
  self.l.runtime_action({'action':'custom_power','enabled':True});self.assertTrue(self.l.assists_armed)
 def test_one_power_on_applies_selected_helpers_without_a_second_enable_step(self):
  self.l.profile['assists']['auto_jockey']=True;self.assertFalse(self.l.assists_armed)
  self.l.runtime_action({'action':'custom_power','enabled':False});self.l.runtime_action({'action':'custom_power','enabled':True})
  self.assertTrue(self.l.assists_armed);self.assertEqual(self.l.physical_frame.axes['L2'],1)
 def test_power_off_persists_and_does_not_modify_profile_on_arm_rejection(self):
  self.l.runtime_action({'action':'custom_power','enabled':False});before=copy.deepcopy(self.l.profile)
  other=copy.deepcopy(before);other['deadzone']=.22
  with self.assertRaises(ValueError):self.l.runtime_action({'action':'arm_assists','local_only':True,'profile':other})
  self.assertEqual(self.l.profile,before);self.assertFalse(json.loads(self.l.control_path.read_text())['custom_enabled'])
 def test_square_cross_hold_cannot_delay_manual_tackle_release(self):
  self.l.profile['assists']['timed_cross']=True;self.l.arm_current();self.l.buttons['Square']=True;self.l.on_frame();self.assertTrue(self.l.physical_frame.buttons['Square'])
  self.l.buttons['Square']=False;self.l.on_frame();self.assertFalse(self.l.physical_frame.buttons['Square']);self.assertFalse(self.l.assist_engine.timers)
 def test_manual_tackle_wins_in_every_mode(self):
  for mode in ['Defender','Creator','Finisher']:
   self.l.select_mode(mode);self.l.profile['assists']['auto_power_shot']=True;self.l.profile['assists']['timed_shot']=True
   self.l.profile['button_map']['Circle']='Disabled';self.l.arm_current();self.l.buttons['Circle']=True;self.l.on_frame()
   self.assertTrue(self.l.physical_frame.buttons['Circle']);self.assertFalse(self.l.physical_frame.buttons['R1']);self.assertFalse(self.l.physical_frame.buttons['L1']);self.assertFalse(self.l.assist_engine.active_recipe)
   self.l.buttons['Circle']=False;self.l.on_frame();self.assertFalse(self.l.physical_frame.buttons['Circle'])
 def test_no_preset_restores_personal_settings(self):
  self.l.profile['deadzone']=.17;saved=copy.deepcopy(self.l.profile);self.l.select_mode('Finisher');self.l.select_mode('None')
  self.assertEqual(self.l.profile,saved);self.assertEqual(self.l.active_mode,'None');self.assertFalse(self.l.defending)
 def test_power_change_rejected_during_delivery_test(self):
  self.l.runtime_action({'action':'delivery_test_start','local_only':True})
  with self.assertRaises(ValueError):self.l.runtime_action({'action':'custom_power','enabled':False})
 def test_actual_helper_and_manual_conflict_is_logged(self):
  self.l.profile['assists']['auto_power_shot']=True;self.l.arm_current();self.l.buttons['Circle']=True;self.l.on_frame()
  row=self.l.audit.rows[-1];self.assertTrue(row['warning']);self.assertIn('Power-shot modifiers',row['activated']);self.assertTrue(any(r['winner']=='Manual action priority' for r in row['conflicts']))
 def test_manual_priority_can_be_disabled_for_physical_shot_helpers(self):
  self.l.profile['play_tools']['manual_action_priority']=False;self.l.profile['assists']['auto_power_shot']=True;self.l.arm_current();self.l.buttons['Circle']=True;self.l.on_frame()
  self.assertFalse(self.l.physical_frame.buttons['R1']);self.assertFalse(self.l.physical_frame.buttons['L1']);self.assertTrue(self.l.physical_frame.buttons['Circle'])

class AuditTests(unittest.TestCase):
 def test_priority_conflicts_export_and_bounded_history(self):
  with tempfile.TemporaryDirectory() as d:
   audit=InputAudit(Path(d));audit.observe({'L2':0},{'Circle':True},[('helper',{'L2':1},{'Circle':True}),('manual',{'L2':0},{'Circle':True})],['jockey'],1000000000)
   self.assertEqual(audit.rows[-1]['conflicts'][0]['winner'],'manual');self.assertTrue(audit.rows[-1]['warning']);self.assertEqual(json.loads(audit.path.read_text())['input'],'Circle')
   for i in range(200):audit.note(str(i))
   self.assertEqual(len(audit.rows),100)
 def test_idle_deduplicated_and_stick_updates_rate_limited(self):
  with tempfile.TemporaryDirectory() as d:
   audit=InputAudit(Path(d));audit.observe({'LX':0},{},[],[],0);audit.observe({'LX':.1},{},[],[],1000000);audit.observe({'LX':.2},{},[],[],200000000);audit.observe({'LX':.2},{},[],[],400000000)
   self.assertEqual(len(audit.rows),2)
