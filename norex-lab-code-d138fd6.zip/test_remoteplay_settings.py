import tempfile,unittest
from pathlib import Path
from remoteplay_settings import RemotePlaySettings
class MediaTests(unittest.TestCase):
 def test_all_modes_preserve_registration_and_apply(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'settings';original='[registered_hosts]\nopaque=unchanged\n[settings]\nkeyboard_enabled=false\n'
   p.write_text(original);r=RemotePlaySettings(p,lambda:False)
   for video,audio,mode in [(False,True,2),(True,True,0),(True,False,1),(False,False,3)]:
    state=r.apply(video,audio);self.assertEqual(state['video_enabled'],video);self.assertEqual(state['audio_enabled'],audio)
    self.assertIn('opaque=unchanged',p.read_text());self.assertIn('keyboard_enabled=false',p.read_text());self.assertIn(f'audio_video_disabled={mode}',p.read_text());self.assertEqual(p.stat().st_mode&0o777,0o600)
 def test_running_and_bad_values_rejected_without_change(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'settings';p.write_text('[settings]\n');before=p.read_bytes()
   with self.assertRaises(ValueError):RemotePlaySettings(p,lambda:True).apply(False,True)
   with self.assertRaises(ValueError):RemotePlaySettings(p,lambda:False).apply('false',True)
   self.assertEqual(p.read_bytes(),before)

 def test_connect_uses_registered_console_and_safe_argument_list(self):
  from unittest.mock import Mock,patch
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'settings';p.write_text('[registered_hosts]\n1\\server_nickname=PS5-test\n')
   launcher=Path(d)/'launcher';launcher.touch();spawn=Mock();spawn.return_value.poll.return_value=None
   with patch('time.sleep'):
    RemotePlaySettings(p,lambda:False).connect(launcher,spawn,host='192.0.2.5')
   self.assertEqual(spawn.call_args.args[0],[str(launcher),'--exit-app-on-stream-exit','stream','PS5-test','192.0.2.5'])
   with self.assertRaises(ValueError):RemotePlaySettings(p,lambda:True).connect(launcher,spawn,host='192.0.2.5')
