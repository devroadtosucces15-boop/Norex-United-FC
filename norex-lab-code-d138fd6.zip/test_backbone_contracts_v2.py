"""Behavioral bounds and provenance checks for the frozen backend contracts."""
import copy,math,random,unittest
from itertools import permutations
from pipeline import neutral_frame,default_profile,validate_profile
from backbone.fc27_data import ALL_SKILLS,SKILLS,JUGGLING,CONTROLS,COMBOS,SIMPLIFIED_SKILLS,SOURCE_METADATA
from backbone.helper_contract import defaults,validate_config,HELPERS
from backbone.engine import BackboneEngine
from backbone.resolver import ConflictResolver,Intent,CompareState
from backbone.skills import validate_recipe
from backbone.api_contract import effective_payload

class KnowledgeTests(unittest.TestCase):
    def test_complete_reference_and_distinct_juggling_ids(self):
        self.assertEqual(len(SKILLS),77);self.assertEqual(len(JUGGLING),9)
        self.assertEqual(len({r['id'] for r in ALL_SKILLS}),115)
        self.assertGreaterEqual(len(CONTROLS),173);self.assertTrue(COMBOS);self.assertEqual(len(SIMPLIFIED_SKILLS),9)
        self.assertNotEqual(next(r['id'] for r in SKILLS if r['name']=='Flick Up'),next(r['id'] for r in JUGGLING if r['name']=='Flick Up'))
    def test_provenance_is_not_execution_or_verification(self):
        for row in ALL_SKILLS:
            self.assertIn(row['provenance']['primary'],SOURCE_METADATA)
            self.assertFalse(row['executable']);self.assertIsNone(row['recipe'])
            self.assertEqual(row['verification']['game'],'not_tested')
            self.assertIn(row['playstyle_dependency'],(None,'Trickster','Trickster+'))
            if row['playstyle_dependency']:self.assertEqual(row['display_group'],'trickster')
        for row in COMBOS:
            self.assertFalse(row['executable']);self.assertIsNone(row['recipe'])
    def test_tba_and_ambiguous_reject_even_user_recipes(self):
        recipe={'relative':True,'steps':[{'ms':50,'axes':{'RX':.5},'buttons':{}}]}
        for row in ALL_SKILLS:
            if row['input_status'] in ('TBA','AMBIGUOUS'):
                with self.assertRaises(ValueError):validate_recipe(row['id'],recipe)
    def test_official_new_controls_have_primary_provenance(self):
        for key in ('corner_avoidance','triggered_curved_run','pass_follow'):
            self.assertEqual(CONTROLS[key]['verification']['source'],'primary')
            self.assertFalse(CONTROLS[key]['executable'])
    def test_unknown_recipe_and_transport_assertions_rejected(self):
        with self.assertRaises(ValueError):validate_recipe('made_up',{})
        with self.assertRaises(ValueError):effective_payload('NOREX','fc27',{},True,'VERIFIED')

class HelperBehaviorTests(unittest.TestCase):
    def setUp(self):self.engine=BackboneEngine();self.f=neutral_frame()
    def config(self,key,**parameters):return {key:{'enabled':True,**parameters}}
    def test_every_advertised_transform_produces_an_effect(self):
        for key in defaults():
            a=copy.deepcopy(self.f.axes);b=copy.deepcopy(self.f.buttons);self.engine.reset()
            a.update(LX=.4,LY=.01,RX=.4,RY=.01,L2=.6,R2=.6)
            b.update(Circle=True,Square=True,Triangle=True,R1=True,R3=True)
            config=self.config(key,strength=100)
            if key=='direction_stability':
                self.engine.process(a,b,config,1_000_000);a['LY']=.015
            elif key=='smoothing':
                self.engine.process(a,b,config,1_000_000);a['LX']=.7
            out,buttons,meta=self.engine.process(a,b,config,11_000_000)
            self.assertNotEqual(out,a,key);self.assertEqual(buttons,b,key);self.assertIn(key,meta['trace'],key)
    def test_all_helper_bounds_and_buttons_with_random_frames(self):
        rng=random.Random(728);cfg=defaults()
        for key,row in cfg.items():
            row['enabled']=True
            for name,p in HELPERS[key]['parameters'].items():row[name]=p['max']
        for i in range(200):
            a={key:rng.uniform(0 if key in ('L2','R2') else -1,1) for key in self.f.axes}
            b={key:bool(rng.getrandbits(1)) for key in self.f.buttons}
            out,buttons,_=self.engine.process(a,b,cfg,(i+1)*10_000_000)
            self.assertEqual(buttons,b)
            for key,value in out.items():self.assertTrue(math.isfinite(value) and (0 if key in ('L2','R2') else -1)<=value<=1)
    def test_context_priority_uses_physical_buttons(self):
        a=copy.deepcopy(self.f.axes);a['LX']=.5;b=copy.deepcopy(self.f.buttons)
        b.update(Triangle=True,Square=True,Circle=True)
        cfg={key:{'enabled':True,'strength':100} for key in ('shot_response','cross_response','through_pass_response')}
        out,_,meta=self.engine.process(a,b,cfg,1)
        self.assertEqual(meta['trace'],['shot_response']);self.assertEqual(len(meta['conflicts']),2)
        physical=copy.deepcopy(b);physical.update(Circle=False,Square=False,Triangle=False)
        out,_,meta=self.engine.process(a,b,cfg,2,physical_buttons=physical)
        self.assertEqual(out,a);self.assertEqual(meta['trace'],[])
    def test_legacy_aim_and_temporal_conflicts_declared(self):
        a=copy.deepcopy(self.f.axes);a['LX']=.5;b=copy.deepcopy(self.f.buttons);b['Triangle']=True
        out,_,meta=self.engine.process(a,b,self.config('through_pass_response'),1,context='shoot')
        self.assertEqual(out,a);self.assertEqual(meta['conflicts'][0]['winner'],'legacy shoot aim response')
        cfg={'smoothing':{'enabled':True},'direction_stability':{'enabled':True}}
        _,_,meta=self.engine.process(a,b,cfg,2)
        self.assertIn({'helper':'smoothing','winner':'direction_stability'},meta['conflicts'])
    def test_temporal_neutral_reversal_outer_and_gap_escape(self):
        cfg=self.config('smoothing',strength=100,window_ms=40)
        for next_value,stamp in [(0,12_000_000),(-.5,12_000_000),(1,12_000_000),(.6,200_000_000)]:
            self.engine.reset();a=copy.deepcopy(self.f.axes);a['LX']=.3
            self.engine.process(a,self.f.buttons,cfg,1_000_000);a['LX']=next_value
            out,_,_=self.engine.process(a,self.f.buttons,cfg,stamp);self.assertEqual(out['LX'],next_value)
    def test_config_rejects_nonfinite_unknown_boolean_and_range_errors(self):
        for invalid in (float('nan'),float('inf'),-1,101,True,'50'):
            with self.assertRaises(ValueError):validate_config(self.config('precision_stick',strength=invalid))
        for cfg in ({'unknown':{}},{'precision_stick':{'enabled':1}},{'precision_stick':{'duration':15}},[]):
            with self.assertRaises(ValueError):validate_config(cfg)
    def test_raw_drops_filter_memory_and_preserves_input(self):
        a=copy.deepcopy(self.f.axes);a['LX']=.4;self.engine.process(a,self.f.buttons,self.config('smoothing'),10)
        self.engine.set_mode('RAW');out,b,meta=self.engine.process(a,self.f.buttons,self.config('precision_stick'),20)
        self.assertEqual(out,a);self.assertIsNone(self.engine.previous);self.assertEqual(meta['trace'],[])
    def test_profile_migration_v2_defaults_and_strict_schema(self):
        p=default_profile();del p['backbone_helpers'];del p['backbone_skills'];p['schema']=1
        self.assertEqual(validate_profile(p)['backbone_helpers'],defaults())
        for bad in ({**p,'schema':True},{**p,'unknown':True}):
            with self.assertRaises(ValueError):validate_profile(bad)

class ResolverValidationTests(unittest.TestCase):
    def test_order_independent_and_trigger_bounds(self):
        f=neutral_frame();rows=[Intent('a','LX','SET_AXIS',30,.3),Intent('b','LX','SET_AXIS',30,.7),Intent('escape','LX','SET_AXIS',90,-.4)]
        results=[ConflictResolver().resolve(f.axes,f.buttons,row) for row in permutations(rows)]
        self.assertTrue(all(result==results[0] for result in results))
        a,_,_=ConflictResolver().resolve(f.axes,f.buttons,[Intent('a','L2','SET_AXIS',40,-1)])
        self.assertEqual(a['L2'],0)
    def test_invalid_lower_priority_intent_cannot_hide(self):
        f=neutral_frame()
        for invalid in [Intent('bad','LX','SET_AXIS',20,float('nan')),Intent('bad','Circle','SET_BUTTON',20,1),Intent('bad','MadeUp','SET_AXIS',20,.4),Intent('bad','LX','SET_AXIS',101,.2)]:
            with self.assertRaises(ValueError):ConflictResolver().resolve(f.axes,f.buttons,[invalid,Intent('good','LX','SET_AXIS',90,.5)])
    def test_same_source_contradiction_rejected(self):
        f=neutral_frame()
        with self.assertRaises(ValueError):ConflictResolver().resolve(f.axes,f.buttons,[Intent('a','LX','SET_AXIS',30,.4),Intent('a','LX','SET_AXIS',30,.3)])
    def test_compare_bounded_and_defensive_copy(self):
        c=CompareState()
        for i in range(50):c.choose('CANNOT_TELL',str(i))
        self.assertEqual(len(c.results),32);state=c.status();state['results'].clear();self.assertEqual(len(c.results),32)
    def test_failed_sample_does_not_change_mode(self):
        c=CompareState();c.start('RAW',{'profile':'one'});c.finish();before=c.status()
        with self.assertRaises(ValueError):c.start('NOREX',{'profile':'two'})
        self.assertEqual(c.status(),before)
