"""Opt-in input shaping and explicit shortcuts; no game-state detection."""
import copy
import math
from pipeline import BUTTONS, number, transform

SHORTCUTS=('finesse','chip','power','low_driven','controlled_sprint','curved_run','pass_follow','player_lock','precision_clutch')

def defaults():
    return {'stick_deadzone':{'enabled':False,'left':.03,'right':.03},
            'triggers':{k:{'enabled':False,'deadzone':.02,'exponent':1.,'digital':False,'press':.15,'release':.08} for k in ('L2','R2')},
            'contexts':{k:{'enabled':False,'exponent':1.15} for k in ('shoot','pass','cross','switching')},
            'defense_only_jockey':False,'sprint_toggle':False,
            'shortcuts':{k:'Disabled' for k in SHORTCUTS},'tap_ms':80,'low_delay_ms':80,'low_press_ms':40}

def validate(value,assists):
    if not isinstance(value,dict): raise ValueError('Invalid advanced settings')
    c=defaults(); c.update(copy.deepcopy(value))
    if set(c)!=set(defaults()): raise ValueError('Unknown advanced option')
    def flag(x):
        if type(x) is not bool: raise ValueError('Expected true/false')
    s=c['stick_deadzone']
    if not isinstance(s,dict) or set(s)!={'enabled','left','right'}: raise ValueError('Invalid stick dead zones')
    flag(s['enabled']);number(s['left'],0,.5);number(s['right'],0,.5)
    if not isinstance(c['triggers'],dict) or set(c['triggers'])!={'L2','R2'}: raise ValueError('Invalid trigger settings')
    for t in c['triggers'].values():
        if not isinstance(t,dict) or set(t)!={'enabled','deadzone','exponent','digital','press','release'}: raise ValueError('Invalid trigger options')
        flag(t['enabled']);flag(t['digital']);number(t['deadzone'],0,.5);number(t['exponent'],.25,4);number(t['press'],.01,1);number(t['release'],0,.99)
        if t['release']>=t['press']: raise ValueError('Trigger release must be below press')
    if not isinstance(c['contexts'],dict) or set(c['contexts'])!={'shoot','pass','cross','switching'}: raise ValueError('Invalid aiming contexts')
    for row in c['contexts'].values():
        if not isinstance(row,dict) or set(row)!={'enabled','exponent'}: raise ValueError('Invalid aiming response')
        flag(row['enabled']);number(row['exponent'],.25,4)
    flag(c['defense_only_jockey']);flag(c['sprint_toggle'])
    bindings=c['shortcuts']
    if isinstance(bindings,dict):
        migrated=defaults()['shortcuts'];migrated.update(bindings);bindings=migrated;c['shortcuts']=bindings
    if not isinstance(bindings,dict) or set(bindings)!=set(SHORTCUTS): raise ValueError('Invalid shortcut bindings')
    allowed=set(BUTTONS.values())-{'PS'}
    if any(v not in allowed|{'Disabled'} for v in bindings.values()): raise ValueError('Invalid shortcut button')
    used=[v for v in bindings.values() if v!='Disabled']
    legacy=[r['button'] for r in assists['button_skills'].values() if r['button']!='Disabled']
    if assists['lock_button']!='Disabled':legacy.append(assists['lock_button'])
    if len(used)!=len(set(used)) or set(used)&set(legacy):raise ValueError('Shortcut buttons must be distinct and cannot share legacy skill/lock triggers')
    # Reserving the standard action buttons would break normal action detection.
    if set(used)&set(assists['action_buttons'].values()):raise ValueError('Choose shortcut buttons other than pass, cross and shoot')
    if any(bindings[k]!='Disabled' for k in ('finesse','chip','power','low_driven')) and any(assists[k] for k in ('timed_shot','low_driven','perfect_lowdrive','auto_power_shot','finesse_finish')):
        raise ValueError('Turn off old shot holds/second presses/power helpers before binding shot shortcuts')
    if bindings['pass_follow']!='Disabled' and assists['timed_pass']:raise ValueError('Turn off fixed pass hold before binding pass-and-follow')
    number(c['tap_ms'],20,200);number(c['low_delay_ms'],20,300);number(c['low_press_ms'],20,150)
    return c

class AdvancedEngine:
    def __init__(self):self.reset()
    def reset(self):
        self.previous={};self.digital={'L2':False,'R2':False};self.taps={};self.low_follow=None;self.sprint_until=0;self.last_ns=None;self.shot_started={}
    def prime(self,buttons,axes=None):
        self.previous=dict(buttons)
        self.digital={k:(axes or {}).get(k,0)>=.5 for k in ('L2','R2')}
    def apply(self,axes,buttons,p,armed,defending,now):
        c=p['advanced']; cfg={**p,'curves':dict(p['curves'])}; physical={k:bool(buttons.get(k,False)) for k in BUTTONS.values()}
        # Use remapped inputs to detect action buttons and shortcut bindings.
        _,mapped=transform(axes,physical,p)
        short=c['shortcuts'];action=p['assists']['action_buttons'];context='movement'
        if armed:
            clutch=short['precision_clutch']!='Disabled' and mapped.get(short['precision_clutch'])
            shooting=(clutch and p['play_tools']['clutch_context']=='shoot') or mapped.get(action['shot']) or any(short[k]!='Disabled' and mapped.get(short[k]) for k in ('finesse','chip','power','low_driven'))
            for kind,held in [('shoot',shooting),('cross',mapped.get(action['cross']) or (clutch and p['play_tools']['clutch_context']=='cross')),('pass',mapped.get(action['pass']) or (clutch and p['play_tools']['clutch_context']=='pass'))]:
                if held and (c['contexts'][kind]['enabled'] or (kind=='shoot' and p['play_tools']['shot_response']['enabled'])):
                    exponent=c['contexts'][kind]['exponent']
                    if kind=='shoot' and p['play_tools']['shot_response']['enabled']:
                        shot_kind='power' if (mapped.get('L1') and mapped.get('R1')) or (short['power']!='Disabled' and mapped.get(short['power'])) else 'finesse' if mapped.get('R1') or (short['finesse']!='Disabled' and mapped.get(short['finesse'])) else 'normal'
                        exponent=p['play_tools']['shot_response'][shot_kind]
                    cfg['curves']['left']={'kind':'power','exponent':exponent};context=kind;break
            if defending and c['contexts']['switching']['enabled']:
                cfg['curves']['right']={'kind':'power','exponent':c['contexts']['switching']['exponent']}
                if context=='movement':context='switching'
        a,b=transform(axes,physical,cfg)
        response_names=[side+' '+row['kind']+' curve' for side,row in cfg['curves'].items() if row['kind']!='linear']
        if cfg['deadzone']>0:response_names.append('stick dead zone')
        if any(k!=v for k,v in cfg['button_map'].items()):response_names.append('button remapping')
        self.trace_steps=[('Response / layout'+(' ('+', '.join(response_names)+')' if response_names else '')+(' / '+context+' aim' if context!='movement' else ''),dict(a),dict(b))]
        previous_trace=[dict(a),dict(b)]
        def checkpoint(label):
            if a!=previous_trace[0] or b!=previous_trace[1]:
                self.trace_steps.append((label,dict(a),dict(b)));previous_trace[:]=[dict(a),dict(b)]
        if c['stick_deadzone']['enabled']:
            # Recompute with the independent radial zone before the curve and axis map.
            for label,pair in [('left',('LX','LY')),('right',('RX','RY'))]:
                part=dict(cfg);part['deadzone']=c['stick_deadzone'][label]
                shaped,_=transform(axes,physical,part)
                for src in pair:a[p['axis_map'][src]]=shaped[p['axis_map'][src]]
        checkpoint('Separate stick dead zones')
        for key,t in c['triggers'].items():
            if t['enabled']:
                value=max(0,min(1,(axes.get(key,0)-t['deadzone'])/(1-t['deadzone'])))**t['exponent']
                if armed and t['digital']:
                    if value>=t['press']:self.digital[key]=True
                    elif value<=t['release']:self.digital[key]=False
                    value=float(self.digital[key])
                    # Explicit remapped trigger button channel matches the analog channel.
                    dest=p['button_map'][key+' button']
                    if dest!='Disabled':b[dest]=bool(value)
                a[key]=value
            checkpoint(key+' response / digital trigger')
        if not armed:
            self.reset();return a,b,context
        if self.last_ns is not None and now-self.last_ns>200_000_000:
            self.taps={};self.low_follow=None;self.sprint_until=0
            self.previous=dict(mapped) # scheduler gaps never create fresh synthetic edges
        self.last_ns=now
        rising=lambda key:mapped.get(key,False) and not self.previous.get(key,False)
        held={k:(v!='Disabled' and mapped.get(v,False)) for k,v in short.items()}
        for key,button in short.items():
            if button!='Disabled':
                b[button]=False
                if button in ('L2 button','R2 button'):a[button[:2]]=0.
        checkpoint('Shortcut activation button consumed')
        for key,mods in [('finesse',('R1',)),('chip',('L1',)),('power',('L1','R1'))]:
            if held[key]:
                self.shot_started.setdefault(key,now)
                b[action['shot']]=now-self.shot_started[key]>=p['play_tools']['chord_delay_ms']*1_000_000
                # Chosen shot type supersedes physical shot modifiers.
                b['L1']='L1' in mods;b['R1']='R1' in mods
            else:self.shot_started.pop(key,None)
            checkpoint(key+' shot shortcut')
        key=short['low_driven']
        if key!='Disabled':
            if held['low_driven']:
                b[action['shot']]=True;b['L1']=False;b['R1']=False
            if self.previous.get(key,False) and not held['low_driven']:
                start=now+c['low_delay_ms']*1_000_000;self.low_follow=(start,start+c['low_press_ms']*1_000_000)
            if self.low_follow:
                start,end=self.low_follow
                if start<=now<end:b[action['shot']]=True
                if now>=end:self.low_follow=None
        checkpoint('Low-driven shortcut / follow-up')
        key=short['controlled_sprint']
        if key!='Disabled':
            if c['sprint_toggle']:
                if rising(key):self.sprint_until=0 if self.sprint_until>now else now+10_000_000_000
                if now<self.sprint_until:b['R1']=True
            elif held['controlled_sprint']:b['R1']=True
        checkpoint('Controlled sprint shortcut')
        for key,keys in [('curved_run',('L1','R1')),('pass_follow',('L1','R1',action['pass'])),('player_lock',('L3','R3'))]:
            button=short[key]
            if button!='Disabled' and rising(button):self.taps[key]=now+c['tap_ms']*1_000_000
            if now<self.taps.get(key,0):
                for out in keys:b[out]=True
            else:self.taps.pop(key,None)
            checkpoint(key.replace('_',' ')+' shortcut')
        self.previous=dict(mapped)
        return a,b,context
