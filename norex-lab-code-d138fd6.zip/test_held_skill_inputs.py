import copy,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import lab
from pipeline import neutral_frame
from play_tools import PlayTools

class HeldMappingTests(unittest.TestCase):
 def test_all_single_triggers_allow_other_controls_without_retrigger(self):
  from pipeline import default_profile
  for trigger in ('L3','R3','Create','Options'):
   for other in ('R1','L1','Cross','Circle','Square','Triangle','L2 button','R2 button'):
    with self.subTest(trigger=trigger,other=other):
     p=default_profile();p['play_tools']['skill_bindings']=[{'trigger':trigger,'skill':'Reverse Elastico'}]
     t=PlayTools();buttons={trigger:True,other:True};axes={'L2':1,'R2':1}
     self.assertIsNone(t.skill_edges(axes,buttons,p,1_000_000_000)[0])
     self.assertEqual(t.skill_edges(axes,buttons,p,1_100_000_000)[0],'Reverse Elastico')
     self.assertIsNone(t.skill_edges(axes,{trigger:True},p,1_150_000_000)[0])
     t.skill_edges(axes,{trigger:False,other:True},p,1_160_000_000)
     self.assertIsNone(t.skill_edges(axes,buttons,p,1_200_000_000)[0])
     self.assertEqual(t.skill_edges(axes,buttons,p,1_300_000_000)[0],'Reverse Elastico')

class HeldRuntimeTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.addCleanup(self.tmp.cleanup)
  with patch.object(lab,'DATA',Path(self.tmp.name)):self.r=lab.Lab()
  self.r.status='Connected';self.r.raw={'LX':0,'LY':-1,'RX':0,'RY':0,'L2':0,'R2':0,'DX':0,'DY':0}
  self.r.bounds={k:[0,1] if k in ('L2','R2') else [-1,1] for k in self.r.raw}
  self.r.buttons=copy.deepcopy(neutral_frame().buttons)
  self.r.profile['play_tools']['skill_bindings']=[{'trigger':'R3','skill':'Reverse Elastico'}]
  self.r.arm_current()
 def tick(self,ms):
  return self.r.processing_pipeline.process(self.r,int(ms*1e6))
 def test_held_sprint_modifier_and_face_button_preserved_after_trigger_release(self):
  self.r.raw['R2']=1
  self.r.buttons.update(R1=True,Cross=True,Triangle=True)
  self.r.buttons['R3']=True;self.tick(1000)
  axes,buttons,*_=self.tick(1100)
  self.assertEqual(self.r.assist_engine.recipe_name,'Reverse Elastico')
  for key in ('R1','Cross','Triangle'):self.assertTrue(buttons[key])
  self.assertFalse(buttons['R3']);self.assertEqual(axes['R2'],1)
  self.r.buttons['R3']=False
  axes,buttons,*_=self.tick(1120)
  self.assertEqual(self.r.assist_engine.recipe_name,'Reverse Elastico')
  for key in ('R1','Cross','Triangle'):self.assertTrue(buttons[key])
  self.assertEqual(axes['R2'],1)
  self.assertNotIn('Manual face-button priority',self.r.processing_pipeline.metadata['trace'])
 def test_colliding_physical_action_still_wins(self):
  self.r.assist_engine.start_recipe('local collision',[{'ms':500,'axes':{'L2':1},'buttons':{'Circle':False,'R1':True}}],1_000_000_000,config=self.r.profile['assists'],relative=False)
  self.r.buttons['Circle']=True
  axes,buttons,*_=self.tick(1010)
  self.assertIsNone(self.r.assist_engine.active_recipe)
  self.assertTrue(buttons['Circle']);self.assertFalse(buttons['R1']);self.assertEqual(axes['L2'],0)
 def test_raw_and_escape_continue_to_bypass_mapping(self):
  self.r.buttons['R3']=True;self.tick(1000);self.tick(1100)
  self.assertIsNotNone(self.r.assist_engine.active_recipe)
  self.r.buttons.update(L1=True,R1=True);self.r.raw.update(L2=1,R2=1)
  self.tick(1120);self.assertIsNone(self.r.assist_engine.active_recipe)
  self.assertTrue(self.r.processing_pipeline.metadata['physical_escape'])
  self.r.raw.update(L2=0,R2=0);self.r.buttons.update(L1=False,R1=False)
  self.r.compare_state.mode='RAW';axes,buttons,*_=self.tick(1130)
  self.assertTrue(buttons['R3']);self.assertEqual(axes['RX'],0)
