"""Game-type presets: for each game type (League, Rush, Grounds) a few variants, each a snapshot of the tunable
settings (profile path -> value). Applying one is a normal 'configure' done by the page, so the usual validation applies."""
import json,re,time
from profile_store import write_atomic

TYPES=('League','Rush','Grounds')
VARIANTS=('Base','Attack','Defend')
KEY=re.compile(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$')
MAX_KEYS=200

def _path(data):return data/'game-presets.json'

def read(data):
    p=_path(data)
    if not p.exists():return {'presets':{}}
    row=json.loads(p.read_text())
    if not isinstance(row,dict) or not isinstance(row.get('presets'),dict):raise ValueError('Invalid game presets file')
    return {'presets':row['presets']}

def _clean(values):
    if not isinstance(values,dict) or not values or len(values)>MAX_KEYS:raise ValueError('A preset needs between 1 and %d settings'%MAX_KEYS)
    out={}
    for k,v in values.items():
        if not isinstance(k,str) or not KEY.match(k) or len(k)>80:raise ValueError('Invalid setting name')
        if isinstance(v,bool) or (isinstance(v,(int,float)) and abs(v)<=100000) or (isinstance(v,str) and len(v)<=40):out[k]=v
        else:raise ValueError('Invalid value for '+k)
    return out

def save(data,game,variant,values):
    if game not in TYPES:raise ValueError('Unknown game type')
    if variant not in VARIANTS:raise ValueError('Unknown variant')
    presets=read(data)['presets']
    presets.setdefault(game,{})[variant]={'values':_clean(values),'at':time.strftime('%Y-%m-%dT%H:%M:%S%z')}
    write_atomic(_path(data),{'presets':presets})
    return {'presets':presets}

def delete(data,game,variant):
    presets=read(data)['presets']
    presets.get(game,{}).pop(variant,None)
    if not presets.get(game):presets.pop(game,None)
    write_atomic(_path(data),{'presets':presets})
    return {'presets':presets}
