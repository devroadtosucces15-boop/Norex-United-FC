"""Opt-in, non-blocking response helpers. No possession or gameplay inference."""
import copy
import math
from pipeline import number

# Each control is owned here exactly once. Existing aim/trigger/remap settings
# remain authoritative in advanced.py and pipeline.py.
BENEFITS = {
    'through_pass': ('Passing/Crossing', 'Through-pass stick response', 'Triangle held: reshape LS magnitude; does not alter press duration.'),
    'controlled_dribble': ('Dribbling/Ball Control', 'Held R1 fine movement', 'R1 held: reshape LS magnitude; manual direction and buttons remain yours.'),
    'jockey': ('Defending', 'Held L2 movement response', 'Physical L2 held: reshape LS magnitude. Never creates an L2 press or detects defending.'),
    'sprint': ('Movement/Responsiveness', 'Held R2 movement response', 'Physical R2 held: reshape LS magnitude; does not change player pace.'),
    'goalkeeper': ('Goalkeeping', 'Held R3 right-stick response', 'R3 held: reshape RS magnitude. Select this only for your goalkeeper control layout; Lab does not detect goalkeeper state.'),
}

def defaults():
    return {'contexts': {k: {'enabled': False, 'exponent': 1., 'strength': 1.} for k in BENEFITS},
            'smoothing': {'enabled': False, 'ms': 12., 'strength': .5},
            'direction_stability': {'enabled': False, 'degrees': 5., 'strength': .5}}

def validate(value):
    if not isinstance(value, dict): raise ValueError('Helpers must be an object')
    c=defaults(); c.update(copy.deepcopy(value))
    if set(c)!=set(defaults()) or set(c['contexts'])!=set(BENEFITS): raise ValueError('Unknown response helper')
    for row in c['contexts'].values():
        if not isinstance(row,dict) or set(row)!={'enabled','exponent','strength'}: raise ValueError('Invalid helper response')
        if type(row['enabled']) is not bool: raise ValueError('Helper enabled must be true/false')
        number(row['exponent'],.25,4);number(row['strength'],0,1)
    for key,parameter,lo,hi in [('smoothing','ms',0,40),('direction_stability','degrees',0,15)]:
        row=c[key]
        if not isinstance(row,dict) or set(row)!={'enabled',parameter,'strength'} or type(row['enabled']) is not bool: raise ValueError('Invalid movement helper')
        number(row[parameter],lo,hi);number(row['strength'],0,1)
    return c

class HelperEngine:
    def __init__(self): self.reset()
    def reset(self): self.previous=None;self.last_ns=None;self.trace=[]
    def apply(self,axes,buttons,physical,p,armed,now,context='movement'):
        a=dict(axes);self.trace=[]
        if not armed:
            self.reset();return a
        c=p['helpers'];old=self.previous;dt=(now-self.last_ns)/1e6 if self.last_ns is not None else 0
        if dt<0 or dt>100:old=None
        def record(label,before):
            if a!=before:self.trace.append((label,dict(a),dict(buttons)))
        # Existing shoot/pass/cross aim curves have priority. Other held contexts
        # use one explicit order: through pass, dribble, jockey, sprint.
        conditions={'through_pass':buttons.get('Triangle'), 'controlled_dribble':buttons.get('R1'),
                    'jockey':physical.get('L2',0)>.1,'sprint':physical.get('R2',0)>.1,
                    'goalkeeper':buttons.get('R3')}
        ls_used=False
        for k in BENEFITS:
            row=c['contexts'][k]
            if not row['enabled'] or not conditions[k]:continue
            if k!='goalkeeper' and (context!='movement' or ls_used):continue
            x,y=('RX','RY') if k=='goalkeeper' else ('LX','LY');r=math.hypot(a[x],a[y]);before=dict(a)
            if r:
                magnitude=min(1,r);target=magnitude+(magnitude**row['exponent']-magnitude)*row['strength']
                a[x]*=target/r;a[y]*=target/r
            record(BENEFITS[k][1],before)
            if k!='goalkeeper':ls_used=True
        # Temporal helpers only affect LS. Neutral, reversals and full travel
        # bypass memory immediately; no queued input, button holds or sleepers.
        before=dict(a);x,y=a['LX'],a['LY'];r=math.hypot(x,y)
        if old and 0<r<.98 and x*old['LX']+y*old['LY']>0:
            s=c['smoothing']
            if s['enabled'] and s['ms']>0 and dt>0:
                retention=math.exp(-dt/s['ms'])*s['strength']
                a['LX']=x*(1-retention)+old['LX']*retention
                a['LY']=y*(1-retention)+old['LY']*retention
            d=c['direction_stability'];pr=math.hypot(old['LX'],old['LY'])
            if d['enabled'] and pr:
                current=math.atan2(a['LY'],a['LX']);previous=math.atan2(old['LY'],old['LX'])
                delta=math.atan2(math.sin(current-previous),math.cos(current-previous))
                if abs(math.degrees(delta))<d['degrees']:
                    angle=current-delta*d['strength'];magnitude=math.hypot(a['LX'],a['LY'])
                    a['LX']=math.cos(angle)*magnitude;a['LY']=math.sin(angle)*magnitude
        record('Movement smoothing / directional stability',before)
        self.previous=dict(a);self.last_ns=now
        return a
