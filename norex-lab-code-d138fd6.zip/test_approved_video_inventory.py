import unittest
import approved_video_inventory as v

class ApprovedVideoInventoryTests(unittest.TestCase):
 def test_only_supplied_sources_and_explicit_execution_boundary(self):
  d=v.document()
  self.assertEqual(set(d['sources']),{'t67iexOyTNM','AFjd0Y29HAc'})
  self.assertTrue(d['observations'])
  for r in d['observations']:
   self.assertEqual(r['video_id'],'AFjd0Y29HAc')
   self.assertFalse(r['game_execution_verified']);self.assertIsNone(r['timing_ms'])
 def test_fc26_never_promoted_to_fc27(self):
  self.assertEqual(v.reference('Ronaldo Fenomeno')['game_status'],'FC26 video reference; FC27 not established')
 def test_duplicate_source_requirements_remain_ambiguous(self):
  r=v.reference('Feint & Exit')
  self.assertIsNone(r['stars']);self.assertIn('conflict',r['notes'].lower())
 def test_unknown_slot_has_no_invented_input(self):
  r=v.reference('Rabona To Scorpion Kick')
  self.assertIsNone(r['ps5_input']);self.assertEqual(r['sources'],[])
 def test_names_alone_do_not_create_timed_recipes(self):
  from skills import seeds
  for name in ('Ronaldo Fenomeno','Big Feint','Fake Shot Turn'):
   self.assertIn(name,seeds());self.assertEqual(seeds()[name]['steps'],[])
