"""Independent local input assists. No game state or outcome prediction."""
import copy
import math
from pipeline import BUTTONS, AXES, number

TOGGLES=('auto_jockey','perfect_sprint','precision_pass','fast_dribble','speed_boost','timed_pass','timed_cross','timed_shot','low_driven','perfect_lowdrive','auto_power_shot','finesse_finish')

def defaults():
    return {**{t:False for t in TOGGLES},'sprint_strength':100,'pass_ms':200,'cross_ms':300,'shot_ms':150,
            'followup_delay_ms':80,'followup_press_ms':40,'boost_ms':80,'aim_angle':0,'facing_angle':270,
            'finesse_delay_ms':180,'lock_ms':80,'lock_button':'Disabled','skill_direction_mode':'movement',
            'button_skills':{str(i):{'button':'Disabled','skill':'Disabled'} for i in (1,2)},
            'shot_types':{'lace':False,'finesse':False,'flair':False,'power':False},
            'action_buttons':{'pass':'Cross','cross':'Square','shot':'Circle'},
            'skills':{d:'Disabled' for d in ('up','down','left','right')},'flex':{d:'Disabled' for d in ('up','down','left','right')}}

def validate(config):
    if not isinstance(config,dict): raise ValueError('Assists must be an object')
    c=defaults(); c.update(copy.deepcopy(config))
    if set(c)!=set(defaults()): raise ValueError('Unknown assist setting')
    for t in TOGGLES:
        if type(c[t]) is not bool: raise ValueError('Assist toggles must be true/false')
    for key in ('pass_ms','cross_ms','shot_ms'): number(c[key],50,500)
    number(c['sprint_strength'],0,100); number(c['boost_ms'],20,300)
    number(c['followup_delay_ms'],20,300); number(c['followup_press_ms'],20,150)
    number(c['aim_angle'],0,359); number(c['facing_angle'],0,359)
    if c['skill_direction_mode'] not in ('movement','fixed'):raise ValueError('Skill direction mode must be movement or fixed')
    if not isinstance(c['shot_types'],dict) or set(c['shot_types'])!={'lace','finesse','flair','power'} or any(type(x) is not bool for x in c['shot_types'].values()): raise ValueError('Invalid shot types')
    if not isinstance(c['action_buttons'],dict) or set(c['action_buttons'])!={'pass','cross','shot'} or len(set(c['action_buttons'].values()))!=3 or any(v not in BUTTONS.values() for v in c['action_buttons'].values()): raise ValueError('Action buttons must be three distinct gamepad buttons')
    number(c['finesse_delay_ms'],20,1000); number(c['lock_ms'],20,200)
    from skills import CATALOG,FLEX
    slots=c['button_skills']
    if not isinstance(slots,dict) or set(slots)!={'1','2'}: raise ValueError('Two button skill slots required')
    assigned=[]
    for row in slots.values():
        if not isinstance(row,dict) or set(row)!={'button','skill'} or row['button'] not in (*BUTTONS.values(),'Disabled') or row['skill'] not in (*CATALOG,'Disabled'): raise ValueError('Invalid button skill slot')
        if (row['button']=='Disabled') != (row['skill']=='Disabled'): raise ValueError('Select both a button and skill, or disable both')
        if row['button']!='Disabled': assigned.append(row['button'])
    if c['lock_button'] not in (*BUTTONS.values(),'Disabled'): raise ValueError('Invalid player-lock button')
    if c['lock_button']!='Disabled': assigned.append(c['lock_button'])
    if len(assigned)!=len(set(assigned)): raise ValueError('Skill and lock trigger buttons must be distinct')
    for k in ('skills','flex'):
        if not isinstance(c[k],dict) or set(c[k])!={'up','down','left','right'} or any(v not in (*(FLEX if k=='flex' else CATALOG),'Disabled') for v in c[k].values()): raise ValueError('Invalid skill assignment')
    return c

class AssistEngine:
    def __init__(self):
        import collections
        self.history=collections.deque(maxlen=8); self.pending_list=None; self.list_ctx=None  # survive reset(): the viewer shows previous / next
        self.reset()
    def reset(self):
        self.previous={b:False for b in BUTTONS.values()}; self.timers={}; self.previous_shot=False
        self.low_pending=False; self.finesse_pending=False; self.finesse_mode=False; self.lock_until=0; self.followup=None; self.boost=None; self.rs_latched=False
        self.active_recipe=None; self.recipe_started=0; self.recipe_name=None; self.message=None; self.last_ns=0
        self.movement_angle=None;self.recipe_angle=None;self.recipe_direction_source=None;self.recipe_relative=None
    def cancel(self):
        # Drop generated holds and any running recipe but keep edge memory, so a
        # button that is still physically held cannot re-trigger on the next frame.
        keep={k:getattr(self,k) for k in ('previous','previous_shot','rs_latched','movement_angle','last_ns')}
        self.reset(); self.__dict__.update(keep)
    def prime(self,buttons,axes=None):
        # Arming while a control is already held never triggers a synthetic edge.
        self.previous={b:bool(buttons.get(b,False)) for b in BUTTONS.values()}
        axes=axes or {}; self.observe_movement(axes)
        self.previous['_sprint']=axes.get('R2',0)>.1 or bool(buttons.get('R2 button'))
        self.rs_latched=math.hypot(axes.get('RX',0),axes.get('RY',0))>.75
    def observe_movement(self,axes):
        # Only physical LS samples are supplied by the authoritative pipeline.
        # Neutral and drift never overwrite the last intentional direction.
        x,y=axes.get('LX',0),axes.get('LY',0)
        if math.isfinite(x) and math.isfinite(y) and math.hypot(x,y)>.15:
            self.movement_angle=math.degrees(math.atan2(y,x))%360
    def orientation_status(self,c):
        movement=c.get('skill_direction_mode','fixed')=='movement'
        live=self.movement_angle if movement and self.movement_angle is not None else c['facing_angle']
        source='last_left_stick' if movement and self.movement_angle is not None else 'manual_fallback' if movement else 'manual'
        active=bool(self.active_recipe) and self.recipe_angle is not None
        return {'mode':c.get('skill_direction_mode','fixed'),'angle':self.recipe_angle if active else live,
                'source':self.recipe_direction_source if active else source,'captured':active,
                'last_movement_angle':self.movement_angle,'movement_threshold':.15,'recipe':self.recipe_name if active else None,
                'relative':self.recipe_relative if active else None,'basis':'Physical left-stick direction; player facing is not game telemetry'}
    def capture_orientation(self,c,relative):
        self.recipe_relative=bool(relative)
        status=self.orientation_status(c)
        self.recipe_angle=status['angle'] if relative else 270
        self.recipe_direction_source=status['source'] if relative else 'screen_fixed'
    def start_recipe(self,name,steps,now,config=None,relative=None):
        if self.active_recipe: raise ValueError('A skill recipe is already running')
        if not steps: raise ValueError('No input recipe configured for this skill')
        self.active_recipe=copy.deepcopy(steps); self.recipe_started=now; self.recipe_name=name; self.message=None
        self.history.append({'name':name,'list':self.pending_list}); self.list_ctx=self.pending_list; self.pending_list=None
        self.recipe_angle=None;self.recipe_direction_source=None;self.recipe_relative=relative
        if config is not None and relative is not None:self.capture_orientation(config,relative)
    def apply(self,axes,buttons,c,now,recipes,physical_axes=None):
        self.observe_movement(physical_axes if physical_axes is not None else axes)
        if self.last_ns and now-self.last_ns>200_000_000:
            self.timers={}; self.followup=None; self.boost=None; self.active_recipe=None; self.recipe_name=None; self.recipe_angle=None; self.recipe_direction_source=None; self.recipe_relative=None; self.low_pending=False; self.finesse_pending=False; self.lock_until=0
            self.message='Pending actions cancelled after scheduler delay'
        self.last_ns=now
        self.trace_steps=[];self.activations=[]
        a=dict(axes); b={k:bool(buttons.get(k,False)) for k in BUTTONS.values()}
        previous_trace=[dict(a),dict(b)]
        def checkpoint(label):
            if a!=previous_trace[0] or b!=previous_trace[1]:
                self.trace_steps.append((label,dict(a),dict(b)));previous_trace[:]=[dict(a),dict(b)]
        physical=dict(b); action=c['action_buttons']; shot=action['shot']
        rising=lambda key: physical[key] and not self.previous.get(key,False)
        sprint=axes.get('R2',0)>.1 or physical['R2 button']
        attacking=any(physical[x] for x in (*action.values(),'Triangle'))
        if c['perfect_sprint'] and sprint:
            a['R2']=c['sprint_strength']/100; b['R2 button']=a['R2']>.1
        checkpoint('Sprint strength')
        if c['auto_jockey'] and not attacking and not sprint: a['L2']=1.; b['L2 button']=True
        checkpoint('Automatic L2 hold')
        if c['fast_dribble'] and math.hypot(axes.get('LX',0),axes.get('LY',0))>.15 and not attacking and not sprint: b['R1']=True
        checkpoint('Controlled sprint')
        for name in ('pass','cross','shot'):
            key=action[name]
            if c['timed_'+name] and rising(key): self.timers[key]=now+c[name+'_ms']*1_000_000;self.activations.append('Fixed '+name+' hold')
            if key in self.timers:
                b[key]=now<self.timers[key]
                if not physical[key] and now>=self.timers[key]: del self.timers[key]
            checkpoint('Fixed '+name+' hold')
        checkpoint('Fixed action holds')
        if rising(shot):
            self.finesse_mode=c['finesse_finish'] and physical['R1'] and not physical['L1']
            kind='power' if (physical['L1'] and physical['R1']) or c['auto_power_shot'] else ('finesse' if physical['R1'] else ('flair' if physical['L2 button'] or axes.get('L2',0)>.1 else 'lace'))
            chip=physical['L1'] and not physical['R1'] and not c['auto_power_shot']
            self.low_pending=not self.finesse_mode and not chip and ((c['low_driven'] and c['shot_types'][kind]) or (c['perfect_lowdrive'] and c['timed_shot']))
            self.followup=None
        if rising(shot): self.finesse_pending=self.finesse_mode
        if self.previous_shot and not b[shot] and (self.low_pending or self.finesse_pending):
            start=now+(c['finesse_delay_ms'] if self.finesse_pending else c['followup_delay_ms'])*1_000_000; self.followup=(start,start+c['followup_press_ms']*1_000_000); self.low_pending=False; self.finesse_pending=False
        self.previous_shot=b[shot]
        if self.followup:
            start,end=self.followup
            if start<=now<end: b[shot]=True
            if now>=end: self.followup=None
        checkpoint('Shot follow-up')
        if self.finesse_mode and b[shot]: b['R1']=True
        checkpoint('Finesse modifier')
        if c['precision_pass'] and b[action['pass']]: b['R1']=True
        checkpoint('Driven pass modifier')
        if c['auto_power_shot'] and not self.finesse_mode and b[shot]: b['L1']=b['R1']=True
        checkpoint('Power-shot modifiers')
        if c['aim_angle']>0 and b[shot] and b['L1'] and b['R1']:
            angle=math.radians(c['aim_angle']); a['LX']=math.cos(angle); a['LY']=math.sin(angle)
        checkpoint('Power aim direction')
        prev_sprint=self.previous.get('_sprint',False)
        if c['speed_boost'] and sprint and not prev_sprint and math.hypot(axes.get('LX',0),axes.get('LY',0))>.15:
            r=math.hypot(axes['LX'],axes['LY']); self.boost=(now+c['boost_ms']*1_000_000,axes['LX']/r,axes['LY']/r)
        if self.boost:
            if now<self.boost[0]: a['RX'],a['RY']=self.boost[1:]
            else: self.boost=None
        checkpoint('Sprint stick flick')
        r=math.hypot(axes.get('RX',0),axes.get('RY',0))
        if r<.25: self.rs_latched=False
        if r>.75 and not self.rs_latched:
            self.rs_latched=True; x,y=axes['RX'],axes['RY']
            direction=('right' if x>0 else 'left') if abs(x)>abs(y) else ('down' if y>0 else 'up')
            group='flex' if physical['L1'] and physical['R1'] else 'skills'; name=c[group][direction]
            if name!='Disabled' and not self.active_recipe:
                steps=recipes.get(name,{}).get('steps',[])
                if steps: self.start_recipe(name,steps,now,config=c,relative=recipes[name].get('relative',False))
                else: self.message=f'{name}: input recipe required'
        checkpoint('Right-stick skill activation')
        for row in c['button_skills'].values():
            key,name=row['button'],row['skill']
            if key!='Disabled':
                b[key]=False
                if key in ('L2 button','R2 button'): a[key[:2]]=0.
                if rising(key) and not self.active_recipe:
                    steps=recipes.get(name,{}).get('steps',[])
                    if steps: self.start_recipe(name,steps,now,config=c,relative=recipes[name].get('relative',False))
                    else: self.message=f'{name}: input recipe required'
        checkpoint('Button skill activation')
        key=c['lock_button']
        if key!='Disabled':
            b[key]=False
            if key in ('L2 button','R2 button'): a[key[:2]]=0.
            if rising(key): self.lock_until=now+c['lock_ms']*1_000_000
            if now<self.lock_until: b['L3']=b['R3']=True
        checkpoint('Player-lock chord')
        if self.active_recipe:
            if self.recipe_angle is None:self.capture_orientation(c,recipes.get(self.recipe_name,{}).get('relative',False))
            elapsed=(now-self.recipe_started)/1e6; chosen=None; total=0
            for step in self.active_recipe:
                total+=step['ms']
                if elapsed<total: chosen=step; break
            if chosen:
                # Only declared controls are overridden; other physical input passes through.
                controls={k for step in self.active_recipe for k in step.get('axes',{})}
                keys={k for step in self.active_recipe for k in step.get('buttons',{})}
                for k in controls: a[k]=chosen.get('axes',{}).get(k,0)
                for k in keys: b[k]=chosen.get('buttons',{}).get(k,False)
                if self.recipe_relative:
                    angle=math.radians(self.recipe_angle-270); cosine=math.cos(angle); sine=math.sin(angle)
                    for x,y in (('LX','LY'),('RX','RY')):
                        if x in controls or y in controls:
                            xx=chosen.get('axes',{}).get(x,0); yy=chosen.get('axes',{}).get(y,0); a[x]=xx*cosine-yy*sine; a[y]=xx*sine+yy*cosine
            else:
                # Each call starts from a fresh upstream frame. Dropping the
                # recipe overlay releases synthetic input and preserves held input.
                self.active_recipe=None; self.recipe_name=None
                self.recipe_angle=None; self.recipe_direction_source=None; self.recipe_relative=None
        checkpoint('Recipe sequence')
        self.previous=physical; self.previous['_sprint']=sprint
        return a,b
