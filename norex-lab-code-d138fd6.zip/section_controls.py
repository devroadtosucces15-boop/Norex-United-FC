"""Reversible section enhancement switches, owned by the server."""
from copy import deepcopy
from pipeline import default_profile
SECTIONS=('Overview','Helpers','Skills','Controller','Profiles','Recording','Modes','Diagnostics')

def paths(section):
    if section=='Helpers':
        return [('assists',k) for k in default_profile()['assists'] if k!='button_skills']+[('advanced',),('helpers',),('backbone_helpers',),('play_tools','shot_response')]
    if section=='Skills':return [('backbone_skills',),('assists','button_skills'),('play_tools','skill_bindings')]
    if section=='Controller':return [(k,) for k in ('deadzone','centers','ranges','trigger_deadzone','curves','button_map','axis_map','invert','visual')]+[('play_tools','outer')]
    return []
def get(p,path):
    for key in path:p=p[key]
    return deepcopy(p)
def put(p,path,value):
    for key in path[:-1]:p=p[key]
    p[path[-1]]=deepcopy(value)
def enforce(r,p):
    p=deepcopy(p);defaults=default_profile()
    for section,enabled in r.sections.items():
        if not enabled:
            for path in paths(section):put(p,path,get(defaults,path))
    return p

def _toggle(r,section,enabled):
    if section not in SECTIONS or type(enabled) is not bool:raise ValueError('Invalid section switch')
    if not r.master_enabled:raise ValueError('Turn Custom + Chiaki ON first')
    if r.sections[section]==enabled:return
    p=deepcopy(r.profile)
    if enabled:
        for path,value in r.section_saved.pop(section,{}).items():put(p,path,value)
        if section=='Modes' and r.section_modes is not None:r.mode_bank=r.section_modes;r.section_modes=None
    else:
        r.section_saved[section]={path:get(p,path) for path in paths(section)}
        for path in paths(section):put(p,path,get(default_profile(),path))
        if section=='Overview':r.compare_state.finish('Overview disabled');r.set_processing_mode('NOREX')
        if section=='Recording':r.end_record();r.stop_replay();r.finish_frames('Recording disabled')
        if section=='Modes':
            r.select_mode('None');p=deepcopy(r.profile)
            r.section_modes=deepcopy(r.mode_bank);r.mode_bank.enabled=False
    r.sections[section]=enabled;r.apply_profile(enforce(r,p));r.revision+=1

def toggle(r,section,enabled):
    # Restoring a section can collide with changes made in another submenu.
    # Validate before touching saved section state or any active processing.
    if enabled and section in SECTIONS and not r.sections.get(section,True):
        from pipeline import validate_profile
        from conflict_rules import validate_global
        candidate=deepcopy(r.profile)
        for path,value in r.section_saved.get(section,{}).items():put(candidate,path,value)
        bank=r.section_modes if section=='Modes' and r.section_modes is not None else r.mode_bank
        validate_global(validate_profile(candidate),bank,r.profile,r.mode_bank)
    return _toggle(r,section,enabled)

ACTION_SECTIONS={
 'Overview':('set_mode','comparison_start','comparison_stop','comparison_choose'),
 'Helpers':('helpers_configure','set_assist_enabled','defending_mode'),
 'Skills':('skill_recipe_save','skill_recipe_remove','skill_bindings','skill_mapping_set','skill_save','skill_from_capture','skill_run','skill_pack'),
 'Controller':('calibrate','deadzone'),
 'Profiles':('save','load','profile_save','profile_load'),
 'Recording':('record','record_frames','replay'),
 'Modes':('mode_select','mode_save','mode_hotkeys'),
}
def check_action(r,action):
    if not getattr(r,'command_center',False):return
    for section,actions in ACTION_SECTIONS.items():
        if action in actions and not r.sections[section]:raise ValueError(section+' options are OFF; restore that section first')
