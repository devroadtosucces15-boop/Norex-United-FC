(()=>{
'use strict';
const groups={play:['play','diagnostics'],connections:['connections'],reports:['reports'],automation:['automation','controls'],routeLab:['routeLab','networkDetails'],storage:['storage'],events:['events'],readiness:['readiness','recovery']};
const titles={play:'Play',connections:'Connections',reports:'Match reports',automation:'Helpers',routeLab:'Tools',storage:'Recordings',events:'Events',readiness:'System'};
const sections=Array.from(document.querySelectorAll('main > section'));
let selectedIP=null;
function activate(target,focus=false){
 const key=Object.keys(groups).find(k=>groups[k].includes(target))||'play';
 for(const section of sections)section.hidden=!groups[key].includes(section.id);
 for(const link of document.querySelectorAll('.rail nav a')){const active=link.getAttribute('href')==='#'+key;link.classList.toggle('current',active);if(active)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current')}
 document.getElementById('viewTitle').textContent=titles[key];document.title='Norex · '+titles[key];
 document.body.dataset.view=key;window.scrollTo({top:0,behavior:'instant'});
 if(focus){const title=document.getElementById('viewTitle');title.tabIndex=-1;title.focus({preventScroll:true})}
}
function show(target){if(location.hash!=='#'+target)location.hash=target;activate(target)}
window.addEventListener('hashchange',()=>activate(location.hash.slice(1)));
document.addEventListener('gateway:view',e=>show(e.detail));
document.querySelector('.rail nav').addEventListener('click',e=>{const link=e.target.closest('a');if(link){e.preventDefault();show(link.hash.slice(1));activate(link.hash.slice(1),true)}});
function inspection(){
 const body=document.getElementById('inspectionBody'),button=document.getElementById('inspectRoute');
 if(!selectedIP){body.innerHTML='<p class="hint">Select Inspect on an observed address to see its role, location and source.</p>';button.disabled=true;return}
 const endpoint=lastData?.endpoints.find(e=>e.ip===selectedIP);button.disabled=!endpoint;
 for(const row of document.querySelectorAll('#cards article'))row.classList.toggle('inspected',row.dataset.ip===selectedIP);
 if(!endpoint){body.innerHTML=`<b class="inspected-ip">${esc(selectedIP)}</b><p class="hint">This address is no longer in the recent observation window. Select another connection.</p>`;return}
 const a=endpoint.assessment,g=endpoint.location,place=g?[g.city,g.region,g.country].filter(Boolean).join(', '):'Location unavailable';
 body.innerHTML=`<b class="inspected-ip">${esc(endpoint.ip)}</b><dl><dt>Likely role</dt><dd>${esc(a.role)} · ${esc(a.confidence)} confidence</dd><dt>Why this assessment</dt><dd>${esc(a.reason)}</dd><dt>Approximate location</dt><dd>${esc(place)}</dd><dt>Provider</dt><dd>${esc(g?.connection?.org||g?.connection?.isp||'Unknown')}</dd><dt>Observed source</dt><dd>${esc(a.source)}<br>${esc(a.dns_source)}</dd><dt>Activity</dt><dd>${endpoint.active?'Active':'Recent'} · ${endpoint.flow_count} flows<br>↑ ${(endpoint.up_bytes/1024).toFixed(1)} / ↓ ${(endpoint.down_bytes/1024).toFixed(1)} KiB</dd></dl>${endpoint.map_url?`<a href="${esc(endpoint.map_url)}" target="_blank" rel="noopener noreferrer">View map ↗</a>`:''}`;
}
document.getElementById('cards').addEventListener('click',e=>{const b=e.target.closest('[data-inspect-ip]');if(b){selectedIP=b.dataset.inspectIp;inspection();if(innerWidth<900)document.getElementById('evidenceInspector').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth',block:'nearest'})}});
document.getElementById('clearInspection').onclick=()=>{selectedIP=null;inspection();for(const row of document.querySelectorAll('#cards article'))row.classList.remove('inspected')};
document.getElementById('inspectRoute').onclick=()=>{if(selectedIP){document.getElementById('target').value=selectedIP;show('routeLab');document.getElementById('target').focus()}};
function status(){const node=document.getElementById('surfaceStatus');node.textContent=lastData?.error?'Observations unavailable':lastData?.ps5_online?'PS5 traffic observed':'PS5 quiet';node.classList.toggle('healthy',Boolean(lastData?.ps5_online&&!lastData?.error));inspection()}
document.addEventListener('gateway:live',status);
activate(location.hash.slice(1));status();
})();
