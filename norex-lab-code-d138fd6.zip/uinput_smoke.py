#!/usr/bin/env python3
"""Create a neutral gamepad, verify registration/state, then destroy it.

No pressed buttons or displaced axes are sent. Run as the normal desktop user
once /dev/uinput access is granted; do not run the web service as root.
"""
import glob, json, os, time
from pathlib import Path
from lab import ioctl_read
from virtual import UInputOutput, NAME
from pipeline import AXES

def matching():
    return [p for p in glob.glob('/sys/class/input/event*') if (Path(p)/'device/name').read_text().strip()==NAME]

if __name__=='__main__':
    before=matching(); sink=None
    try:
        sink=UInputOutput(); deadline=time.monotonic()+3; found=[]
        while time.monotonic()<deadline:
            found=[p for p in matching() if p not in before]
            if found: break
            time.sleep(.05)
        if not found: raise RuntimeError('Virtual device registration not observed')
        node='/dev/input/'+Path(found[0]).name
        deadline=time.monotonic()+3
        while not os.access(node,os.R_OK) and time.monotonic()<deadline: time.sleep(.05)
        fd=os.open(node,os.O_RDONLY|os.O_NONBLOCK)
        try:
            import struct
            for code in AXES:
                values=struct.unpack('6i',ioctl_read(fd,0x40+code,24))
                if values[0]!=0: raise RuntimeError('Expected neutral axis state')
            keys=ioctl_read(fd,0x18,96)
            if any(keys): raise RuntimeError('Expected all buttons released')
        finally: os.close(fd)
        print(json.dumps({'registered':node,'name':NAME,'neutral_axes':True,'buttons_released':True}))
    finally:
        if sink: sink.close()
    deadline=time.monotonic()+3
    while any(p not in before for p in matching()) and time.monotonic()<deadline: time.sleep(.05)
    if any(p not in before for p in matching()): raise RuntimeError('Virtual device teardown not observed')
    print('Virtual device teardown verified')
