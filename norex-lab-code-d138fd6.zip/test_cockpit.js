// Cockpit coverage: every option, stored number and shortcut the Lab exposes must have a control in the cockpit.
const fs=require('fs'),vm=require('vm'),{execFileSync}=require('child_process');
const ctx={document:{addEventListener(){},querySelector(){return null}},localStorage:{getItem(){return null},setItem(){}},window:{}};vm.createContext(ctx);
vm.runInContext(fs.readFileSync('ui/cockpit.js','utf8')+';this.__goals=cockpit.goals',ctx);
ctx.__paths=null;const goals=ctx.__goals,paths=new Set();
goals.forEach(g=>{(g.alts||[]).forEach(a=>{paths.add(a.p);(a.nums||[]).forEach(n=>paths.add(n.p))});(g.nums||[]).forEach(n=>paths.add(n.p))});
const py=JSON.parse(execFileSync('python3',['-c',"import json,conflict_rules as c;from pipeline import default_profile as d;p=d();print(json.dumps({'options':[r['id'] for r in c.option_rows()],'shortcuts':list(p['advanced']['shortcuts']),'assists':[k for k,v in p['assists'].items() if isinstance(v,(int,float)) and not isinstance(v,bool)],'adv':[k for k,v in p['advanced'].items() if k.endswith('_ms')]}))"],{encoding:'utf8'}));
const miss=[];
py.options.forEach(o=>{if(!paths.has(o))miss.push('option '+o)});
const sc=new Set(goals.flatMap(g=>g.shortcuts||[]));py.shortcuts.forEach(k=>{if(!sc.has(k))miss.push('shortcut '+k)});
py.assists.forEach(k=>{if(!paths.has('assists.'+k))miss.push('assist number '+k)});
py.adv.forEach(k=>{if(!paths.has('advanced.'+k))miss.push('advanced timing '+k)});
['advanced.defense_only_jockey','play_tools.mapping_dwell_ms'].forEach(p=>{if(!paths.has(p))miss.push(p)});
const ids=goals.map(g=>g.id);if(new Set(ids).size!==ids.length)miss.push('duplicate goal ids');
if(miss.length){console.error('Cockpit is missing controls for:\n '+miss.join('\n '));process.exit(1)}
console.log('Cockpit covers every option, number and shortcut ('+goals.length+' goals)');

// A game preset must round-trip each helper's tunable numbers, not just its switch.
const assert=require('assert');
const model=JSON.parse(execFileSync('python3',['-c',"import json;from pipeline import default_profile;from backbone.helper_contract import HELPERS;print(json.dumps({'profile':default_profile(),'helpers':HELPERS}))"],{encoding:'utf8'}));
const actions=[];
const testContext={...ctx,structuredClone,esc:String,helpers:{helpers:model.helpers},effective:{configuration:model.profile,helpers_v2:{configured:model.profile.backbone_helpers},global_rules:{blocked:{}}},setProfilePath(o,p,v){const keys=p.split('.');const last=keys.pop();keys.reduce((n,k)=>n[k],o)[last]=v},act(action,body){actions.push({action,body});return Promise.resolve()}};
vm.createContext(testContext);
vm.runInContext(fs.readFileSync('ui/cockpit.js','utf8').replace('return {live,tune,feel,feelPlan,ROLES,setups,tools,sync,init,navHtml,refreshPop,goals:GOALS,openPalette,PHASES};','return {snapshotValues,selectAlt,blocked,goalCard,shapeOf,radialY,goals:GOALS};')+';this.testCockpit=cockpit',testContext);
const cp=testContext.testCockpit,snapshot=cp.snapshotValues();
for(const [name,row] of Object.entries(model.profile.backbone_helpers))for(const [key,value] of Object.entries(row))assert.equal(snapshot['backbone_helpers.'+name+'.'+key],value,'preset loses '+name+'.'+key);
const stored=JSON.parse(execFileSync('python3',['-c',"import json,sys,tempfile;from pathlib import Path;import game_presets as g;from pipeline import default_profile,validate_profile;v=json.load(sys.stdin);d=Path(tempfile.mkdtemp());g.save(d,'Rush','Attack',v);print(json.dumps(g.read(d)['presets']['Rush']['Attack']['values']))"],{input:JSON.stringify(snapshot),encoding:'utf8'}));
assert.deepEqual(stored,snapshot,'backend preset store preserves the complete Tune snapshot');
const filter=cp.goals.find(g=>g.id==='filter');
model.profile.backbone_helpers.smoothing.enabled=true;
cp.selectAlt(filter,filter.alts.find(a=>a.k==='lock'));
assert.equal(actions.length,1,'alternative switch must be one atomic action');
assert.equal(actions[0].body.profile.backbone_helpers.smoothing.enabled,false);
assert.equal(actions[0].body.profile.backbone_helpers.direction_stability.enabled,true);
const target=filter.alts.find(a=>a.k==='lock');
testContext.effective.global_rules.blocked[target.p]=[{options:filter.alts.map(a=>a.p),names:['Filter'],reason:'Choose one'}];
assert.equal(cp.blocked(target),'','same-goal conflict must allow version switching');
testContext.effective.global_rules.blocked[target.p].push({options:[target.p,'assists.timed_shot'],names:['Timed shot'],reason:'External conflict'});
assert.match(cp.blocked(target),/External conflict/,'external conflicts stay blocked');
model.profile.backbone_helpers.precision_stick.enabled=false;
const card=cp.goalCard(cp.goals.find(g=>g.id==='precision'),true);
assert.match(card,/data-gk="strength"/,'off card keeps strength available');
assert.match(card,/class="pv"/,'off card keeps its comparison preview');
assert.match(card,/data-exponent="1.8"/,'preview uses the backend curve default');
console.log('Cockpit presets retain helper numbers; atomic switching, conflicts and off-card previews passed');
const numerical=JSON.parse(execFileSync('python3',['-c',"import json;from backbone.engine import _radial;print(json.dumps([_radial({'LX':m,'LY':0},'LX','LY',1.8,.7)['LX'] for m in [0,.25,.5,.75,1]]))"],{encoding:'utf8'}));
[0,.25,.5,.75,1].forEach((m,i)=>assert(Math.abs(cp.radialY(m,.7,1.8)-numerical[i])<1e-10,'preview must match the isolated backend response'));
console.log('Stick preview matches backend numerical response at neutral, partial and full travel');
