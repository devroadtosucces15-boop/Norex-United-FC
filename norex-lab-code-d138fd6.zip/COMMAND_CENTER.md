# Controller Lab quick switches and Chiaki lifecycle

Implemented on ME2001, October 7, 2026. Open http://127.0.0.1:8790.

The single main button is now **Custom + Chiaki**.

- ON restores the custom setup retained from the previous OFF in this running session, opens one virtual output, arms configured helpers, discovers the registered PS5 on the current network, and launches one tracked Chiaki streaming window.
- Repeated ON does not launch another output or Chiaki process.
- Launch failure returns the master and virtual output to OFF. Closing the Chiaki process also switches custom input OFF.
- OFF neutralizes and removes virtual output, disarms helpers, ends active Lab operations, and closes only Lab-owned child sessions. The command-center supervisor remains available.
- Current active settings return to defaults while OFF. The custom setup remains in memory for restoration on the next ON. Named profile archives remain intact; use a named profile to preserve a setup across restarting the command center.
- OFF fades and disables the settings beneath the section switch. Backend mutation checks enforce the same rule.

Every navigation section has a quick switch at its top: Overview, Helpers, Skills, Controller, Profiles, Recording, Modes, Diagnostics. Enhancement sections disable their configuration and restore the captured values when reenabled. Utility sections disable their operations; turning Recording OFF also ends recording/replay. Section switches are unavailable while the main master is OFF. Existing server-authoritative polling and stale-edit rejection apply to these switches too.

The hard-coded old gateway address is removed. Registered-console discovery follows the Chiaki discovery protocol and matches the stored console identity without exposing registration credentials. Read-only discovery found the registered PS5 at its current local address. Protocol reference: https://github.com/chiaki-ng/chiaki-ng/blob/main/lib/src/discovery.c.

**Direct Bluetooth handoff:** closing Chiaki releases the Lab path, but the PC cannot guarantee that the DualSense automatically switches its Bluetooth connection back to the PS5. Press PS to reconnect if required. This limitation is stated in the interface. No pairing/unpairing or Bluetooth configuration was changed.

Validation: **211 Python tests and 23 subtests passed**. JavaScript regression checks passed for polling, the skill dialog, and disabled-state behavior under master/section OFF. JavaScript syntax passed. New tests cover independent section restoration, blocking edits to disabled sections, remembered setup restoration, one Chiaki launch across repeated ON, launch-failure rollback, and parsing registered-console identity.

The live browser was checked with the master OFF: controls were visibly faded and disabled. No live Remote Play session was launched for this change. PS5/game receipt and automatic Bluetooth return remain unverified. Final state: master OFF, Chiaki not running, no cleanup errors.

Operational commands:

```sh
cd /mnt/DEV_WORK/projects/norex-controller-lab-backbone
./labs start
./labs on       # Starts custom input AND the Lab-owned Chiaki session
./labs off      # Closes that session and disables custom input
./labs status
./labs stop
./labs test
```

Before-change source backups are in `work/section-switch-backup/`, with SHA256SUMS. Earlier backups and named profiles remain preserved. Changes are limited to the canonical Lab; no gateway services, Bluetooth pairing, unrelated repositories, or `.norex` were changed.
