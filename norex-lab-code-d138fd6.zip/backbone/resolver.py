"""One deterministic final-frame owner; never performs transport I/O."""
from dataclasses import dataclass
from copy import deepcopy
import math

PRIORITY = {'BASE':20, 'TRANSFORM':30, 'MODIFIER':40, 'SEQUENCE':60,
            'COMBO':70, 'SKILL':80, 'PHYSICAL_ESCAPE':90, 'SAFETY':100}

@dataclass(frozen=True)
class Intent:
    source: str
    control: str
    operation: str
    priority: int
    value: object

class ConflictResolver:
    def resolve(self, physical_axes, physical_buttons, intents=()):
        if not isinstance(physical_axes,dict) or not isinstance(physical_buttons,dict):raise ValueError('Resolver needs frame dictionaries')
        for key,value in physical_axes.items():
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not (0 if key in ('L2','R2') else -1)<=value<=1:
                raise ValueError('Physical axes must be finite and bounded')
        if any(type(value) is not bool for value in physical_buttons.values()):raise ValueError('Physical buttons must be boolean')
        axes, buttons = deepcopy(physical_axes), deepcopy(physical_buttons)
        winners, conflicts = {}, []
        # Explicit priority then source ID; never dependent on registration order.
        ordered = []
        for i in intents:
            if not isinstance(i, Intent) or not isinstance(i.source,str) or not i.source:
                raise ValueError('Invalid resolver intent')
            if type(i.priority) is not int or not 0 <= i.priority <= 100:
                raise ValueError('Invalid resolver priority')
            if i.operation == 'SET_AXIS':
                if i.control not in axes: raise ValueError('Unknown axis')
                if isinstance(i.value,bool) or not isinstance(i.value,(int,float)) or not math.isfinite(i.value):
                    raise ValueError('Axis intent must be finite')
            elif i.operation == 'SET_BUTTON':
                if i.control not in buttons or type(i.value) is not bool:
                    raise ValueError('Invalid button intent')
            else: raise ValueError('Unsupported resolver operation')
            ordered.append(i)
        for i in sorted(ordered,key=lambda x:(x.priority,x.source,x.operation,x.control)):
            key=(i.operation,i.control)
            old=winners.get(key)
            if old is not None:
                if old.priority==i.priority and old.source==i.source and old.value!=i.value:
                    raise ValueError('Contradictory intents from the same source')
                if old.value!=i.value:
                    conflicts.append({'control':i.control,'replaced':old.source,'winner':i.source,
                                      'replaced_priority':old.priority,'winner_priority':i.priority})
            winners[key]=i
        for i in winners.values():
            if i.operation=='SET_AXIS':
                axes[i.control]=max(0.0 if i.control in ('L2','R2') else -1.0,min(1.0,float(i.value)))
            else: buttons[i.control]=i.value
        return axes,buttons,conflicts

def frame_intents(source,priority,before_axes,before_buttons,axes,buttons):
    """Adapters propose only changed controls, preserving undeclared physical input."""
    return [Intent(source,k,'SET_AXIS',priority,v) for k,v in axes.items() if before_axes.get(k)!=v] + [
        Intent(source,k,'SET_BUTTON',priority,bool(v)) for k,v in buttons.items() if bool(before_buttons.get(k))!=bool(v)]

class CompareState:
    """Bounded session data; subjective results never certify gameplay or receipt."""
    def __init__(self):
        self.mode='NOREX'; self.results=[]; self.pair_id=0; self.samples={}; self.active=None
        self.frame_count=0; self.changed_frames=0; self.last_pair=None
    def set_mode(self,mode):
        if mode not in ('RAW','NOREX'):raise ValueError('mode must be RAW or NOREX')
        self.mode=mode
        return mode
    def raw(self):return self.set_mode('RAW')
    def processed(self):return self.set_mode('NOREX')
    def toggle(self):return self.set_mode('RAW' if self.mode=='NOREX' else 'NOREX')
    def observe(self,physical,final):
        self.frame_count+=1
        changed=physical.axes!=final.axes or physical.buttons!=final.buttons
        self.changed_frames+=int(changed)
        self.last_pair={'physical':physical.to_dict(),'final':final.to_dict(),'different':changed}
        if self.active:
            self.active['frames']+=1;self.active['changed_frames']+=int(changed)
    def start(self,mode,configuration):
        if self.active:raise ValueError('Finish the current sample first')
        if mode not in ('RAW','NOREX'):raise ValueError('mode must be RAW or NOREX')
        if mode!='RAW' and self.samples and next(iter(self.samples.values()))['configuration']!=configuration:
            raise ValueError('Configuration changed; start a new RAW sample')
        self.set_mode(mode)
        if mode=='RAW' or not self.pair_id:
            self.pair_id+=1;self.samples={}
        self.active={'pair_id':self.pair_id,'mode':mode,'frames':0,'changed_frames':0,
                     'configuration':deepcopy(configuration),'local_measurement_only':True}
    def finish(self,reason='operator'):
        if self.active:
            row=deepcopy(self.active);row['reason']=reason;self.samples[row['mode']]=row;self.active=None
    def choose(self,winner,notes=''):
        if winner not in ('RAW','NOREX','CANNOT_TELL'):raise ValueError('Invalid comparison result')
        if not isinstance(notes,str) or len(notes)>500:raise ValueError('Notes must be at most 500 characters')
        self.results.append({'pair_id':self.pair_id,'winner':winner,'notes':notes,
                             'samples':deepcopy(self.samples),'verification':'SUBJECTIVE_UNVERIFIED'})
        self.results=self.results[-32:]
    def status(self):
        return deepcopy({'mode':self.mode,'pair_id':self.pair_id,'active':self.active,'samples':self.samples,
                         'results':self.results,'frames':self.frame_count,'changed_frames':self.changed_frames,
                         'last_pair':self.last_pair,'game_verification':'UNVERIFIED'})
