#!/usr/bin/env python3
"""Keep the DualSense touchpad out of X11 pointer routing; evdev is untouched."""
import argparse
import ctypes as c
import time
import os
import fcntl
from pathlib import Path

TARGET = 'Sony Interactive Entertainment DualSense Wireless Controller Touchpad'

class Device(c.Structure):
    _fields_ = [('id', c.c_int), ('name', c.c_char_p), ('use', c.c_int),
                ('attachment', c.c_int), ('enabled', c.c_int),
                ('num_classes', c.c_int), ('classes', c.c_void_p)]

def apply(enabled=None):
    x = c.CDLL('libX11.so.6'); xi = c.CDLL('libXi.so.6')
    x.XOpenDisplay.argtypes = [c.c_char_p]; x.XOpenDisplay.restype = c.c_void_p
    x.XCloseDisplay.argtypes = [c.c_void_p]
    x.XInternAtom.argtypes = [c.c_void_p, c.c_char_p, c.c_int]; x.XInternAtom.restype = c.c_ulong
    x.XSync.argtypes = [c.c_void_p, c.c_int]
    xi.XIQueryDevice.argtypes = [c.c_void_p, c.c_int, c.POINTER(c.c_int)]
    xi.XIQueryDevice.restype = c.POINTER(Device)
    xi.XIFreeDeviceInfo.argtypes = [c.POINTER(Device)]
    xi.XIChangeProperty.argtypes = [c.c_void_p, c.c_int, c.c_ulong, c.c_ulong,
                                   c.c_int, c.c_int, c.POINTER(c.c_ubyte), c.c_int]
    display = x.XOpenDisplay(None)
    if not display: raise RuntimeError('An accessible X11 display is required')
    count = c.c_int(); devices = xi.XIQueryDevice(display, 0, c.byref(count))
    result = []
    try:
        for i in range(count.value):
            d = devices[i]; name = d.name.decode()
            if name != TARGET: continue
            result.append({'id': d.id, 'name': name, 'enabled': bool(d.enabled)})
            if enabled is not None and bool(d.enabled) != enabled:
                atom = x.XInternAtom(display, b'Device Enabled', 1)
                if not atom: raise RuntimeError('Device Enabled property is unavailable')
                value = c.c_ubyte(int(enabled))
                xi.XIChangeProperty(display, d.id, atom, 19, 8, 0, c.byref(value), 1)
                x.XSync(display, 0)
    finally:
        xi.XIFreeDeviceInfo(devices); x.XCloseDisplay(display)
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['status', 'disable', 'enable', 'watch'])
    args = parser.parse_args()
    if args.action == 'watch':
        # Desktop autostart and the current-session service share one owner.
        lock = open(Path(os.environ.get('XDG_RUNTIME_DIR', f'/run/user/{os.getuid()}')) / 'norex-dualsense-pointer.lock', 'a+')
        try: fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise SystemExit(0)
        while True:
            try: apply(False)
            except RuntimeError: pass  # X11 may be coming up during login.
            time.sleep(5)
    else:
        apply({'disable': False, 'enable': True}.get(args.action))
        print(apply())
