import copy,json,tempfile,threading,unittest,urllib.request,urllib.error
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
import lab
from skill_preferences import read,update
from backbone.fc27_data import ALL_SKILLS,SKILL_BY_ID
from backbone.skills import validate_recipe

class FavoriteHttpTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.data=Path(self.tmp.name)
  with patch.object(lab,'DATA',self.data):self.r=lab.Lab()
  self.r.command_center=True;self.r.master_enabled=False
  self.server=ThreadingHTTPServer(('127.0.0.1',0),lab.Handler);self.server.lab=self.r
  self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
  self.base='http://127.0.0.1:'+str(self.server.server_port)
 def tearDown(self):
  self.server.shutdown();self.server.server_close();self.thread.join();self.tmp.cleanup()
 def request(self,body=None,origin=None):
  url=self.base+('/api/skill-favorites' if body is not None else '/api/center')
  req=urllib.request.Request(url,data=json.dumps(body).encode() if body is not None else None,headers={'Origin':origin} if origin else {})
  try:
   with urllib.request.urlopen(req,timeout=3) as response:return response.status,json.load(response)
  except urllib.error.HTTPError as e:return e.code,json.load(e)
 def test_persistent_shared_favorites_without_power_or_profile_changes(self):
  before=copy.deepcopy(self.r.profile);revision=self.r.revision
  for key in ('canonical:reverse_elastico','canonical:trickster_fake_shot','existing:Ball Roll Left'):
   status,row=self.request({'key':key,'favorite':True});self.assertEqual(status,200)
  self.assertEqual(len(read(self.data)['favorites']),3)
  self.assertEqual(self.request()[1]['skill_preferences'],read(self.data))
  self.assertEqual(self.r.profile,before);self.assertEqual(self.r.revision,revision)
  self.assertFalse(self.r.master_enabled);self.assertIsNone(self.r.output)
  self.request({'key':'canonical:reverse_elastico','favorite':False})
  self.assertNotIn('canonical:reverse_elastico',read(self.data)['favorites'])
 def test_invalid_or_external_requests_do_not_mutate_preferences(self):
  update(self.data,'canonical:reverse_elastico',True);before=read(self.data)
  for body in ({'key':'unknown','favorite':True},{'key':'canonical:reverse_elastico','favorite':1},{'key':'canonical:reverse_elastico','favorite':True,'extra':1}):
   self.assertEqual(self.request(body)[0],400)
  self.assertEqual(self.request({'key':'canonical:reverse_elastico','favorite':False},'https://example.com')[0],403)
  self.assertEqual(read(self.data),before)

class ResearchTests(unittest.TestCase):
 def test_stable_old_ids_and_missing_new_moves(self):
  for key in ('reverse_elastico','juggling_around_the_world','giant_fake_shot','foot_to_foot','lateral_heel_to_heel','running_fake_drag'):
   self.assertIn(key,SKILL_BY_ID)
  self.assertEqual(len(ALL_SKILLS),len(SKILL_BY_ID))
 def test_trickster_is_separate_and_disputed_controls_remain_blocked(self):
  self.assertEqual(SKILL_BY_ID['tricksterplus_flicks']['playstyle_dependency'],'Trickster+')
  for key in ('trickster_fake_shot','trickster_flicks','tricksterplus_flicks','trickster_rainbow','kneel_header'):
   self.assertEqual(SKILL_BY_ID[key]['display_group'],'trickster')
  recipe={'relative':True,'steps':[{'ms':50,'axes':{'RX':1},'buttons':{}}]}
  for key in ('trickster_rainbow','kneel_header'):
   with self.assertRaises(ValueError):validate_recipe(key,recipe)
 def test_all_references_keep_provenance_and_no_generated_recipes(self):
  for row in ALL_SKILLS:
   self.assertIn(row['display_group'],('1','2','3','4','5','trickster'))
   self.assertTrue(row['sources']);self.assertFalse(row['executable'])
   self.assertEqual(row['verification']['game'],'not_tested')
