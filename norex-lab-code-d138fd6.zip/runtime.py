"""Capture-independent replay scheduling and explicit virtual output."""
import copy
import math
import os
import re
import threading
import time
from pipeline import ControllerFrame, neutral_frame, transform, normalized, default_profile, validate_profile
from recording import FrameRecorder, ReplaySource
from virtual import UInputOutput
from output_backend import delivery_test_frame
from remoteplay_settings import RemotePlaySettings
from assists import AssistEngine, TOGGLES
from advanced import AdvancedEngine
from input_audit import InputAudit
from play_tools import PlayTools, ModeBank, MODES, CHORDS, MAPPING_TRIGGERS, TOP_SKILLS, resolve_bindings
from skills import SkillLibrary, CATALOG
from helpers import HelperEngine

class Runtime:
    def init_runtime(self,data):
        from backbone.processing import ProcessingPipeline
        from backbone.resolver import CompareState
        from profile_store import write_atomic,recover_save
        recover_save(data)
        path=data/'startup-profile.json'
        if not path.exists():path=data/'profile-fc27.json'
        if not path.exists(): write_atomic(path,default_profile())
        startup_document=__import__('json').loads(path.read_text())
        self.processing_pipeline=ProcessingPipeline();self.compare_state=CompareState()
        self.helper_engine=HelperEngine()
        self.data=data; import skill_lists; skill_lists.load(data); self.skill_library=SkillLibrary(data,load_saved='snapshot_schema' not in startup_document); self.assist_engine=AssistEngine(); self.advanced_engine=AdvancedEngine(); self.defending=False; self.input_context='movement'; self.comparison=None; self.comparison_results=[]; self.assists_armed=False; self.last_assist_tick=0; self.frame_rec=None; self.frame_record_name=None
        self.output=None; self.output_source=None; self.output_error=None; self.output_frames=0; self.output_last_stop=None
        self.remoteplay=RemotePlaySettings()
        self.output_factory=lambda: UInputOutput(); self.delivery_test_until=0
        self.replay=None; self.replay_state='Stopped'; self.replay_index=0; self.replay_speed=1.; self.replay_origin=0
        self.replay_frame=neutral_frame(); self.physical_frame=neutral_frame(); self.replay_name=None
        self.replay_lateness=[]; self.replay_sent=0; self.replay_duration=0
        self.last_output_ns=None; self.last_emitted_frame=None
        self.profile=validate_profile(startup_document.get('profile',startup_document)); self.startup_arm_pending=self.profile.get('arm_on_startup',False)
        self.play_tools=PlayTools(); self.mode_bank=ModeBank(data,self.profile,load_saved='snapshot_schema' not in startup_document); self.active_mode='None'; self.base_profile=copy.deepcopy(self.profile); self.binding_report=[]; self.custom_enabled=True; self.resume_helpers=False; self.audit=InputAudit(data)
        self.default_inputs=default_profile();self.default_inputs['deadzone']=0;self.default_inputs['trigger_deadzone']=0
        self.control_path=data/'lab-controls.json'
        if self.control_path.exists():
            saved=__import__('json').loads(self.control_path.read_text()); self.custom_enabled=saved.get('custom_enabled') is True
        if not self.custom_enabled:self.startup_arm_pending=False
        self.profile_result=None
        if 'snapshot_schema' in startup_document:
            from profile_store import validate_snapshot,restore
            restore(self,validate_snapshot(startup_document,self.mode_bank))
            self.profile_result={'operation':'startup','name':self.profile['name'],'saved_at':startup_document['saved_at'],'snapshot_schema':startup_document['snapshot_schema']}
    def set_processing_mode(self,mode,finish_sample=True):
        if mode not in ('RAW','NOREX'):raise ValueError('mode must be RAW or NOREX')
        if finish_sample:self.compare_state.finish('mode changed')
        self.compare_state.set_mode(mode)
        self.processing_pipeline.reset();self.assist_engine.reset();self.advanced_engine.reset();self.helper_engine.reset();self.play_tools.reset()
        if self.output and self.output_source=='physical':self.neutralize_output()
        if self.assists_armed:self.arm_current()
        self.on_frame()
    def select_mode(self,name):
        if name not in (*MODES,'None'): raise ValueError("Unknown mode")
        target=copy.deepcopy(self.base_profile if name=='None' else self.mode_bank.profiles[name])
        from backbone.skills import validate_bindings
        validate_bindings(validate_profile(target),self.mode_bank)
        from conflict_rules import validate_global
        validate_global(target,self.mode_bank,self.profile)
        if self.active_mode=='None' and name!='None':self.base_profile=copy.deepcopy(self.profile)
        self.active_mode=name; self.defending=name=="Defender"; self.apply_profile(target)
        self.audit.note('Play-style preset: '+name)
    def arm_current(self):
        self.helper_engine.reset();self.processing_pipeline.reset();self.processing_pipeline.prime(self)
        if not self.custom_enabled:raise ValueError('Turn Lab custom settings on before enabling helpers')
        self.assist_engine.reset(); self.advanced_engine.reset()
        axes,buttons=transform(normalized(self.raw,self.bounds,self.profile),self.buttons,self.profile)
        self.assist_engine.prime(buttons,axes); self.advanced_engine.prime(buttons,axes); self.play_tools.prime(normalized(self.raw,self.bounds,self.profile),self.buttons); self.assists_armed=True
    def apply_profile(self,profile):
        if getattr(self,'command_center',False):
            from section_controls import enforce
            profile=enforce(self,profile)
        validated=validate_profile(profile)
        from backbone.skills import validate_bindings
        validate_bindings(validated,self.mode_bank)
        from conflict_rules import validate_global
        validate_global(validated,self.mode_bank,self.profile)
        self.compare_state.finish('configuration changed');self.processing_pipeline.reset()
        self.helper_engine.reset()
        was_armed=self.assists_armed
        self.profile=validated; self.assist_engine.reset(); self.advanced_engine.reset()
        if was_armed: self.arm_current()
        self.on_frame()
    def first_connection(self):
        if self.startup_arm_pending or (getattr(self,'command_center',False) and self.master_enabled):
            self.startup_arm_pending=False; self.arm_current(); self.on_frame()
    def on_frame(self):
        now=time.monotonic_ns()
        axes,buttons,physical,stages,meta=self.processing_pipeline.process(self,now)
        original_axes,original_buttons=physical.axes,physical.buttons
        activated=meta['trace'];context_conflicts=meta['conflicts']
        if self.comparison and (self.comparison['profile']!=self.profile or self.comparison['helpers']!=self.assists_armed):self.finish_comparison()
        self.play_tools.diagnose(self.buttons,buttons,now)
        self.audit.observe(original_axes,original_buttons,stages,activated,now,context_conflicts,{'preset':self.active_mode,'lab_enabled':self.custom_enabled,'helpers_on':self.assists_armed,'output_connected':bool(self.output)})
        self.measure_comparison(axes)
        self.physical_frame=ControllerFrame(now,axes,buttons,'raw' if meta['mode']=='RAW' else 'assisted' if self.assists_armed else 'physical',self.frames)
        if self.compare_state.active and self.compare_state.active['configuration']!={'profile':self.profile,'armed':self.assists_armed,'custom_enabled':self.custom_enabled}:
            self.compare_state.finish('configuration changed')
        self.compare_state.observe(physical,self.physical_frame)
        if self.frame_rec:
            try: self.frame_rec.frame(self.physical_frame)
            except (ValueError,OSError) as e:
                self.error=str(e); self.finish_frames(str(e))
        if self.output and self.output_source=='delivery-test':
            if time.monotonic_ns() >= self.delivery_test_until: self.close_output()
            else:
                self.physical_frame=delivery_test_frame({},self.buttons,time.monotonic_ns(),self.frames)
                self.emit_output(self.physical_frame)
        elif self.output and self.output_source=='physical': self.emit_output(self.physical_frame)
    def helper_candidates(self,c,a,b):
        names=[];sprint=a.get('R2',0)>.1 or b.get('R2 button');actions=c['action_buttons']
        for key,label,condition in [('perfect_sprint','Sprint strength',sprint),('auto_jockey','Automatic L2 hold',not sprint and not any(b.get(x) for x in actions.values())),('fast_dribble','Controlled sprint',math.hypot(a.get('LX',0),a.get('LY',0))>.15),('precision_pass','Driven pass modifier',b.get(actions['pass'])),('auto_power_shot','Power-shot modifiers',b.get(actions['shot'])),('speed_boost','Sprint stick flick',bool(self.assist_engine.boost))]:
            if c[key] and condition:names.append(label)
        for k in ('pass','cross','shot'):
            if actions[k] in self.assist_engine.timers:names.append('Fixed '+k+' hold')
        if self.assist_engine.followup:names.append('Shot follow-up')
        return names
    def neutralize_output(self):
        self.output.neutralize()
        now=time.monotonic_ns()
        self.last_emitted_frame=neutral_frame(now,source='neutral',sequence=self.frames).to_dict()
        self.last_output_ns=now;self.output_frames+=1
    def emit_output(self,frame):
        try:
            self.output.emit(frame); self.output_frames+=1; self.last_output_ns=time.monotonic_ns()
            self.last_emitted_frame=copy.deepcopy(frame.to_dict())
        except OSError as e:
            self.output_error=str(e); self.assists_armed=False; self.assist_engine.reset(); self.advanced_engine.reset(); self.close_output()
            if getattr(self,'command_center',False):
                from command_center import power
                power(self,False)
    def release_all(self,reason='released'):
        """Return every button, stick and trigger to neutral; physical holds resume on the next real frame."""
        self.assist_engine.reset();self.advanced_engine.reset();self.helper_engine.reset();self.play_tools.reset();self.processing_pipeline.reset()
        self.physical_frame=neutral_frame()
        if self.output:
            try:self.neutralize_output()
            except OSError as e:self.output_error=str(e);self.close_output('Neutralization failed: '+str(e))
        else:self.last_emitted_frame=None
    def release_if_stale(self,max_age_ns=150_000_000):
        # Watchdog: a frame source that stopped (controller asleep, unplugged, tick halted)
        # must not leave the last skill frame held on the console.
        f=self.last_emitted_frame
        if not self.output or self.output_source!='physical' or not f or self.last_output_ns is None:return
        if time.monotonic_ns()-self.last_output_ns<max_age_ns:return
        if any(f.get('axes',{}).values()) or any(f.get('buttons',{}).values()):self.release_all('stale output')
    def close_output(self,reason=None):
        if self.output:self.output_last_stop=reason or self.output_error or 'Output stopped'
        self.processing_pipeline.reset();self.compare_state.finish('output closed')
        self.helper_engine.reset()
        self.play_tools.reset()
        self.advanced_engine.reset(); self.defending=False
        if self.output:
            try: self.output.close()
            except OSError as e: self.output_error=str(e)
        self.output=None; self.output_source=None; self.last_output_ns=None; self.last_emitted_frame=None; self.delivery_test_until=0
    def finish_frames(self,reason='stopped'):
        if self.frame_rec:
            try: self.frame_rec.finish(reason)
            except OSError as e: self.error=str(e)
        self.frame_rec=None
    def disconnect_runtime(self,reason):
        self.advanced_engine.reset(); self.defending=False
        self.finish_comparison(); self.close_output(reason); self.finish_frames(reason); self.assists_armed=False; self.assist_engine.reset(); self.advanced_engine.reset(); self.physical_frame=neutral_frame()
        if getattr(self,'command_center',False) and self.master_enabled:
            from command_center import power
            power(self,False)
    def resync_input(self):
        """Keep physical output registered during evdev SYN_DROPPED recovery."""
        if not self.output or self.output_source!='physical':
            self.disconnect_runtime('Input queue overrun');return
        self.finish_comparison();self.finish_frames('Input queue overrun')
        self.assists_armed=False;self.startup_arm_pending=False
        self.assist_engine.reset();self.advanced_engine.reset();self.play_tools.reset()
        self.processing_pipeline.reset();self.helper_engine.reset()
        self.physical_frame=neutral_frame()
        try:self.neutralize_output()
        except OSError as e:
            self.output_error=str(e);self.close_output('Neutralization failed: '+str(e))

    def new_output(self,source):
        if getattr(self,'command_center',False) and source!='physical':raise ValueError('The command center owns the single physical output')
        if self.output: raise ValueError('Stop current virtual output before starting another source')
        try: self.output=self.output_factory()
        except OSError as e:
            self.output_error=f'Cannot open uinput: {e}. A local administrator must grant this user access.'; raise ValueError(self.output_error)
        self.output_source=source; self.output_error=None; self.output_frames=0
    def stop_replay(self,state='Stopped'):
        self.replay=None; self.replay_state=state; self.replay_frame=neutral_frame(source='replay')
        if self.output_source=='replay': self.close_output()
    def expire_delivery_test(self, now_ns):
        if self.delivery_test_until and now_ns >= self.delivery_test_until: self.close_output()
    def run_replay(self):
        while not self.stop.wait(.002):
            with self.lock:
                if getattr(self,'command_center',False) and self.master_enabled and time.monotonic()-getattr(self,'last_owner_check',0)>.5:
                    self.last_owner_check=time.monotonic()
                    from command_center import conflicts,power
                    # Owned Remote Play children are allowed; external connections force OFF.
                    owned={str(p.pid) for p in self.owned_sessions.children}
                    overlap=[x for x in conflicts() if x.split(':',1)[0] not in owned]
                    if overlap:
                        power(self,False);self.output_error='Connection conflict: '+', '.join(overlap)
                if getattr(self,'require_remoteplay',False) and self.master_enabled and self.remote_session is not None and self.remote_session.poll() is not None:
                    from command_center import power
                    power(self,False);self.output_error='Chiaki session closed; custom input is OFF'
                self.expire_delivery_test(time.monotonic_ns())
                if self.comparison and time.monotonic_ns()-self.comparison['start']>=30_000_000_000:self.finish_comparison()
                if self.assists_armed and not self.replay and (self.status=='Connected' or self.output) and time.monotonic_ns()-self.last_assist_tick>=10_000_000:
                    self.last_assist_tick=time.monotonic_ns(); self.on_frame()
                self.release_if_stale()
                if self.frame_rec and time.monotonic_ns()-self.frame_rec.origin>=600_000_000_000: self.finish_frames('10-minute limit')
                if not self.replay: continue
                elapsed=(time.monotonic_ns()-self.replay_origin)*self.replay_speed
                due=[]
                while self.replay_index<len(self.replay.frames) and self.replay.frames[self.replay_index].t_ns<=elapsed:
                    due.append(self.replay.frames[self.replay_index]); self.replay_index+=1
                if due and (len(due)>32 or (elapsed-due[0].t_ns)/self.replay_speed>100_000_000):
                    self.stop_replay('Stopped: scheduler fell behind'); continue
                for frame in due:
                    self.replay_frame=frame; self.replay_sent+=1
                    self.replay_lateness.append(max(0,(elapsed-frame.t_ns)/1e6/self.replay_speed))
                    self.replay_lateness=self.replay_lateness[-4096:]
                    if self.output and self.output_source=='replay': self.emit_output(frame)
                if self.replay_index>=len(self.replay.frames): self.stop_replay('Completed')
    def measure_comparison(self,axes):
        c=self.comparison
        if not c or c.get('last_frame')==self.frames:return
        now=time.monotonic_ns(); c['last_frame']=self.frames
        if now-c['start']>=30_000_000_000:self.finish_comparison();return
        radius=math.hypot(axes.get('LX',0),axes.get('LY',0));c['samples']+=1;c['sum_left']+=radius;c['max_left']=max(c['max_left'],radius)
        if c['last_time'] is not None:c['intervals'].append((now-c['last_time'])/1e6);c['intervals']=c['intervals'][-4096:]
        c['last_time']=now
    def finish_comparison(self):
        c=self.comparison
        if not c:return
        row={'label':c['label'],'duration_s':(time.monotonic_ns()-c['start'])/1e9,'samples':c['samples'],'mean_left':c['sum_left']/c['samples'] if c['samples'] else 0,'max_left':c['max_left'],'mean_change_frame_ms':sum(c['intervals'])/len(c['intervals']) if c['intervals'] else None,'helpers':c['helpers'],'profile':c['profile']}
        self.comparison_results.append(row);self.comparison_results=self.comparison_results[-8:];self.comparison=None
    def comparison_status(self):
        return {'active':bool(self.comparison),'label':self.comparison['label'] if self.comparison else None,'remaining_s':max(0,30-(time.monotonic_ns()-self.comparison['start'])/1e9) if self.comparison else 0,'results':copy.deepcopy(self.comparison_results)}
    def runtime_state(self):
        replay_files=[]
        for path in self.data.glob('capture-*.jsonl'):
            if self.frame_rec and path.name==self.frame_record_name: continue
            try:
                with path.open() as f: header=__import__('json').loads(f.readline(8192))
                if header.get('schema')==2: replay_files.append(path.name)
            except (OSError,ValueError): pass
        return {'input_console':self.audit.status(),'custom_settings':{'enabled':self.custom_enabled,'manual_action_priority':self.profile['play_tools']['manual_action_priority'],'default_note':'Direct controller inputs; FC27 in-game settings are unchanged'},'active_settings':self.active_setting_names(),'configured_settings':self.active_setting_names(configured=True),'play_modes':{'active':self.active_mode,'enabled':self.mode_bank.enabled,'bindings':copy.deepcopy(self.mode_bank.bindings),'names':['None',*MODES]},'skill_mapping':{'choices':MAPPING_TRIGGERS,'top_pack':TOP_SKILLS,'report':self.binding_report},'release_diagnostics':copy.deepcopy(self.play_tools.release_history),'input_context':self.input_context,'defending':self.defending,'comparison_v2':self.compare_state.status(),'processing_v2':copy.deepcopy(self.processing_pipeline.metadata),'comparison':self.comparison_status(),'remoteplay':self.remoteplay.status(),'assists':{'armed':self.assists_armed,'active_recipe':self.assist_engine.recipe_name,'orientation':self.assist_engine.orientation_status(self.profile['assists']),'message':self.assist_engine.message,'catalog':self.skill_library.catalog()},'replay_files':sorted(replay_files,reverse=True),'processed':self.physical_frame.to_dict(),
                'delivery_test':{'active':self.output_source=='delivery-test','remap':'Cross ↔ Square; all other controls neutral','remaining_s':max(0,(self.delivery_test_until-time.monotonic_ns())/1e9)},
                'output':{**(self.output.status() if self.output else {'backend':'uinput','destination':UInputOutput.destination,'transport':UInputOutput.transport,'transport_connected':False,'receipt':'no active output','ps5_receipt':'unverified','game_receipt':'unverified'}), 'active':bool(self.output),'source':self.output_source,'frames':self.output_frames,'error':self.output_error,'uinput_writable':os.access('/dev/uinput',os.W_OK),'name':'NOREX Controller Lab Virtual'},
                'frame_recording':self.frame_record_name if self.frame_rec else None,
                'frame_record_bytes':self.frame_rec.bytes if self.frame_rec else 0,
                'replay':{'state':self.replay_state,'name':self.replay_name,'speed':self.replay_speed,'index':self.replay_index,'duration_s':self.replay_duration,'sent_states':self.replay_sent,'max_lateness_ms':max(self.replay_lateness,default=0),'preview':self.replay_frame.to_dict(),'active':bool(self.replay)}}
    def active_setting_names(self,configured=False):
        if not self.custom_enabled and not configured:return []
        labels=[k.replace('_',' ') for k in TOGGLES if self.profile['assists'][k]] if (self.assists_armed or configured) else []
        labels.extend(k+' aiming' for k,r in self.profile['advanced']['contexts'].items() if (self.assists_armed or configured) and r['enabled'])
        labels.extend(k+' shortcut' for k,v in self.profile['advanced']['shortcuts'].items() if (self.assists_armed or configured) and v!='Disabled')
        if (self.assists_armed or configured) and self.profile['play_tools']['skill_bindings']:labels.append('skill mappings')
        for side,row in self.profile['curves'].items():
            if row['kind']!='linear':labels.append(side+' '+row['kind']+' response')
        if self.profile['deadzone']>0:labels.append('stick dead zone')
        c=self.profile['advanced']
        if c['stick_deadzone']['enabled']:labels.append('separate stick dead zones')
        labels.extend(k+' trigger response' for k,r in c['triggers'].items() if r['enabled'])
        tools=self.profile['play_tools']
        if self.assists_armed or configured:
            from helpers import BENEFITS
            labels.extend(BENEFITS[k][1] for k,v in self.profile['helpers']['contexts'].items() if v['enabled'])
            labels.extend(k.replace('_',' ') for k in ('smoothing','direction_stability') if self.profile['helpers'][k]['enabled'])
        if tools['outer']['enabled']:labels.append('outer stick response')
        if (self.assists_armed or configured) and tools['shot_response']['enabled']:labels.append('shot-type aiming response')
        if (self.assists_armed or configured) and tools['manual_action_priority']:labels.append('manual Circle/Square priority')
        names={'timed shot':'fixed shot hold','timed pass':'fixed pass hold','timed cross':'fixed cross hold','perfect sprint':'sprint strength','fast dribble':'controlled sprint','precision pass':'driven pass modifier'}
        return [names.get(n,n) for n in labels]
    def runtime_action(self,b):
        a=b.get('action')
        if a=='custom_power':
            enabled=b.get('enabled')
            if type(enabled) is not bool:raise ValueError('Expected true/false')
            if self.replay or self.frame_rec or self.delivery_test_until:raise ValueError('Stop replay, recording or delivery test before changing power')
            if enabled==self.custom_enabled:return True
            tmp=self.control_path.with_suffix('.tmp');tmp.write_text(__import__('json').dumps({'custom_enabled':enabled}));tmp.replace(self.control_path)
            if not enabled:self.resume_helpers=self.assists_armed;self.assists_armed=False;self.startup_arm_pending=False
            self.custom_enabled=enabled;self.assist_engine.reset();self.advanced_engine.reset();self.play_tools.reset()
            if self.output:self.neutralize_output()
            if enabled and self.status=='Connected':self.arm_current()
            elif enabled:self.startup_arm_pending=True
            self.audit.note('Lab custom settings '+('ON' if enabled else 'OFF — default controller inputs'));self.on_frame();return True
        if a in ('mode_select' ,'mode_save','mode_hotkeys','skill_bindings','skill_pack'):
            if self.delivery_test_until: raise ValueError('Stop delivery test before changing play tools')
            if self.replay or self.frame_rec: raise ValueError('Stop replay/recording before changing modes or mappings')
            if a=='mode_select': self.select_mode(b.get('name'))
            elif a=='mode_save':
                from backbone.skills import validate_bindings
                candidate=validate_profile(b.get('profile',self.profile));validate_bindings(candidate,self.mode_bank)
                from conflict_rules import validate_global
                validate_global(candidate,self.mode_bank,self.profile)
                self.mode_bank.save(b.get('name'),candidate)
            elif a=='mode_hotkeys':
                enabled=b.get('enabled'); bindings=b.get('bindings')
                # Validate the whole candidate before any live state or file changes.
                candidate=copy.copy(self.mode_bank);candidate.configure(enabled,bindings,persist=False)
                ready={n for n,r in self.skill_library.recipes.items() if r.get('steps')}
                current,report=resolve_bindings(self.profile,self.profile['play_tools']['skill_bindings'],ready,bindings if enabled else {})
                saved={n:resolve_bindings(p,p['play_tools']['skill_bindings'],ready,bindings if enabled else {})[0] for n,p in self.mode_bank.profiles.items()}
                from backbone.skills import validate_bindings
                from conflict_rules import validate_global
                for profile in [current,self.base_profile,*saved.values()]:
                    validate_bindings(profile,candidate)
                    validate_global(profile,candidate,profile,self.mode_bank)
                candidate.profiles=saved;candidate.persist();self.mode_bank=candidate
                self.apply_profile(current);self.binding_report=report;self.play_tools.reset()
            else:
                rows=b.get('rows') if a=='skill_bindings' else [{'trigger':CHORDS[i],'skill':n} for i,n in enumerate(TOP_SKILLS)]
                ready={n for n,r in self.skill_library.recipes.items() if r.get('steps')}
                profile,report=resolve_bindings(self.profile,rows,ready,self.mode_bank.bindings if self.mode_bank.enabled else {})
                self.binding_report=report or ['Mappings applied with no conflicts']; self.apply_profile(profile)
            return True
        if a=='remoteplay_connect':
            self.remoteplay.connect(); return True
        if a=='remoteplay_media':
            if self.output or self.replay: raise ValueError('Stop output/replay before saving media options')
            self.remoteplay.apply(b.get('video_enabled'),b.get('audio_enabled')); return True
        if self.delivery_test_until and a not in ('delivery_test_stop','output_stop','emergency_stop'):
            raise ValueError('Stop delivery test before other actions')
        if a=='defending_mode':
            if type(b.get('enabled')) is not bool: raise ValueError('Expected true/false')
            if self.replay or self.frame_rec: raise ValueError('Stop replay/recording before switching modes')
            self.defending=b['enabled']; self.assist_engine.reset(); self.advanced_engine.reset()
            if self.assists_armed: self.arm_current()
            self.on_frame(); return True
        if a=='comparison_start':
            if self.status!='Connected' or self.replay or self.frame_rec: raise ValueError('Connect controller and stop replay/recording')
            if self.comparison: raise ValueError('Stop the current comparison sample first')
            label=b.get('label','')
            if label not in ('A','B'): raise ValueError('Sample must be A or B')
            self.comparison={'label':label,'start':time.monotonic_ns(),'samples':0,'max_left':0.,'sum_left':0.,'last_time':None,'intervals':[],'helpers':self.assists_armed,'profile':copy.deepcopy(self.profile)}
            return True
        if a=='comparison_stop': self.finish_comparison(); return True
        if a=='set_assist_enabled':
            key=b.get('key'); enabled=b.get('enabled')
            if key not in TOGGLES or type(enabled) is not bool: raise ValueError('Invalid assist switch')
            if self.replay or self.frame_rec: raise ValueError('Stop replay/recording before changing assists')
            profile=copy.deepcopy(self.profile); profile['assists'][key]=enabled
            self.apply_profile(profile); return True
        if a=='delivery_test_start':
            if b.get('local_only') is not True: raise ValueError('Confirm single-player test use')
            if self.status!='Connected' or self.replay or self.frame_rec or self.output: raise ValueError('Connect controller; stop output, replay and recording first')
            self.startup_arm_pending=False; self.assists_armed=False; self.assist_engine.reset(); self.advanced_engine.reset(); self.play_tools.reset()
            self.new_output('delivery-test'); self.delivery_test_until=time.monotonic_ns()+60_000_000_000
            self.emit_output(neutral_frame(source='delivery-test')); return True
        if a=='delivery_test_stop': self.close_output(); return True
        if a=='configure':
            if self.frame_rec or self.replay: raise ValueError('Stop frame recording/replay before changing the profile')
            self.apply_profile(b['profile'])
        elif a=='arm_assists':
            if not self.custom_enabled:raise ValueError('Turn Lab custom settings on before enabling helpers')
            if b.get('local_only') is not True: raise ValueError('Select local/single-player test mode')
            if self.status!='Connected' or self.replay or self.frame_rec: raise ValueError('Connect controller and stop replay/recording first')
            if 'profile' in b:self.apply_profile(b['profile'])
            self.arm_current(); self.on_frame()
        elif a=='disarm_assists':
            self.processing_pipeline.reset();self.compare_state.finish('helpers disarmed')
            self.startup_arm_pending=False; self.assists_armed=False; self.assist_engine.reset(); self.advanced_engine.reset(); self.play_tools.reset()
            if self.output and self.output_source=='physical': self.neutralize_output()
            self.on_frame()
        elif a=='skill_get':
            name=b.get('name')
            if name not in CATALOG: raise ValueError('Unknown skill name')
            return {'recipe':copy.deepcopy(self.skill_library.recipes[name])}
        elif a=='skill_save':
            if self.assists_armed or self.frame_rec or self.replay: raise ValueError('Disarm assists and stop recording/replay before editing recipes')
            self.skill_library.save(b['recipe'])
        elif a=='skill_from_capture':
            if self.assists_armed or self.frame_rec or self.replay: raise ValueError('Disarm assists and stop recording/replay before importing a recipe')
            name=b.get('name'); capture=b.get('capture','')
            if name not in CATALOG or not re.fullmatch(r'capture-[0-9-]+\.jsonl',capture): raise ValueError('Invalid skill or capture name')
            source=ReplaySource(self.data/capture)
            self.skill_library.from_capture(name,source,b.get('start_ms',0),b.get('duration_ms',1000))
        elif a=='skill_run':
            if not self.assists_armed or self.replay: raise ValueError('Arm local assists and stop replay before running a skill')
            name=b.get('name')
            if name not in CATALOG: raise ValueError('Unknown skill')
            self.assist_engine.observe_movement(normalized(self.raw,self.bounds,self.default_inputs))
            self.assist_engine.start_recipe(name,self.skill_library.recipes[name]['steps'],time.monotonic_ns(),config=self.profile['assists'],relative=self.skill_library.recipes[name].get('relative',False)); self.on_frame()
        elif a=='record_frames':
            if self.status!='Connected': raise ValueError('Connect controller first')
            if self.frame_rec or self.replay: raise ValueError('Stop recording/replay first')
            if sum(p.stat().st_size for p in self.data.glob('capture-*'))>=200*1024*1024: raise ValueError('200 MiB archive threshold reached')
            self.frame_record_name='capture-'+time.strftime('%Y%m%d-%H%M%S')+'-'+str(time.time_ns()%1000000)+'.jsonl'
            self.frame_rec=FrameRecorder(self.data/self.frame_record_name,copy.deepcopy(self.profile),copy.deepcopy(self.device)); self.on_frame()
        elif a=='stop_frames': self.finish_frames()
        elif a=='output_start':
            if b.get('local_only') is not True: raise ValueError('Confirm local/single-player use')
            if self.status!='Connected' or self.replay: raise ValueError('Connect controller and stop replay first')
            self.new_output('physical'); self.on_frame()
        elif a in ('output_stop','emergency_stop'):
            self.finish_comparison()
            self.startup_arm_pending=False; self.assists_armed=False; self.assist_engine.reset(); self.advanced_engine.reset(); self.play_tools.reset(); self.stop_replay(); self.close_output(); self.finish_frames('emergency stop' if a=='emergency_stop' else 'output stopped')
        elif a=='replay':
            if b.get('local_only') is not True: raise ValueError('Confirm local/single-player use')
            if self.replay or self.frame_rec or (self.output and not getattr(self,'command_center',False)): raise ValueError('Stop replay, frame recording and virtual output first')
            if getattr(self,'command_center',False) and b.get('virtual') is True:raise ValueError('Use preview replay; the master owns physical output')
            name=b.get('name','')
            if not re.fullmatch(r'capture-[0-9-]+\.jsonl',name): raise ValueError('Invalid capture name')
            speed=b.get('speed',1)
            if isinstance(speed,bool) or not isinstance(speed,(int,float)) or not .25<=speed<=2: raise ValueError('Replay speed must be 0.25–2')
            source=ReplaySource(self.data/name)
            self.assists_armed=False; self.assist_engine.reset(); self.advanced_engine.reset()
            if b.get('virtual') is True: self.new_output('replay')
            self.replay=source; self.replay_index=0; self.replay_speed=speed; self.replay_origin=time.monotonic_ns()
            self.replay_name=name; self.replay_state='Playing to virtual output' if self.output else 'Previewing'; self.replay_sent=0
            self.replay_duration=source.duration_ns/1e9; self.replay_lateness=[]; self.replay_frame=neutral_frame(source='replay')
        elif a=='replay_stop': self.stop_replay()
        else: return False
        return True
