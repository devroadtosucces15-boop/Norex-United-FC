"""Individual input-contract checks; these do not assert FC27 game outcomes."""
import unittest
from assists import AssistEngine,defaults
from pipeline import neutral_frame
class IndividualAssists(unittest.TestCase):
 def test_individual_modifiers(self):
  cases=[('auto_jockey',{}, {},lambda a,b:a['L2']==1 and b['L2 button']),('perfect_sprint',{'R2':1},{},lambda a,b:a['R2']==.6),('precision_pass',{}, {'Cross':True},lambda a,b:b['R1']),('fast_dribble',{'LX':1},{},lambda a,b:b['R1']),('auto_power_shot',{}, {'Circle':True},lambda a,b:b['L1'] and b['R1']),('speed_boost',{'LX':1,'R2':1},{},lambda a,b:a['RX']==1)]
  for key,axes,buttons,expect in cases:
   with self.subTest(feature=key):
    f=neutral_frame();f.axes.update(axes);f.buttons.update(buttons);cfg=defaults();cfg[key]=True;cfg['sprint_strength']=60
    a,b=AssistEngine().apply(f.axes,f.buttons,cfg,1_000_000_000,{})
    self.assertTrue(expect(a,b))
    cfg[key]=False;a,b=AssistEngine().apply(f.axes,f.buttons,cfg,1_000_000_000,{})
    self.assertFalse(expect(a,b))
 def test_each_timed_hold_releases(self):
  for key,button in [('pass','Cross'),('cross','Square'),('shot','Circle')]:
   with self.subTest(feature=key):
    f=neutral_frame();c=defaults();c['timed_'+key]=True;c[key+'_ms']=100;e=AssistEngine();f.buttons[button]=True
    self.assertTrue(e.apply(f.axes,f.buttons,c,1_000_000_000,{})[1][button]);f.buttons[button]=False
    self.assertTrue(e.apply(f.axes,f.buttons,c,1_050_000_000,{})[1][button])
    self.assertFalse(e.apply(f.axes,f.buttons,c,1_110_000_000,{})[1][button])
 def test_followups_individually_release(self):
  for key in ['low_driven','perfect_lowdrive','finesse_finish']:
   with self.subTest(feature=key):
    f=neutral_frame();c=defaults();c[key]=True;c['shot_types']['lace']=True;c['timed_shot']=key=='perfect_lowdrive';c['shot_ms']=50;c['finesse_delay_ms']=80;c['followup_delay_ms']=80
    if key=='finesse_finish':f.buttons['R1']=True
    e=AssistEngine();f.buttons['Circle']=True;e.apply(f.axes,f.buttons,c,1_000_000_000,{})
    f.buttons['Circle']=False;e.apply(f.axes,f.buttons,c,1_060_000_000,{})
    self.assertTrue(e.apply(f.axes,f.buttons,c,1_145_000_000,{})[1]['Circle'])
    self.assertFalse(e.apply(f.axes,f.buttons,c,1_190_000_000,{})[1]['Circle'])
