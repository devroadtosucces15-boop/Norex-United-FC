import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import lab
from profile_store import snapshot

class CompleteSnapshots(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.patch=patch.object(lab,'DATA',Path(self.tmp.name));self.patch.start();self.l=lab.Lab()
    def tearDown(self):self.patch.stop();self.tmp.cleanup()
    def test_save_mutate_load_full_snapshot_and_restart(self):
        p=copy.deepcopy(self.l.profile);p['helpers']['contexts']['jockey'].update(enabled=True,exponent=1.8)
        p['centers']['LX']=128;p['curves']['left']['exponent']=2;p['advanced']['contexts']['pass']['enabled']=True
        p['play_tools']['manual_action_priority']=False;p['visual']['theme']='light'
        self.l.skill_library.save({'name':'Stop And Go','relative':True,'steps':[{'ms':35,'axes':{'RX':.5},'buttons':{}}]})
        self.l.mode_bank.profiles['Creator']['deadzone']=.17
        self.l.action({'action':'save','name':'fc27','profile':p})
        saved=snapshot(self.l,self.l.profile)
        self.l.profile['helpers']['contexts']['jockey']['exponent']=.5
        self.l.skill_library.recipes['Stop And Go']['steps'][0]['ms']=55
        self.l.mode_bank.profiles['Creator']['deadzone']=.4
        self.l.action({'action':'load','name':'fc27'})
        loaded=snapshot(self.l,self.l.profile)
        for key in ('profile','skill_recipes','mode_bank','selection','scope'):self.assertEqual(loaded[key],saved[key],key)
        self.assertFalse(self.l.assists_armed);self.assertIsNone(self.l.output)
        restart=lab.Lab();self.assertEqual(restart.profile,saved['profile']);self.assertEqual(restart.skill_library.recipes,saved['skill_recipes']);self.assertEqual(restart.mode_bank.profiles,saved['mode_bank']['profiles'])
    def test_corrupt_snapshot_does_not_partially_load(self):
        self.l.action({'action':'save','name':'fixture'});path=lab.DATA/'profile-fixture.json';doc=json.loads(path.read_text());doc['mode_bank']['bindings']['Defender']['direction']='invalid';path.write_text(json.dumps(doc))
        before=snapshot(self.l,self.l.profile)
        with self.assertRaises(ValueError):self.l.action({'action':'load','name':'fixture'})
        after=snapshot(self.l,self.l.profile)
        for key in ('profile','skill_recipes','mode_bank','selection'):self.assertEqual(before[key],after[key])
    def test_failed_save_leaves_active_profile_and_disk_unchanged(self):
        self.l.action({'action':'save','name':'fixture'});path=lab.DATA/'profile-fixture.json';disk=path.read_bytes();before=copy.deepcopy(self.l.profile)
        p=copy.deepcopy(before);p['deadzone']=.2
        with patch('profile_store.os.fsync',side_effect=OSError('simulated failure')):
            with self.assertRaises(OSError):self.l.action({'action':'save','name':'fixture','profile':p})
        self.assertEqual(path.read_bytes(),disk);self.assertEqual(self.l.profile,before)
    def test_legacy_flat_load_and_session_controls_excluded(self):
        path=lab.DATA/'profile-legacy.json';path.write_text(json.dumps(self.l.profile));self.l.action({'action':'load','name':'legacy'})
        self.assertEqual(self.l.profile_result['snapshot_schema'],0);self.assertFalse(self.l.assists_armed)
        self.assertNotIn('output',snapshot(self.l,self.l.profile))
