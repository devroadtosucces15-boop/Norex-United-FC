import copy, unittest
from pipeline import default_profile, validate_profile, neutral_frame
from helpers import HelperEngine, BENEFITS

class ResponseHelpers(unittest.TestCase):
    def setUp(self):
        self.p=default_profile();self.e=HelperEngine();self.a=neutral_frame().axes;self.b=neutral_frame().buttons
    def apply(self,ns=1_000_000,armed=True,context='movement'):
        return self.e.apply(self.a,self.b,self.a,self.p,armed,ns,context)
    def test_migration_disabled_and_exact_passthrough(self):
        p=copy.deepcopy(self.p);del p['helpers'];self.assertEqual(validate_profile(p)['helpers'],self.p['helpers'])
        self.a['LX']=.4;self.assertEqual(self.apply(),self.a)
    def test_all_held_contexts_release_and_never_generate_buttons(self):
        for key in BENEFITS:
            with self.subTest(key=key):
                self.setUp();row=self.p['helpers']['contexts'][key];row.update(enabled=True,exponent=2)
                self.a.update(LX=.5,RX=.5)
                if key in ('jockey','sprint'):self.a['L2' if key=='jockey' else 'R2']=.6
                else:self.b[{'through_pass':'Triangle','controlled_dribble':'R1','goalkeeper':'R3'}[key]]=True
                before=copy.deepcopy(self.b);out=self.apply();self.assertAlmostEqual(out['RX' if key=='goalkeeper' else 'LX'],.25);self.assertEqual(before,self.b)
                self.b={};self.a.update(L2=0,R2=0);out=self.apply(2_000_000);self.assertEqual(out,self.a)
    def test_goalkeeper_response_is_independent_of_left_stick_priority(self):
        for key in ('through_pass','goalkeeper'):
            self.p['helpers']['contexts'][key].update(enabled=True,exponent=2)
        self.a.update(LX=.5,RX=.5);self.b.update(Triangle=True,R3=True)
        out=self.apply();self.assertAlmostEqual(out['LX'],.25);self.assertAlmostEqual(out['RX'],.25)
    def test_strength_zero_and_existing_aim_priority(self):
        self.p['helpers']['contexts']['through_pass'].update(enabled=True,exponent=2,strength=0)
        self.b['Triangle']=True;self.a['LX']=.5;self.assertEqual(self.apply(),self.a)
        self.p['helpers']['contexts']['through_pass']['strength']=1;self.assertEqual(self.apply(context='shoot'),self.a)
    def test_smoothing_neutral_reversal_full_travel_gap_and_disarm(self):
        self.p['helpers']['smoothing'].update(enabled=True,ms=40,strength=1)
        self.a['LX']=.2;self.apply();self.a['LX']=.6;self.assertLess(self.apply(11_000_000)['LX'],.6)
        self.a['LX']=0;self.assertEqual(self.apply(12_000_000)['LX'],0)
        self.a['LX']=.6;self.apply(13_000_000);self.a['LX']=-.6;self.assertEqual(self.apply(14_000_000)['LX'],-.6)
        self.a['LX']=1;self.assertEqual(self.apply(15_000_000)['LX'],1)
        self.a['LX']=.3;self.assertEqual(self.apply(200_000_000)['LX'],.3)
        self.assertEqual(self.apply(210_000_000,armed=False),self.a);self.assertIsNone(self.e.previous)
    def test_direction_stability_preserves_magnitude(self):
        import math
        self.p['helpers']['direction_stability'].update(enabled=True,strength=1)
        self.a['LX']=.5;self.apply();self.a.update(LX=.5*math.cos(.03),LY=.5*math.sin(.03))
        out=self.apply(11_000_000);self.assertAlmostEqual(out['LY'],0);self.assertAlmostEqual(math.hypot(out['LX'],out['LY']),.5)
    def test_invalid_and_nonfinite_configuration(self):
        for value in (-1,41,float('nan')):
            self.p['helpers']['smoothing']['ms']=value
            with self.assertRaises(ValueError):validate_profile(self.p)
        self.p=default_profile();self.p['helpers']['contexts']['jockey']['enabled']=1
        with self.assertRaises(ValueError):validate_profile(self.p)
