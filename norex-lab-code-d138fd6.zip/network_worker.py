#!/usr/bin/python3
import signal,secrets
from http.server import ThreadingHTTPServer
from lab import Handler
from network_integration import Network
server=ThreadingHTTPServer(('127.0.0.1',8792),Handler)
server.network=Network();server.network_token=secrets.token_urlsafe(32)
def stop(*_):raise KeyboardInterrupt
signal.signal(signal.SIGTERM,stop)
try:server.serve_forever()
except KeyboardInterrupt:pass
finally:server.network.close();server.server_close()
