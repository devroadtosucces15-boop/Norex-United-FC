"""Pure v2 response engine: bounded transforms, manual buttons, no transport."""
import math
from copy import deepcopy
from .resolver import ConflictResolver
from .helper_contract import validate_config, effective_config, CONTEXT_ORDER


def _radial(axes,xname,yname,exponent,strength):
    out=deepcopy(axes);x=float(out.get(xname,0));y=float(out.get(yname,0));r=math.hypot(x,y)
    if not r:return out
    mag=min(1.0,r);target=mag+(mag**exponent-mag)*strength;scale=target/r
    out[xname]=max(-1,min(1,x*scale));out[yname]=max(-1,min(1,y*scale));return out

class BackboneEngine:
    def __init__(self):
        self.mode='NOREX';self.resolver=ConflictResolver();self.reset()
    def reset(self):self.previous=None;self.last_ns=None
    def set_mode(self,mode):
        if mode not in ('RAW','NOREX'):raise ValueError('mode must be RAW or NOREX')
        if mode!=self.mode:self.reset()
        self.mode=mode
    def process(self,axes,buttons,config,now_ns=0,physical_axes=None,physical_buttons=None,context='movement'):
        physical_axes=deepcopy(axes if physical_axes is None else physical_axes)
        physical_buttons=deepcopy(buttons if physical_buttons is None else physical_buttons)
        if self.mode=='RAW':
            self.reset()
            return deepcopy(axes),deepcopy(buttons),{'mode':'RAW','trace':[],'conflicts':[]}
        _,enabled,conflicts=effective_config(config or {})
        for name,value in axes.items():
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not (0 if name in ('L2','R2') else -1)<=value<=1:
                raise ValueError('Input axes must be finite and bounded')
        a=deepcopy(axes);trace=[]
        def apply(key,x='LX',y='LY'):
            nonlocal a
            row=enabled[key];before=deepcopy(a)
            a=_radial(a,x,y,row['exponent'],row['strength']/100)
            if a!=before:trace.append(key)
        for key in ('precision_stick','outer_response'):
            if enabled[key]['enabled']:apply(key)
        conditions={'shot_response':physical_buttons.get('Circle'),
                    'cross_response':physical_buttons.get('Square'),
                    'through_pass_response':physical_buttons.get('Triangle'),
                    'controlled_dribble_response':physical_buttons.get('R1'),
                    'jockey_response':physical_axes.get('L2',0)>.1,
                    'sprint_response':physical_axes.get('R2',0)>.1}
        candidates=[key for key in CONTEXT_ORDER if enabled[key]['enabled'] and conditions[key]]
        if candidates:
            winner=candidates[0] if context=='movement' else 'legacy '+context+' aim response'
            if context=='movement':apply(winner)
            for key in candidates if context!='movement' else candidates[1:]:
                conflicts.append({'helper':key,'control':'left-stick response','winner':winner})
        if enabled['goalkeeper_stick']['enabled'] and physical_buttons.get('R3'):apply('goalkeeper_stick','RX','RY')
        dt=(now_ns-self.last_ns)/1e6 if self.last_ns is not None else None
        old=self.previous if dt is not None and 0<dt<=100 else None
        x,y=a.get('LX',0),a.get('LY',0);r=math.hypot(x,y)
        if old and 0<r<.98 and x*old.get('LX',0)+y*old.get('LY',0)>0:
            s=enabled['smoothing']
            if s['enabled'] and s['window_ms']>0:
                retention=math.exp(-dt/s['window_ms'])*s['strength']/100
                a['LX']=x*(1-retention)+old.get('LX',0)*retention
                a['LY']=y*(1-retention)+old.get('LY',0)*retention
                trace.append('smoothing')
            d=enabled['direction_stability'];pr=math.hypot(old.get('LX',0),old.get('LY',0))
            if d['enabled'] and pr:
                current=math.atan2(y,x);previous=math.atan2(old.get('LY',0),old.get('LX',0))
                delta=math.atan2(math.sin(current-previous),math.cos(current-previous))
                if abs(math.degrees(delta))<d['degrees']:
                    ang=current-delta*d['strength']/100
                    a['LX']=math.cos(ang)*r;a['LY']=math.sin(ang)*r;trace.append('direction_stability')
        self.previous=deepcopy(a);self.last_ns=now_ns
        return a,deepcopy(buttons),{'mode':'NOREX','trace':trace,'conflicts':conflicts}
