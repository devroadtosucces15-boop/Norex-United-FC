import copy,json
from unittest.mock import patch
from test_command_center import MasterTests
from command_center import power
from pipeline import default_profile

class PersistentMasterTests(MasterTests):
    def test_disk_restore_after_new_runtime(self):
        power(self.r,True)
        self.r.profile['deadzone']=.31
        power(self.r,False)
        with patch.object(__import__('lab'),'DATA',self.r.data):other=__import__('lab').Lab()
        other.command_center=True;other.status='Connected';other.output_factory=lambda:self.sink
        power(other,False);power(other,True)
        self.assertEqual(other.profile['deadzone'],.31)
        self.assertTrue(other.master_enabled)
        power(other,False)
    def test_repeated_off_preserves_saved_profile(self):
        power(self.r,True);self.r.profile['deadzone']=.27
        power(self.r,False)
        saved=(self.r.data/'master-saved.json').read_bytes()
        power(self.r,False)
        self.assertEqual((self.r.data/'master-saved.json').read_bytes(),saved)
    def test_disabled_section_can_restore_after_restart(self):
        from section_controls import toggle
        power(self.r,True);self.r.profile['deadzone']=.29
        toggle(self.r,'Controller',False);power(self.r,False)
        self.r.section_saved={};power(self.r,True)
        self.assertFalse(self.r.sections['Controller'])
        toggle(self.r,'Controller',True)
        self.assertEqual(self.r.profile['deadzone'],.29)
        power(self.r,False)
