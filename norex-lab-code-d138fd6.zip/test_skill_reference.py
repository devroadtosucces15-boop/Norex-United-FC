import unittest,tempfile
from pathlib import Path
from skills import SkillLibrary, CATALOG
from skill_reference import reference

class EvidenceTests(unittest.TestCase):
    def test_every_name_has_explicit_unknown_or_evidence_and_recipe_status(self):
        with tempfile.TemporaryDirectory() as d:
            rows=SkillLibrary(Path(d)).catalog()
        self.assertEqual(len(rows),len(CATALOG))
        for row in rows:
            self.assertEqual(row['verification']['game'],'unverified')
            if row['stars'] is not None:self.assertIn(row['stars'],range(1,6));self.assertTrue(row['sources']);self.assertTrue(row['ps5_input'])
            if not row['sources']:self.assertEqual(row['verification']['source'],'unverified');self.assertIsNone(row['ps5_input'])
            for source in row['sources']:self.assertTrue(any(video in source for video in ('t67iexOyTNM','AFjd0Y29HAc')))
            self.assertEqual(row['recipe_status'],'Unverified recipe' if row['ready'] else 'Recipe not configured')
            if row['playstyle_dependency'] is not None:
                self.assertIn(row['playstyle_dependency'],('Trickster','Trickster+','Inventive','Gamechanger'));self.assertTrue(row['video_evidence'])
    def test_source_conflict_and_legacy_are_not_current_official(self):
        self.assertIn('conflict',reference('Giant Fake Shot')['game_status'])
        self.assertIn('FC27 uncertain',reference('Explosive Stepover')['game_status'])
        self.assertIsNone(reference('Advanced Croqueta')['stars'])
    def test_metadata_cannot_promote_recipe_to_game_verified(self):
        with tempfile.TemporaryDirectory() as d:
            library=SkillLibrary(Path(d));library.save({'name':'Stop And Go','relative':True,'status':'Game verified','steps':[{'ms':30,'axes':{},'buttons':{}}]})
            row=next(r for r in library.catalog() if r['name']=='Stop And Go')
            self.assertEqual(row['verification']['game'],'unverified');self.assertEqual(row['recipe_status'],'Unverified recipe')
