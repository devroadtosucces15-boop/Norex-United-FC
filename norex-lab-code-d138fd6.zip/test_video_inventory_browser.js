// Read-only scratchpad: never sends controller commands or changes settings.
const {chromium}=require('playwright'),assert=require('assert');
(async()=>{
 const b=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 try{
  const p=await b.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.route('**/api/**',r=>{if(r.request().method()!=='POST')return r.continue();const data=r.request().postDataJSON();assert.equal(data.action,'skill_get','only a simulated recipe read is allowed');return r.fulfill({json:{recipe:{name:data.name,relative:false,steps:[{ms:100,axes:{},buttons:{}}]}}})});
  await p.goto('http://127.0.0.1:8797/lab');await p.waitForSelector('.gcard');
  await p.locator('#nav [data-page=Skills]').click();await p.waitForSelector('#skillRows .srow');
  const result=await p.evaluate(()=>{
   const rows=allSkillRows();return {
    ramp:rows.find(x=>x.name==='Ramp Flick Up'),
    feint:rows.find(x=>x.name==='Feint & Exit'),
    old:rows.find(x=>x.name==='Ronaldo Fenomeno'),
    sources:rows.flatMap(x=>x.sources||[]),
    duplicated:rows.filter(x=>x.name==='Ball Juggle'||x.name==='Ball Juggling').length,
    rampPlayDisabled:document.querySelector('[data-play-skill="Ramp Flick Up"]').disabled
   };
  });
  assert(result.ramp);assert.equal(result.ramp.stars,4);assert.equal(result.rampPlayDisabled,false,'recovered video replay must be playable');
  assert(result.feint);assert.equal(result.feint.stars,null);
  assert.equal(result.old.video_membership,'FC26 only');assert.equal(result.old.display_group,'legacy');
  assert.equal(result.duplicated,1,'video aliases must not duplicate catalog rows');
  assert(result.sources.every(x=>x.includes('t67iexOyTNM')||x.includes('AFjd0Y29HAc')));
  assert.deepEqual(errors,[]);console.log('Video inventory UI: approved sources only, aliases deduplicated, conflicts unconfirmed, FC26 separated, recovered video playback enabled. No writes.');
 }finally{await b.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
