"""Measured controller-animation replays from the user-approved tutorial.

These are animation timings, not certified game timings. Only an explicit Play
runs one bounded example. Existing working and user-authored recipes win.
"""
import copy,json
from functools import lru_cache
from pathlib import Path
from approved_video_inventory import key

@lru_cache(maxsize=1)
def manifest():
    return json.loads(Path(__file__).with_name('ui').joinpath('fc27-video-playback.json').read_text())

def recipes():
    return copy.deepcopy(manifest()['recipes'])

def unavailable_reason(name):
    for n,reason in manifest()['skipped'].items():
        if key(n)==key(name):return reason
    return 'No complete controller-overlay sequence has been recovered for this entry yet.'
