import json,random,tempfile,unittest
from pathlib import Path
import skill_lists as L
from skills import SkillLibrary
from pipeline import default_profile,validate_profile
from play_tools import resolve_bindings,MAPPING_TRIGGERS

class SkillListTests(unittest.TestCase):
    def setUp(self):
        self.d=Path(tempfile.mkdtemp());L.load(self.d)
        self.ready={'Elastico','Roulette Right','Hocus Pocus','Ball Roll Left'}
    def test_save_validates_and_persists(self):
        out=L.save(self.d,'Mix 1',['Elastico','Hocus Pocus'],'random')
        self.assertEqual(out['lists'][0]['name'],'Mix 1')
        L.LISTS.clear();L.load(self.d);self.assertIn('List: Mix 1',L.LISTS)
        for bad in (('',['Elastico'],'random'),('x',[],'random'),('x',['Elastico','Elastico'],'random'),('x',['Nope Move'],'random'),('x',['Elastico'],'bogus'),('bad/name',['Elastico'],'random')):
            with self.assertRaises(ValueError):L.save(self.d,*bad)
    def test_rename_and_delete(self):
        L.save(self.d,'A',['Elastico'],'random');L.save(self.d,'B',['Hocus Pocus'],'random')
        L.save(self.d,'C',['Elastico'],'random',old_name='A');self.assertEqual({x['name'] for x in L.snapshot()},{'B','C'})
        with self.assertRaises(ValueError):L.save(self.d,'B',['Elastico'],'random',old_name='C')
        L.delete(self.d,'C');self.assertEqual([x['name'] for x in L.snapshot()],['B'])
    def test_random_never_repeats_twice_in_a_row(self):
        L.save(self.d,'R',['Elastico','Roulette Right','Hocus Pocus'],'random');rng=random.Random(3);last=None
        for _ in range(200):
            m=L.pick('List: R',self.ready,rng);self.assertNotEqual(m,last);last=m
    def test_shuffle_plays_each_once_per_round(self):
        L.save(self.d,'S',['Elastico','Roulette Right','Hocus Pocus','Ball Roll Left'],'shuffle');rng=random.Random(1)
        for _ in range(5):self.assertEqual({L.pick('List: S',self.ready,rng) for _ in range(4)},self.ready)
    def test_order_cycles(self):
        L.save(self.d,'O',['Elastico','Hocus Pocus'],'order');got=[L.pick('List: O',self.ready) for _ in range(4)]
        self.assertEqual(got,['Elastico','Hocus Pocus','Elastico','Hocus Pocus'])
    def test_only_ready_members_are_picked(self):
        L.save(self.d,'P',['Elastico','Hocus Pocus'],'random')
        self.assertEqual({L.pick('List: P',{'Elastico'}) for _ in range(20)},{'Elastico'})
        self.assertIsNone(L.pick('List: P',set()));self.assertIsNone(L.pick('List: Gone',self.ready))
    def test_mapping_accepts_list_and_checks_members(self):
        L.save(self.d,'M',['Elastico'],'random');p=default_profile()
        out,_=resolve_bindings(p,[{'trigger':MAPPING_TRIGGERS[0],'skill':'List: M'}],self.ready,{})
        self.assertEqual(out['play_tools']['skill_bindings'][0]['skill'],'List: M')
        validate_profile(out)
        with self.assertRaises(ValueError):resolve_bindings(p,[{'trigger':MAPPING_TRIGGERS[0],'skill':'List: M'}],set(),{})
    def test_binding_survives_a_deleted_list(self):
        L.save(self.d,'M',['Elastico'],'random');p=default_profile()
        out,_=resolve_bindings(p,[{'trigger':MAPPING_TRIGGERS[0],'skill':'List: M'}],self.ready,{})
        L.delete(self.d,'M');validate_profile(out)   # profile still loads; the trigger simply does nothing
if __name__=='__main__':unittest.main()

class ListTriggerRuntimeTests(unittest.TestCase):
    """A mapped list plays one of its own moves on each press, through the real processing path."""
    def setUp(self):
        import copy
        from unittest.mock import patch
        import lab
        from pipeline import neutral_frame
        self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.addCleanup(self.tmp.cleanup)
        with patch.object(lab,'DATA',Path(self.tmp.name)):self.r=lab.Lab()
        self.r.status='Connected';self.r.raw={'LX':0,'LY':-1,'RX':0,'RY':0,'L2':0,'R2':0,'DX':0,'DY':0}
        self.r.bounds={k:[0,1] if k in ('L2','R2') else [-1,1] for k in self.r.raw}
        self.r.buttons=copy.deepcopy(neutral_frame().buttons)
        L.save(Path(self.tmp.name),'Mix',['Elastico','Hocus Pocus','Roulette Right'],'random')
        self.r.profile['play_tools']['skill_bindings']=[{'trigger':'R3','skill':'List: Mix'}]
        self.r.arm_current()
    def tick(self,ms):return self.r.processing_pipeline.process(self.r,int(ms*1e6))
    def press(self,t):
        self.r.buttons['R3']=True;self.tick(t);self.tick(t+100)
        name=self.r.assist_engine.recipe_name
        self.r.assist_engine.reset();self.r.buttons['R3']=False;self.tick(t+200);self.tick(t+400)
        return name
    def test_each_press_plays_a_member_without_repeating(self):
        got=[self.press(1000+i*1000) for i in range(12)]
        self.assertTrue(all(g in ('Elastico','Hocus Pocus','Roulette Right') for g in got),got)
        self.assertTrue(all(a!=b for a,b in zip(got,got[1:])),got)
        self.assertGreater(len(set(got)),1)
    def test_unready_list_does_nothing_and_says_why(self):
        L.save(Path(self.tmp.name),'Mix',['Elastico'],'random')
        self.r.skill_library.recipes['Elastico']['steps']=[]
        self.r.buttons['R3']=True;self.tick(1000);self.tick(1100)
        self.assertIsNone(self.r.assist_engine.active_recipe);self.assertIn('no ready moves',self.r.assist_engine.message)

class NotesAndViewerTests(unittest.TestCase):
    def test_notes_roundtrip_and_validation(self):
        import skill_notes as N
        d=Path(tempfile.mkdtemp())
        out=N.save(d,'Elastico','correct','matches the game');self.assertEqual(out['notes']['Elastico']['status'],'correct')
        N.save(d,'Elastico','check','timing feels off');self.assertEqual(N.read(d)['notes']['Elastico']['status'],'check')
        self.assertNotIn('Elastico',N.save(d,'Elastico',None,'')['notes'])
        for bad in (('Nope Move','correct'),('Elastico','maybe')):
            with self.assertRaises(ValueError):N.save(d,*bad)
        self.assertEqual(len(N.save(d,'Elastico','check','x'*500)['notes']['Elastico']['note']),200)
    def test_upcoming_is_what_the_next_press_plays(self):
        d=Path(tempfile.mkdtemp());ready={'Elastico','Roulette Right','Hocus Pocus'}
        for mode in L.MODES:
            L.save(d,'U',['Elastico','Roulette Right','Hocus Pocus'],mode);rng=random.Random(5)
            for _ in range(20):
                nxt=L.upcoming('List: U',ready,rng);self.assertEqual(L.upcoming('List: U',ready,rng),nxt)  # stable until played
                self.assertEqual(L.pick('List: U',ready,rng),nxt)
    def test_facets_are_derived_from_recipes(self):
        import skill_meta as M
        lib=SkillLibrary(Path(tempfile.mkdtemp()),load_saved=False)
        f=M.facets('Roulette Right',lib.recipes['Roulette Right'],True)
        self.assertIn('right stick arc',f['stick']);self.assertEqual(f['side'],['right']);self.assertIn('3 star',f['rating'])
        f=M.facets('Heel Chop Left',lib.recipes['Heel Chop Left'],True)
        self.assertEqual(f['fake'],['fake shot']);self.assertIn('L2',f['buttons']);self.assertIn('running',f['situation'])
        name=next(n for n in lib.recipes if M._norm(n)=='aroundtheworld');self.assertIn('in air',M.facets(name,lib.recipes[name],True)['where'])
    def test_telemetry_reports_now_previous_and_next(self):
        import copy
        from unittest.mock import patch
        import lab
        from pipeline import neutral_frame
        import live_telemetry
        tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.addCleanup(tmp.cleanup)
        with patch.object(lab,'DATA',Path(tmp.name)):r=lab.Lab()
        r.status='Connected';r.raw={'LX':0,'LY':-1,'RX':0,'RY':0,'L2':0,'R2':0,'DX':0,'DY':0}
        r.bounds={k:[0,1] if k in ('L2','R2') else [-1,1] for k in r.raw};r.buttons=copy.deepcopy(neutral_frame().buttons)
        L.save(Path(tmp.name),'V',['Elastico','Hocus Pocus'],'order')
        r.profile['play_tools']['skill_bindings']=[{'trigger':'R3','skill':'List: V'}];r.arm_current()
        tick=lambda ms:r.processing_pipeline.process(r,int(ms*1e6))
        for t in (1000,3000):
            r.buttons['R3']=True;tick(t);tick(t+100);r.assist_engine.reset();r.buttons['R3']=False;tick(t+200);tick(t+400)
        k=live_telemetry.skill_block(r)
        self.assertEqual(k['previous']['name'],'Hocus Pocus');self.assertEqual(k['list'],'List: V')   # last finished move
        self.assertEqual(k['next'],'Elastico')      # order: Elastico, Hocus Pocus, then round again
        r.buttons['R3']=True;tick(5000);tick(5100)
        k=live_telemetry.skill_block(r);self.assertEqual(k['now']['name'],'Elastico');self.assertEqual(k['previous']['name'],'Hocus Pocus')
