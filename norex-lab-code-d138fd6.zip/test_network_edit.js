const fs=require('fs'),vm=require('vm'),assert=require('assert');
const fields=new Map();
function field(id){if(!fields.has(id))fields.set(id,{value:'',checked:false,textContent:'',innerHTML:'',content:'test-token',addEventListener(){},setAttribute(){},classList:{toggle(){}},style:{}});return fields.get(id)}
let fetches=0,modal=false;
const intervals=[];
const context={window:{addEventListener(){}},document:{activeElement:{matches:()=>true},getElementById:field,querySelector:s=>s==='dialog[open]'?(modal?{}:null):field(s),querySelectorAll:()=>[],addEventListener(){},createTreeWalker:()=>({nextNode:()=>null})},fetch:async()=>{fetches++;return {ok:false,json:async()=>({})}},setTimeout:()=>0,setInterval:fn=>intervals.push(fn),MutationObserver:class{observe(){}disconnect(){}},NodeFilter:{SHOW_TEXT:4},localStorage:{getItem(){return null}},console,Event:class{},URL,Blob};
vm.createContext(context);
for(const path of ['network/livebox.js','network/play.js','network/gateway.js'])vm.runInContext(fs.readFileSync(path,'utf8'),context);
(async()=>{
 for(const poll of intervals)await poll();
 assert.equal(fetches,0,'network polling must not rebuild any views while a select is active');
 context.document.activeElement={};modal=true;
 for(const poll of intervals)await poll();
 assert.equal(fetches,0,'an open detail dialog must also defer network polling');
 modal=false;
 for(const poll of intervals)await poll();
 assert.equal(fetches,6,'all network polls resume when the interaction ends');
 field('eventGroup').value='none';field('eventSearch').value='';
 context.document.querySelectorAll=selector=>selector==='#eventRows details'?[{dataset:{group:'none:Recent events'},open:false}]:[];
 vm.runInContext("eventData=[{time:1,type:'connection',message:'test'}];renderEvents()",context);
 assert.match(field('eventRows').innerHTML,/<details data-group="none:Recent events" ><summary>/,'refresh must preserve a collapsed event group');
 console.log('Network dropdown, dialog, polling resumption and expanded-details checks passed');
})().catch(e=>{console.error(e);process.exitCode=1});
