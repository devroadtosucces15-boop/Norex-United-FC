"""Output contract. A successful emit acknowledges only the backend's local write."""
from abc import ABC, abstractmethod

class OutputBackend(ABC):
    backend_id = 'unknown'
    destination = 'unknown'
    transport = 'unknown'

    @abstractmethod
    def emit(self, frame): pass

    @abstractmethod
    def neutralize(self): pass

    @abstractmethod
    def close(self):
        """Release controls and resources; safe to call repeatedly."""

    def status(self):
        return {'backend': self.backend_id, 'destination': self.destination,
                'transport': self.transport, 'transport_connected': False,
                'receipt': 'unverified', 'ps5_receipt': 'unverified',
                'game_receipt': 'unverified'}


def delivery_test_frame(axes, buttons, timestamp, sequence):
    """Manual Cross/Square swap, with all other controls neutral. No automation."""
    from pipeline import neutral_frame
    frame = neutral_frame(source='delivery-test')
    frame.buttons['Square'] = bool(buttons.get('Cross', False))
    frame.buttons['Cross'] = bool(buttons.get('Square', False))
    from dataclasses import replace
    return replace(frame, t_ns=timestamp, sequence=sequence)
