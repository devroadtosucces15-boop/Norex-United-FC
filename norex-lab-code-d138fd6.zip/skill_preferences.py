"""Shared, durable non-gameplay preferences for the one Lab service."""
import json
from profile_store import write_atomic
from backbone.fc27_data import SKILL_BY_ID
from skills import CATALOG

def read(data):
 path=data/'skill-favorites.json'
 if not path.exists():return {'favorites':[]}
 row=json.loads(path.read_text())
 if not isinstance(row,dict) or not isinstance(row.get('favorites'),list):raise ValueError('Invalid favorites file')
 return {'favorites':sorted(set(row['favorites']))}

def update(data,key,favorite):
 valid={'canonical:'+k for k in SKILL_BY_ID}|{'existing:'+k for k in CATALOG}
 if key not in valid or type(favorite) is not bool:raise ValueError('Invalid favorite')
 row=read(data);values=set(row['favorites'])
 if favorite:values.add(key)
 else:values.discard(key)
 row={'favorites':sorted(values)}
 write_atomic(data/'skill-favorites.json',row)
 return row
