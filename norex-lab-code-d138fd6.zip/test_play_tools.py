import tempfile,unittest,math
from pathlib import Path
from pipeline import default_profile
from play_tools import PlayTools,ModeBank,resolve_bindings,CHORDS,TOP_SKILLS
class PlayToolsTests(unittest.TestCase):
 def test_modes_persist_and_distinct(self):
  with tempfile.TemporaryDirectory() as d:
   bank=ModeBank(Path(d),default_profile());bank.configure(True,bank.bindings)
   self.assertTrue(ModeBank(Path(d),default_profile()).enabled)
   bad={n:{'trigger':'both','direction':'left'} for n in bank.bindings}
   with self.assertRaises(ValueError):bank.configure(True,bad)
 def test_hold_once_and_release(self):
  with tempfile.TemporaryDirectory() as d:
   bank=ModeBank(Path(d),default_profile());bank.configure(True,bank.bindings);t=PlayTools();a={'L2':1,'R2':1,'DX':-1}
   self.assertEqual(t.mode_combo(a,bank,0),(None,True));self.assertEqual(t.mode_combo(a,bank,250000000),('Defender',True));self.assertEqual(t.mode_combo(a,bank,500000000),(None,True));t.mode_combo({},bank,600000000);self.assertEqual(t.mode_combo(a,bank,700000000),(None,True))
 def test_conflicts_reassign_atomic(self):
  p=default_profile();rows=[{'trigger':CHORDS[0],'skill':n} for n in TOP_SKILLS];q,report=resolve_bindings(p,rows,set(TOP_SKILLS),{})
  self.assertEqual(len(set(r['trigger'] for r in q['play_tools']['skill_bindings'])),6);self.assertEqual(len(report),5);self.assertEqual(p['play_tools']['skill_bindings'],[])
  with self.assertRaises(ValueError):resolve_bindings(p,rows,set(),{})
 def test_outer_preserves_angle(self):
  p=default_profile()['play_tools'];p['outer'].update(enabled=True,left=.5);a=PlayTools().shape_input({'LX':.3,'LY':.4},p)
  self.assertAlmostEqual(math.hypot(a['LX'],a['LY']),1);self.assertAlmostEqual(a['LX']/a['LY'],.75)
 def test_skill_edge_not_repeated(self):
  p=default_profile();p['play_tools']['skill_bindings']=[{'trigger':CHORDS[0],'skill':'Elastico'}];t=PlayTools();a={'DY':-1};b={'R1':True}
  self.assertEqual(t.skill_edges(a,b,p)[0],'Elastico');self.assertIsNone(t.skill_edges(a,b,p)[0]);t.skill_edges({},b,p);self.assertEqual(t.skill_edges(a,b,p)[0],'Elastico')

 def test_single_mapping_requires_dwell_and_release(self):
  p=default_profile();p['play_tools']['mapping_dwell_ms']=100;p['play_tools']['skill_bindings']=[{'trigger':'R3','skill':'Reverse Elastico'}];t=PlayTools();a={}
  self.assertIsNone(t.skill_edges(a,{'R3':True},p,0)[0])
  self.assertIsNone(t.skill_edges(a,{'R3':True},p,99_000_000)[0])
  self.assertEqual(t.skill_edges(a,{'R3':True},p,100_000_000)[0],'Reverse Elastico')
  self.assertIsNone(t.skill_edges(a,{'R3':True},p,150_000_000)[0])
  t.skill_edges(a,{'R3':False},p,160_000_000)
  self.assertIsNone(t.skill_edges(a,{'R3':True},p,200_000_000)[0])
  self.assertEqual(t.skill_edges(a,{'R3':True},p,300_000_000)[0],'Reverse Elastico')
 def test_single_mapping_second_button_preserves_pending_dwell(self):
  p=default_profile();p['play_tools']['mapping_dwell_ms']=100;p['play_tools']['skill_bindings']=[{'trigger':'R3','skill':'Reverse Elastico'}];t=PlayTools();a={}
  self.assertIsNone(t.skill_edges(a,{'R3':True},p,0)[0])
  self.assertIsNone(t.skill_edges(a,{'R3':True,'Cross':True},p,80_000_000)[0])
  self.assertEqual(t.skill_edges(a,{'R3':True,'Cross':True},p,100_000_000)[0],'Reverse Elastico')
  self.assertIsNone(t.skill_edges(a,{'R3':True},p,200_000_000)[0])
 def test_release_delay(self):
  t=PlayTools();t.diagnose({'Cross':True},{'Cross':True},0);t.diagnose({'Cross':False},{'Cross':True},1000000);t.diagnose({'Cross':False},{'Cross':False},4000000);self.assertEqual(t.release_history[0]['release_delay_ms'],3)

class RuntimePlayToolsTests(unittest.TestCase):
 from test_advanced import AdvancedRuntime
 setUp=AdvancedRuntime.setUp
 def test_mode_is_full_profile_and_preserves_helper_state(self):
  self.l.runtime_action({'action':'mode_select','name':'Finisher'})
  self.assertEqual(self.l.active_mode,'Finisher');self.assertTrue(self.l.profile['play_tools']['shot_response']['enabled']);self.assertFalse(self.l.assists_armed)
 def test_delivery_test_blocks_new_controls(self):
  self.l.runtime_action({'action':'delivery_test_start','local_only':True})
  for action in ['mode_select','mode_save','mode_hotkeys','skill_bindings','skill_pack']:
   with self.assertRaises(ValueError):self.l.runtime_action({'action':action})
 def test_pack_uses_six_unique_ready_sequences(self):
  self.l.runtime_action({'action':'skill_pack'})
  rows=self.l.profile['play_tools']['skill_bindings'];self.assertEqual(len(rows),6);self.assertEqual(len({r['trigger'] for r in rows}),6)
  self.assertTrue(all(self.l.skill_library.recipes[r['skill']]['steps'] for r in rows))
