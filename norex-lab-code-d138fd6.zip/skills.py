"""Named move slots and independent editable training recipes.

The referenced catalog provides names, not proprietary input sequences. Seeds
use older public EA controls with chosen Lab timings; FC27 results are unverified.
"""
import copy,json,math
from pipeline import AXES,BUTTONS,number
CATALOG='''Advanced Rainbow
Around The World
Ball Hop
Ball Juggle
Ball Roll
Ball Roll Cut
Ball Roll Cut Left
Ball Roll Cut Right
Ball Roll Drag
Ball Roll Fake Left
Ball Roll Fake Right
Ball Roll Fake Turn
Ball Roll Flick Left
Ball Roll Flick Right
Ball Roll Left
Ball Roll Right
Body Feint Left
Body Feint Right
Chest Flick
Directional Nutmeg
Drag Back
Drag Back Spin Left
Drag Back Spin Right
Drag Back Turn
Drag To Heel
Elastico
Elastico Chop Left
Elastico Chop Right
Fake Left Go Right
Fake Pass
Fake Pass Exit Left
Fake Pass Exit Right
Fake Right Go Left
Fake Shot L
Fake Shot R
Feint Fwd Turn
Feint Left Exit Right
Feint Right Exit Left
Feint Turn
Flair Nutmegs
Flair Rainbow
Flick Over
Flick Up
Heel Chop Left
Heel Chop Right
Heel Fake
Heel Flick
Heel Flick Turn
Heel To Ball Roll
Heel To Heel Flick
Hocus Pocus
In Air Elastico
Lane Change Left
Lane Change Right
Quick Ball Rolls
Rabona Fake
Reverse Elastico
Reverse In Air Elastico
Reverse Stepover Left
Reverse Stepover Right
Roulette
Roulette Left
Roulette Right
Simple Rainbow
Sombrero Flick
Sombrero Fwd
Sombrero Left
Sombrero Right
Spin Flick
Spin Left
Spin Right
Stepover Left
Stepover Right
Stop And Turn
Stop And Turn Left
Stop And Turn Right
Stutter Feint
T Around The World
Three Touch Roulette Left
Three Touch Roulette Right
Tornado Spin
Triple Elastico
Turn And Spin Left
Turn And Spin Right'''.splitlines()
# Additional V3 labels are editable slots, not invented working sequences.
V3_EXTRA=('Advanced Croqueta','Ball Roll Chop','Ball Roll Cut 180','Ball Roll Scoop Turn','Ball Roll Stepover','Boost Directional Nutmeg','Berba Spin Directional Combo','Cancel Four Touch Turn','Canceled Three Touch Roulette','Canceled Turn And Spin','Cruyff Turn','Diagonal Heel Chop','Drag Back Sombrero','Drag Back Universal','Drag To Drag','Drag Elastico Combo','Fake Berba Opposite Exit','Fake Berba Fake Drag Combo','Fake Shot','Fake Shot Cancel','Four Touch Turn','Jog Openup Fake Shot','Juggle Back Sombrero','Juggling Rainbow','La Croqueta','Late Heel To Heel','Lateral Heel To Heel','Rabona To Scorpion Kick','Rabona Elastico Combo','Rainbow To Scorpion','Ronaldo Chop','Scoop Turn Fake','Skilled Bridge','Stepover Boost','Stepover Feint','Stop V Drag','Stop La Croqueta','Stop Neymar Roll','Stop Elastico Combo','Turn Back','Waka Waka')
CATALOG+=list(V3_EXTRA)
CATALOG=sorted(set(CATALOG)|set('Alternate Elastico Chop|Drag To Chop|Drag To Drag|Drag Turn|First Time Spin|Flair Roulette|Foot To Foot|Four Touch Skill|Giant Fake Shot|Lateral Heel To Heel|Running Fake Drag|Skilled Bridge|Standing Scoop Turn|Stop And Go'.split('|')))
from skill_reference import LEGACY
from approved_video_inventory import reference,video_names as approved_video_names,key as approved_video_key
CATALOG=sorted(set(CATALOG)|set(LEGACY))
from skill_video import video_recipes,video_names,fc27_keys
from skill_meta import facets
_fc27=fc27_keys()
import re as _re
_norm=lambda n:_re.sub(r'[^a-z0-9]','',n.lower().replace('&','and'))
_have={_norm(n) for n in CATALOG}
CATALOG=sorted(set(CATALOG)|{n for n in video_names() if _norm(n) not in _have})
# New video-backed labels are reference slots; no executable sequences are inferred.
_have={approved_video_key(n) for n in CATALOG}
for _name in approved_video_names():
    if approved_video_key(_name) not in _have:
        CATALOG.append(_name);_have.add(approved_video_key(_name))
CATALOG=sorted(CATALOG)
FLEX=('Around The World','T Around The World','Flick Up','Sombrero Fwd','Sombrero Left','Sombrero Right','In Air Elastico','Reverse In Air Elastico','Chest Flick')
EA_OLD='https://www.ea.com/able/resources/fifa/fifa-22/ps4/skill-moves'

def step(ms=80,axes=None,buttons=None): return {'ms':ms,'axes':axes or {},'buttons':buttons or {}}
def rs(x,y,ms=80,buttons=None): return step(ms,{'RX':x,'RY':y},buttons)
def flicks(vectors,buttons=None):
    out=[]
    for x,y in vectors: out.extend([rs(x,y,80,buttons),rs(0,0,40,buttons)])
    return out

def arc(start,end,buttons=None):
    count=max(4,round(abs(end-start)/30)); out=[]
    for i in range(count+1):
        a=math.radians(start+(end-start)*i/count);out.append(rs(round(math.cos(a),6),round(math.sin(a),6),30,buttons))
    return out+[rs(0,0,40)]

def seeds():
    result={n:{'name':n,'relative':True,'status':'Recipe required','source':'Catalog name only; create or record input sequence','steps':[]} for n in CATALOG}
    def add(n,steps):
        result[n]={'name':n,'relative':True,'status':'Training template; FC27 unverified','source':EA_OLD+' (older controls; Lab-chosen timings)','steps':steps}
    for side,x in [('Left',-1),('Right',1)]:
        add('Body Feint '+side,flicks([(x,0)]));add('Ball Roll '+side,[rs(x,0,220),rs(0,0,50)])
        add('Lane Change '+side,[rs(x,0,220,{'L1':True}),rs(0,0,50)])
        add('Stop And Turn '+side,flicks([(0,-1),(x,0)]));add('Turn And Spin '+side,flicks([(0,-1),(x,0)]))
        add('Drag Back Spin '+side,flicks([(0,1),(x,0)]))
        add('Three Touch Roulette '+side,flicks([(0,1),(x,0)],{'L2 button':True})+[step(40,{'L2':0})])
        add('Ball Roll Flick '+side,[rs(-x,0,220),rs(0,0,40)]+flicks([(0,-1)]))
        add('Ball Roll Fake '+side,[rs(x,0,220),rs(0,0,40)]+flicks([(-x,0)]))
        add('Ball Roll Cut '+side,[rs(-x,0,220),step(160,{'LX':x,'LY':0,'RX':0,'RY':0}),step(40,{'LX':0,'LY':0})])
        start=90;end=450 if side=='Right' else -270
        add('Roulette '+side,arc(start,end));add('Spin '+side,arc(start,end,{'R1':True}))
        add('Elastico Chop '+side,arc(0,180 if side=='Left' else -180,{'R1':True}))
        diagonal=x/math.sqrt(2)
        fake=[step(60,buttons={'Square':True}),step(60,buttons={'Cross':True}),step(40)]
        add('Fake Pass Exit '+side,[step(s['ms'],{'R2':1,'LX':diagonal,'LY':-1/math.sqrt(2)},dict(s['buttons'],**{'R2 button':True})) for s in fake]+[step(40,{'R2':0,'LX':0,'LY':0})])
        add('Heel Chop '+side,[step(60,{'L2':1,'LX':x,'LY':0},{'Circle':True}),step(60,{'L2':1,'LX':x,'LY':0},{'Cross':True}),step(40,{'L2':0,'LX':0,'LY':0})])
    add('Heel Flick',flicks([(0,-1),(0,1)]));add('Heel To Heel Flick',flicks([(0,-1),(0,1)]))
    add('Heel Flick Turn',flicks([(0,-1),(0,1)],{'R1':True}))
    add('Simple Rainbow',flicks([(0,1),(0,-1),(0,-1)]))
    add('Advanced Rainbow',flicks([(0,1)])+[rs(0,-1,220),rs(0,0,40)]+flicks([(0,-1)]))
    add('Sombrero Flick',flicks([(0,-1),(0,-1),(0,1)]))
    add('Feint Fwd Turn',flicks([(0,1),(0,1)]))
    add('Quick Ball Rolls',[rs(0,1,220),rs(0,0,40)])
    add('Flick Over',[rs(0,-1,220,{'L1':True}),rs(0,0,40)])
    add('Drag Back',[step(80,{'LX':0,'LY':1},{'L1':True,'R1':True}),step(40,{'LX':0,'LY':0})])
    add('Elastico',arc(0,180));add('Reverse Elastico',arc(180,0))
    add('Fake Left Go Right',arc(180,360));add('Fake Right Go Left',arc(0,180))
    add('Hocus Pocus',[rs(-1,0)]+arc(180,360));add('Triple Elastico',[rs(1,0)]+arc(0,180))
    add('Around The World',arc(-90,270));add('T Around The World',arc(-90,270)+flicks([(0,-1)]))
    add('In Air Elastico',flicks([(1,0),(-1,0)]));add('Reverse In Air Elastico',flicks([(-1,0),(1,0)]))
    add('Ball Juggle',[step(100,{'L2':1},{'R1':True}),step(60,{'L2':0})])
    add('Ball Hop',[step(80,buttons={'L1':True,'R3':True}),step(50)])
    add('Flick Up',[step(220,{'LX':0,'LY':-1}),step(40,{'LX':0,'LY':0})])
    add('Sombrero Left',[step(220,{'LX':-1,'LY':0}),step(40,{'LX':0,'LY':0})]);add('Sombrero Right',[step(220,{'LX':1,'LY':0}),step(40,{'LX':0,'LY':0})])
    add('Chest Flick',[step(80,{'L2':1},{'R3':True}),step(60,{'L2':1}),step(80,{'L2':1},{'R3':True}),step(40,{'L2':0})])
    add('Fake Pass',[step(60,{'R2':1},{'Square':True}),step(60,{'R2':1},{'Cross':True}),step(40,{'R2':0})])
    names={_norm(n):n for n in result}
    from skill_video import supplement_recipes
    for n,row in {**video_recipes()[0],**supplement_recipes()[0]}.items():
        key=names.get(_norm(n))
        if key: result[key]=dict(row,name=key)
    # Add playable training variants only where the existing slot has no sequence.
    # Existing working templates and stored custom recipes retain precedence.
    from approved_video_recipes import recipes as approved_recipes
    approved_names={approved_video_key(n):n for n in result}
    for name,row in approved_recipes().items():
        dest=approved_names.get(approved_video_key(name))
        if dest and not result[dest]['steps']:result[dest]=dict(row,name=dest)
    for row in result.values():
        for s in row['steps']:
            if s['buttons'].get('L2 button'): s['axes']['L2']=1.
            if s['buttons'].get('R2 button'): s['axes']['R2']=1.
    return result

def validate_recipe(row):
    if not isinstance(row,dict) or row.get('name') not in CATALOG or type(row.get('relative')) is not bool: raise ValueError('Invalid named skill recipe')
    steps=row.get('steps')
    if not isinstance(steps,list) or not 1<=len(steps)<=128: raise ValueError('Recipe needs 1–128 steps')
    total=0
    for s in steps:
        if not isinstance(s,dict) or set(s)!={'ms','axes','buttons'}: raise ValueError('Step requires ms, axes and buttons')
        number(s['ms'],5,2000);total+=s['ms']
        if not isinstance(s['axes'],dict) or not isinstance(s['buttons'],dict): raise ValueError('Invalid step state')
        for k,v in s['axes'].items():
            if k not in AXES.values(): raise ValueError('Unsupported axis')
            number(v,0 if k in ('L2','R2') else -1,1)
        if any(k not in BUTTONS.values() or type(v) is not bool for k,v in s['buttons'].items()): raise ValueError('Invalid recipe buttons')
    if total>10000: raise ValueError('Recipe cannot exceed 10 seconds')
    result=copy.deepcopy(row); result['status']='Custom recipe; game result unverified';result['source']='User-authored or recorded local input'
    return result

class SkillLibrary:
    def __init__(self,data,load_saved=True):
        self.path=data/'skill-recipes.json'; self.recipes=seeds()
        if load_saved and self.path.exists():
            saved=json.loads(self.path.read_text())
            for name,row in saved.items():
                if row.get('steps'):
                    if str(row.get('status','')).startswith(('Training template','Menu-notation recipe')): continue
                    valid=validate_recipe(row)
                    if name in self.recipes and row['steps']==self.recipes[name]['steps'] and row['relative']==self.recipes[name]['relative']: continue
                    self.recipes[name]=valid
        elif load_saved: self.persist()
    def persist(self):
        from profile_store import write_atomic
        write_atomic(self.path,self.recipes)
    def save(self,row):
        valid=validate_recipe(row);previous=self.recipes;self.recipes=copy.deepcopy(previous);self.recipes[valid['name']]=valid
        try:self.persist()
        except Exception:
            self.recipes=previous;raise
    def catalog(self):
        rows=[]
        for n,r in self.recipes.items():
            evidence=reference(n)
            evidence['verification']['implementation']='bounded local sequence' if r['steps'] else 'recipe not configured'
            from approved_video_recipes import unavailable_reason
            evidence['playback_reason']=None if r['steps'] else unavailable_reason(n)
            capture=r.get('overlay_capture')
            evidence['playback_kind']='video controller replay' if capture else 'local recipe' if r['steps'] else 'reference only'
            evidence['playback_capture']=copy.deepcopy(capture)
            if capture:
                evidence['notes']+=' Play replays one measured controller-animation cycle and finishes with an explicit neutral release.'
                if capture.get('playstyle_dependency'):evidence['playstyle_dependency']=capture['playstyle_dependency']
            facts=facets(n,r,_norm(n) in _fc27)
            facts['rating']=[str(evidence['stars'])+' star'] if evidence['stars'] else ['unrated']
            facts['menu']=['FC27 video reference'] if evidence['video_membership']=='FC27' else ['FC26 video reference'] if evidence['video_membership']=='FC26 only' else ['not established by supplied videos']
            facts['playstyle']=[evidence['playstyle_dependency']] if evidence['playstyle_dependency'] else []
            rows.append({**evidence,'name':n,'ready':bool(r['steps']),'status':r['status'],'flex':n in FLEX,
                         'recipe_status':'Unverified recipe' if r['steps'] else 'Recipe not configured','in_fc27_menu':_norm(n) in _fc27,'facets':facts,
                         'duration_ms':sum(s['ms'] for s in r['steps'])})
        return rows
    def from_capture(self,name,source,start_ms,duration_ms):
        number(start_ms,0,600000); number(duration_ms,20,10000)
        start=start_ms*1e6;end=start+duration_ms*1e6; steps=[]
        frames=source.frames
        for i,f in enumerate(frames[:-1]):
            finish=frames[i+1].t_ns
            lo=max(start,f.t_ns);hi=min(end,finish)
            if hi-lo<5_000_000: continue
            s=step(round((hi-lo)/1e6,3),dict(f.axes),dict(f.buttons))
            if steps and s['axes']==steps[-1]['axes'] and s['buttons']==steps[-1]['buttons'] and steps[-1]['ms']+s['ms']<=2000: steps[-1]['ms']+=s['ms']
            else: steps.append(s)
        row={'name':name,'relative':False,'steps':steps};self.save(row);return self.recipes[name]
