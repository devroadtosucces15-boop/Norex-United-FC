"""Explicit play modes, conflict-managed skill bindings and response tools."""
import copy,json,math
from pathlib import Path
from pipeline import BUTTONS,number,validate_profile
MODES=('Defender','Creator','Finisher')
DIRECTIONS=('up','right','down','left')
CHORDS=[f'{modifier} + D-pad {d}' for modifier in ('R1','L1','L2','R2') for d in DIRECTIONS]
SINGLE_TRIGGERS=('L3','R3','Create','Options')
MAPPING_TRIGGERS=[*SINGLE_TRIGGERS,*CHORDS]
TOP_SKILLS=('Elastico','Reverse Elastico','Hocus Pocus','Triple Elastico','Advanced Rainbow','Turn And Spin Left')

def defaults():
    return {'outer':{'enabled':False,'left':1.,'right':1.},'shot_response':{'enabled':False,'normal':1.15,'finesse':1.25,'power':1.3},'manual_action_priority':True,'clutch_context':'shoot','chord_delay_ms':0,'mapping_dwell_ms':100,'skill_bindings':[]}

def validate(c,p):
    if not isinstance(c,dict):raise ValueError('Invalid play tools')
    result=defaults();result.update(copy.deepcopy(c));c=result
    if set(c)!=set(defaults()):raise ValueError('Unknown play tool')
    for key,fields in [('outer',('left','right')),('shot_response',('normal','finesse','power'))]:
        row=c[key]
        if not isinstance(row,dict) or set(row)!={'enabled',*fields} or type(row['enabled']) is not bool:raise ValueError('Invalid response tool')
        for f in fields:number(row[f],.5 if key=='outer' else .25,1 if key=='outer' else 4)
    if type(c['manual_action_priority']) is not bool:raise ValueError('Invalid manual action priority')
    if c['clutch_context'] not in ('shoot','pass','cross'):raise ValueError('Invalid precision clutch context')
    number(c['chord_delay_ms'],0,40);number(c['mapping_dwell_ms'],0,500)
    from skills import CATALOG
    from skill_lists import is_list
    rows=c['skill_bindings']
    if not isinstance(rows,list) or len(rows)>32:raise ValueError('At most 32 skill mappings')
    if any(not isinstance(row,dict) or set(row)!={'trigger','skill'} or row['trigger'] not in MAPPING_TRIGGERS or (row['skill'] not in CATALOG and not is_list(row['skill'])) for row in rows):raise ValueError('Invalid skill mapping')
    if len({row['trigger'] for row in rows})!=len(rows):raise ValueError('Skill triggers must be unique; use Resolve conflicts')
    return c

def occupied(p):
    # Whole-button shortcuts conflict with a chord that uses the same modifier.
    return {v for v in p['advanced']['shortcuts'].values() if v!='Disabled'}|{r['button'] for r in p['assists']['button_skills'].values() if r['button']!='Disabled'}|{p['assists']['lock_button']}

def resolve_bindings(p,rows,ready,mode_bindings):
    from skills import CATALOG
    from skill_lists import is_list,ready_members
    if not isinstance(rows,list) or len(rows)>32:raise ValueError('At most 32 skill mappings')
    result=[];used=set();report=[]
    blocked=occupied(p)
    reserved={f"{r['trigger']} + D-pad {r['direction']}" for r in mode_bindings.values() if r['trigger']!='both'}
    available=[x for x in MAPPING_TRIGGERS if x.split(' + ')[0] not in blocked and x not in reserved]
    for row in rows:
        if not isinstance(row,dict) or not (row.get('skill') in CATALOG or is_list(row.get('skill'))) or row.get('trigger') not in MAPPING_TRIGGERS:raise ValueError('Invalid skill mapping')
        if is_list(row['skill']):
            if not ready_members(row['skill'],ready):raise ValueError(row['skill']+': add at least one move with a recipe to this list first')
        elif row['skill'] not in ready:raise ValueError(row['skill']+': no input recipe available; create/record one first')
        wanted=row['trigger'];chosen=wanted
        if chosen in used or chosen not in available:
            chosen=next((x for x in available if x not in used),None)
            if chosen is None:raise ValueError('No free skill trigger combinations; remove a binding or free a modifier shortcut')
            report.append(f"{row['skill']}: {wanted} → {chosen}")
        used.add(chosen);result.append({'trigger':chosen,'skill':row['skill']})
    q=copy.deepcopy(p);q['play_tools']['skill_bindings']=result
    return validate_profile(q),report

class ModeBank:
    def __init__(self,data,base,load_saved=True):
        self.path=data/'play-modes.json';self.enabled=False;self.bindings={n:{'trigger':'both','direction':d} for n,d in zip(MODES,('left','up','right'))};self.profiles={}
        for n in MODES:
            p=copy.deepcopy(base);p['arm_on_startup']=False
            p['description']=n+' input preset; edit and save this mode. Game outcomes unverified.'
            if n=='Defender':
                p['advanced']['defense_only_jockey']=True;p['advanced']['contexts']['switching']={'enabled':True,'exponent':.85}
            if n=='Creator':
                p['advanced']['contexts']['pass']={'enabled':True,'exponent':1.2};p['advanced']['contexts']['cross']={'enabled':True,'exponent':1.2}
            if n=='Finisher':
                p['advanced']['contexts']['shoot']={'enabled':True,'exponent':1.3};p['play_tools']['shot_response']['enabled']=True
            self.profiles[n]=validate_profile(p)
        if load_saved and self.path.exists():
            row=json.loads(self.path.read_text());self.configure(row['enabled'],row['bindings'],persist=False)
            for n in MODES:self.profiles[n]=validate_profile(row['profiles'][n])
        elif load_saved:self.persist()
    def configure(self,enabled,bindings,persist=True):
        if type(enabled) is not bool or not isinstance(bindings,dict) or set(bindings)!=set(MODES):raise ValueError('Invalid mode combinations')
        combos=[]
        for r in bindings.values():
            if not isinstance(r,dict) or set(r)!={'trigger','direction'} or r['trigger'] not in ('both','L2','R2') or r['direction'] not in DIRECTIONS:raise ValueError('Invalid mode hotkey')
            combos.append((r['trigger'],r['direction']))
        if len(set(combos))!=3:raise ValueError('Each mode needs a distinct combination')
        self.enabled=enabled;self.bindings=copy.deepcopy(bindings)
        if persist:self.persist()
    def persist(self):
        from profile_store import write_atomic
        write_atomic(self.path,{'enabled':self.enabled,'bindings':self.bindings,'profiles':self.profiles})
    def save(self,name,p):
        if name not in MODES:raise ValueError('Unknown mode')
        validated=validate_profile(p);previous=self.profiles;self.profiles=copy.deepcopy(previous);self.profiles[name]=validated
        try:self.persist()
        except Exception:
            self.profiles=previous;raise

class PlayTools:
    def __init__(self):self.reset()
    def reset(self):self.mode_candidate=None;self.mode_since=0;self.mode_latched=False;self.previous=set();self.release_pending={};self.release_history=[];self.last_physical={};self.last_generated={};self.mapping_candidates={};self.mapping_latched=set()
    def prime(self,axes,buttons):self.previous={ch for ch in MAPPING_TRIGGERS if self.matches(ch,axes,buttons)}
    @staticmethod
    def direction(a):
        x,y=a.get('DX',0),a.get('DY',0)
        if x and y:return None
        return 'right' if x>0 else 'left' if x<0 else 'down' if y>0 else 'up' if y<0 else None
    @classmethod
    def matches(cls,chord,a,b):
        if chord in SINGLE_TRIGGERS:return bool(b.get(chord,False))
        modifier,d=chord.split(' + D-pad ')
        held=a.get(modifier,0)>.8 if modifier in ('L2','R2') else b.get(modifier,False)
        return bool(held and cls.direction(a)==d)
    def mode_combo(self,a,bank,now):
        if not bank.enabled:return None,False
        d=self.direction(a);l=a.get('L2',0)>.8;r=a.get('R2',0)>.8
        name=next((n for n,row in bank.bindings.items() if row['direction']==d and ((l and r) if row['trigger']=='both' else (l and not r if row['trigger']=='L2' else r and not l))),None)
        if name!=self.mode_candidate:self.mode_candidate=name;self.mode_since=now;self.mode_latched=False
        if name and not self.mode_latched and now-self.mode_since>=250_000_000:self.mode_latched=True;return name,True
        return None,bool(name)
    def shape_input(self,a,c):
        a=dict(a)
        if c['outer']['enabled']:
            for label,x,y in [('left','LX','LY'),('right','RX','RY')]:
                radius=math.hypot(a.get(x,0),a.get(y,0));scale=min(1,radius/c['outer'][label])/radius if radius else 0
                a[x]=a.get(x,0)*scale;a[y]=a.get(y,0)*scale
        return a
    def skill_edges(self,a,b,p,now=None):
        rows=p['play_tools']['skill_bindings']
        held={row['trigger'] for row in rows if self.matches(row['trigger'],a,b)}
        # A mapped press owns its trigger, not every other physical control.
        # Compatible held buttons must not restart dwell or suppress the edge.
        eligible=held
        if now is None:
            rising=eligible-self.previous
        else:
            dwell=int(p['play_tools'].get('mapping_dwell_ms',100))*1_000_000
            for x in list(self.mapping_candidates):
                if x not in eligible:
                    self.mapping_candidates.pop(x,None);self.mapping_latched.discard(x)
            for x in eligible:self.mapping_candidates.setdefault(x,now)
            rising={x for x in eligible if x not in self.mapping_latched and now-self.mapping_candidates[x]>=dwell}
            self.mapping_latched|=rising
        edge=next((row['skill'] for row in rows if row['trigger'] in rising),None)
        self.previous=held
        return edge,held
    def diagnose(self,physical,generated,now):
        for key in BUTTONS.values():
            if self.last_physical.get(key) and not physical.get(key):self.release_pending[key]=now
            if key in self.release_pending and not generated.get(key):
                self.release_history.append({'button':key,'release_delay_ms':max(0,(now-self.release_pending.pop(key))/1e6)})
        self.release_history=self.release_history[-64:];self.last_physical=dict(physical);self.last_generated=dict(generated)
