import tempfile, unittest, json
from pathlib import Path
from unittest.mock import patch
import lab
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.patch=patch.object(lab,'DATA',Path(self.tmp.name)); self.patch.start(); self.l=lab.Lab()
 def tearDown(self): self.l.end_record(); self.patch.stop(); self.tmp.cleanup()
 def test_normalize_and_deadzone(self):
  self.assertEqual(lab.normalize(255,0,255,127.5),1); self.assertEqual(lab.normalize(0,0,255,127.5),-1)
  self.assertEqual(lab.radial(.03,.02,.08),[0,0]); self.assertAlmostEqual(lab.radial(1,0,.08)[0],1)
 def test_events_timing_dropped(self):
  self.l.feed(10,0,3,0,140); self.l.feed(10,0,1,304,1); self.l.feed(10,0,0,0,0); self.l.feed(10,4000,0,0,0)
  self.assertEqual(self.l.raw['LX'],140); self.assertTrue(self.l.buttons['Cross']); self.assertAlmostEqual(self.l.intervals[0],4)
  self.l.feed(10,5000,0,3,0); self.l.feed(10,6000,3,0,200); self.l.feed(10,6000,0,0,0)
  self.assertEqual(self.l.raw['LX'],140); self.assertEqual(self.l.dropped,1)
 def test_profile_record_export(self):
  self.l.status='Connected'; self.l.action({'action':'deadzone','value':.12}); self.l.action({'action':'save','name':'test'})
  self.l.action({'action':'deadzone','value':.2}); self.l.action({'action':'load','name':'test'}); self.assertEqual(self.l.profile['deadzone'],.12)
  with self.assertRaises(ValueError): self.l.action({'action':'save','name':'../x'})
  with self.assertRaises(ValueError): self.l.action({'action':'deadzone','value':float('nan')})
  self.l.action({'action':'record'}); self.l.feed(1,0,1,304,1); self.l.action({'action':'stop'})
  lines=(lab.DATA/self.l.record_name).read_text().splitlines(); self.assertEqual(json.loads(lines[1])['value'],1)
 def test_calibration_includes_stationary_state(self):
  self.l.raw={'LX':129,'LY':127,'RX':128,'RY':128}; self.l.bounds={k:[0,255] for k in self.l.raw}; self.l.status='Connected'
  self.l.action({'action':'calibrate','mode':'center'}); self.l.tick_cal(); self.l.cal['until']=0; self.l.tick_cal()
  self.assertEqual(self.l.profile['centers']['LX'],129); self.assertEqual(self.l.cal_result['samples'],2)
 def test_range_calibration(self):
  self.l.status='Connected'; self.l.raw={'L2':0,'LX':0}; self.l.action({'action':'calibrate','mode':'range'}); self.l.tick_cal()
  self.l.raw={'L2':255,'LX':255}; self.l.cal['until']=0; self.l.tick_cal()
  self.assertEqual(self.l.profile['ranges']['L2'],[0,255]); self.assertEqual(self.l.profile['ranges']['LX'],[0,255])
 def test_disconnect_discovery_uses_identity(self):
  for d in lab.discover(): self.assertIn('DualSense',d['name'])
if __name__=='__main__': unittest.main()
