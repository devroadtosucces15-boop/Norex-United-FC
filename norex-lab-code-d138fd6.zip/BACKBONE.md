# NOREX Controller Lab backend v2

This is the isolated development copy on ME2001. The original Controller Lab,
PS5 Gateway and unrelated NOREX repositories are outside its implementation scope.
The existing dashboard is retained. This document freezes the backend contract
for a later frontend implementation.

## Processing ownership

`Runtime.on_frame()` obtains one final logical frame from
`backbone.processing.ProcessingPipeline` and alone handles recording/output.
The chain is hardware normalization, profile calibration and response/remapping,
legacy response adapters, v2 response helpers, selected bounded local recipes,
then the deterministic final-frame resolver. Legacy adapters propose changes;
they do not own the output device. Replay emits already-recorded final frames
without processing them again.

- RAW uses normalized hardware bounds and bypasses profile calibration, dead
  zones, curves, remaps, helpers, hotkeys and generated sequences. It preserves
  all physical button/axis states without overwriting the saved configuration.
- Physical L1 + R1 with both analog triggers above 0.8 is the escape chord.
  It cancels pending generated work and passes the complete physical frame.
- The existing physical Circle/Square priority preference remains authoritative
  for manual actions. The full escape chord always works, regardless of that
  preference.
- Returning from RAW, arming while a trigger is held, disconnecting, disarming,
  output failure and emergency stop clear or prime temporal/sequence state.
  Existing controls are never interpreted as new edges merely because a mode
  changed.
- Resolver priorities are base/ordered adapter stages, recipe 80, physical
  action escape 90 and safety 100. Equal-priority intent ties use stable source
  IDs; contradictory intents from one source are rejected. Intent values must
  be finite, buttons boolean, sticks bounded to [-1, 1], triggers to [0, 1].
- Only one v2 left-stick held context wins: shot, cross, through pass,
  controlled dribble, jockey, sprint, in that order. Goalkeeper RS is independent.
  Existing legacy aim contexts win over equivalent v2 held aim modifiers.
- V2 context or temporal helpers suppress their equivalent legacy helper rather
  than shaping the same concept twice. Direction stability wins over v2
  smoothing. Intent decisions and helper suppressions are reported.
- Precision and outer response are deliberate sequential base transforms.
  Configured curves/remaps remain profile behavior even when helpers are disarmed.

## Knowledge and execution

`backbone/catalog_facts.json` contains extracted factual control-table records.
`fc27_data.py` adds stable IDs, context, provenance, source disagreement,
verification fields and explicit execution limitations. Sources were checked
on 2026-10-06. EA's gameplay notes are primary evidence for mechanics and three
explicit new controls. The complete input tables are community-reported facts,
not EA-certified controls or game-tested recipes.

The reference contains 73 established normal skill entries, four new TBA entries,
nine distinct juggling entries, nine simplified-skill direction/rating entries,
173 context-specific controls plus stable aliases and three EA-reported new
controls, and multi-control combinations. Source counting disagreements and
juggling-rating ambiguity are recorded rather than silently resolved.

Fake Turn, Ball Roll Spin, Stepover Combo and Kneel Header have no executable
input. Ambiguous source sequences also cannot become v2 executable recipes.
Reference entries are never automatically compiled into timing sequences.
Simplified skills are an in-game contextual setting: the Lab cannot determine
its availability, player rating, selected move, possession, screen-facing,
animation, opponents or results. Attribute/PlayStyle requirements remain unknown
unless actually sourced. No helper changes player attributes.

Canonical user recipes are explicitly authored local controller input with
5–2000 ms per step, at most 128 steps and 10 seconds total. Relative recipes
use the operator's existing facing-angle setting; it is not inferred from the
screen. They remain game-unverified. Recipes and shortcuts require local-use
acknowledgment, validation and explicit selection; bindings are never silently
assigned. TBA/ambiguous entries are rejected even for user recipe edits.
The historical Lab library and its older training templates remain separate,
unchanged in meaning and explicitly unverified.

## Helpers

The 12 benefit-grouped v2 entries include 11 implemented response helpers and
RAW comparison utility. Metadata includes affected physical inputs, purpose,
examples, downsides, unchanged attributes, lower/higher parameter meaning,
defaults, units, bounds, conflicts and guided A/B tests. Helpers are available
across all positions and archetypes and default off.

All v2 response helpers shape sticks or filter small temporal changes. They
never manufacture button presses or animation timings. Strength is 0–100%,
response exponent 0.25–4, smoothing window 0–40 ms and stability band 0–15 degrees.
Neutral input, reversal, full travel, nonpositive time and gaps over 100 ms
immediately bypass temporal memory. The legacy opt-in local training functions
remain available through their original contracts.

## Stable HTTP contract

V2 JSON uses `schema: 1` and `api_version: 2`. Legacy `/api/state` and
`/api/action` keep their existing response format. Every route retains localhost
Host/Origin checks and `Cache-Control: no-store`.

| Method and route | Payload |
| --- | --- |
| GET `/api/v2/fc27` | Controls, skills, juggling, simplified skills, combos, mechanics, provenance and count notes |
| GET `/api/v2/helpers` | Benefit groups, education, parameters and conflict order |
| GET `/api/v2/skills` | Canonical recipe/shortcut readiness; filters `q`, `stars`, `status`, `kind`, `ready` |
| GET `/api/v2/effective` | Complete configured profile, eligible helper configuration, suppressions, actual processing trace, physical/final frames, arming and output truth |
| GET `/api/v2/comparison` | Bounded session samples and subjective results |
| GET `/api/v2/profiles` | Profile inventory and last operation |
| GET `/api/v2/contracts` | Authoritative route/action fields and bounds |
| POST `/api/v2/action` | Validated mutation; `{ok, action, effective}` envelope |

`effective` helper configuration means eligible configuration given current
arming/RAW/conflict rules; actual held-context applications appear in processing
trace. The complete configuration includes preserved legacy settings.

V2 actions: `set_mode`, `helpers_configure`, `comparison_start`,
`comparison_stop`, `comparison_choose`, `skill_recipe_save`,
`skill_recipe_remove`, `skill_bindings`, `skill_run`, `profile_save`,
`profile_load`, `configure`, `arm_assists`, `disarm_assists`, `emergency_stop`.
Required/optional fields are available from `/api/v2/contracts`. Unknown fields,
unsupported versions, duplicate filters, nonfinite parameters and conflicts are
rejected before live mutation. Request limit is 262144 bytes.

Example mode request: `{"action":"set_mode","mode":"RAW"}`.
Example helper request:
`{"action":"helpers_configure","helpers":{"precision_stick":{"enabled":true,"strength":60,"exponent":1.8}}}`.
Unspecified v2 helper entries reset to their disabled defaults in this complete
helper configuration request; it is not a partial patch.

V2 errors contain `ok: false` and `{error: {code, message}}`: invalid input is
400, local-origin rejection 403, missing routes/profiles 404, I/O failures 500.
No route can promote PS5/game receipt to verified. `active` is backend lifecycle,
`local_virtual` specifically identifies active uinput, and
`local_write_acknowledged` requires an actual successful backend emit.
Neither backend creation nor local writes prove that PS5 received anything.

## RAW / NOREX comparisons

A comparison pair stores an immutable configuration/arming identity. Start RAW,
collect input, stop, then start NOREX with the same configuration and stop.
Choosing RAW/NOREX/CANNOT_TELL requires both nonempty samples. Configuration
changes end the active sample before counting new frames. Samples, current
physical/final frames and up to 32 results are session state, not profile state.
Measurements count processing observations; they are not hardware polling,
network latency or game outcomes. Feedback is explicitly subjective/unverified.

## Profiles and recovery

Profile schema 2 is preserved for existing callers with additive validated v2
helper and canonical recipe sections. Flat profile schemas 1/2 and complete
snapshot schema 1 migrate to complete snapshot schema 2. Future/boolean schema
versions and unknown profile fields are rejected.

A snapshot contains calibration, curves, remaps/inversion, legacy and v2
helpers/parameters, legacy recipes, canonical recipes and bindings, all mode
profiles/hotkeys, selected mode/base profile and visual selections. Device
discovery, transport/media settings, Lab power, comparison sessions, live arming,
output and replay are excluded. Snapshot restore disarms helpers and does not
restore startup arming, output or replay.

Each document write serializes with nonfinite JSON rejected, uses a unique
same-directory temporary file, fsyncs, atomically renames and fsyncs the directory.
Pre-rename failures preserve the prior document. A directory-fsync failure after
rename means the new document is visible but durability is uncertain; it remains
an I/O error rather than being advertised as a durable save.

A named snapshot is the save commit point. A durable intent journal spans the
subsequent startup-selection replacement. If that replacement is interrupted,
Save reports the complete named profile as saved with
`startup_recovery_pending: true` and a warning. Next launch checks the committed
named bytes and completes startup selection idempotently. A pre-commit failure
never activates an uncommitted profile. The runtime lock serializes callers.

`startup-profile.json` is the complete restored selection. Startup uses its
embedded recipes/modes instead of stale auxiliary files. Saving a mode edits
that saved mode and preserves the base profile. Profile results include name,
operation, timestamp and snapshot version. Instance-specific storage paths keep
independent API/test instances from accidentally saving into another Lab's data.

Recording/replay retains complete-frame semantics and neutral closure. Large
validated profiles now have a separately bounded 262144-byte recording header;
frame lines retain the 8192-byte limit, with the existing overall archive limits.

## Validation and operation

Run `python3 -m pytest -q` from this directory. Tests use isolated data and an
ephemeral localhost HTTP server, preserving actual saved profiles and the original
running Lab. The original JavaScript compatibility check remains
`node test_controller_edit.js`. Rollback source/data snapshots and manifests are
under `work/backend-start-*`; pytest excludes these historical copies.

For a separate development preview, use `python3 lab.py --port 8791` from this
copy after verifying the USB mount. Port 8790 belongs to the current Lab.
No service, original profile, device permission, PS5 registration, Gateway route
or unrelated repository is changed by this backend implementation.
Frontend redesign, physical reconnect experiments and in-game/PS5 delivery
verification remain separate work. Existing automated reconnect/capture/output
coverage is retained; host observations are never presented as console proof.

## Single controller console (2026-10-06)

`/lab` is the only settings interface in this copy. `/legacy` serves a small redirect to `/lab`; the previous HTML is retained only in the work backup. Diagnostics contains read-only delivery and processing data. The Skills page has one chord mapper that writes both recipe identities as a single validated profile configuration, preserving provenance. Move names and Details buttons open a native dialog; saved historical recipes use the same visual builder, while canonical source facts remain separate from local timing. Polling preserves form drafts.

The user-requested `league_striker_manual` complete snapshot uses linear sticks/triggers, 0.03 radial stick deadzone and 0.02 trigger deadzone, identity button/axis maps, no generated actions or skill chords, and disabled mode hotkeys. These are a conservative local starting point, not measured optimal FC27 settings or latency compensation. `mike_before_league` preserves the previous working setup; `mike` was not overwritten. The original port 8790 Lab runtime was stopped after confirming its output was inactive; its repository was not changed. Port 8791 remained active without a restart.
