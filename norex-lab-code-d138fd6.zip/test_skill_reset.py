import copy,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
import lab
from pipeline import neutral_frame

class FakeOut:
    def __init__(s):s.last=None
    def emit(s,f):s.last=f
    def neutralize(s):s.last=neutral_frame()
    def close(s):s.neutralize()

class SkillResetTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.addCleanup(self.tmp.cleanup)
  with patch.object(lab,'DATA',Path(self.tmp.name)):self.r=lab.Lab()
  r=self.r;r.status='Connected';r.raw={'LX':0,'LY':-1,'RX':0,'RY':0,'L2':0,'R2':0,'DX':0,'DY':0}
  r.bounds={k:[0,1] if k in ('L2','R2') else [-1,1] for k in r.raw}
  r.buttons=copy.deepcopy(neutral_frame().buttons)
  r.profile['play_tools']['skill_bindings']=[{'trigger':'R3','skill':'Lane Change Left'}]
  r.arm_current()
 def tick(self,ms,**b):
  self.r.buttons.update({k:False for k in self.r.buttons});self.r.buttons.update(b)
  axes,buttons,*_=self.r.processing_pipeline.process(self.r,int(ms*1e6));return axes,buttons
 def test_stale_mid_skill_output_is_released_to_neutral(self):
  r=self.r;r.output=FakeOut();r.output_source='physical'
  r.assist_engine.start_recipe('x',[{'ms':500,'axes':{'RX':-1,'L2':1.0},'buttons':{'L1':True}}],time.monotonic_ns(),config=r.profile['assists'],relative=False)
  r.on_frame();self.assertTrue(r.output.last.buttons['L1']);self.assertEqual(r.output.last.axes['L2'],1.0)
  r.release_if_stale();self.assertTrue(r.output.last.buttons['L1'])  # fresh frames are left alone
  r.last_output_ns-=500_000_000;r.release_if_stale()
  self.assertFalse(any(r.output.last.buttons.values()));self.assertFalse(any(r.output.last.axes.values()))
  self.assertIsNone(r.assist_engine.active_recipe);self.assertEqual(r.physical_frame.axes,neutral_frame().axes)
 def test_stale_telemetry_output_reads_neutral(self):
  from live_telemetry import telemetry
  r=self.r;r.output=FakeOut();r.output_source='physical'
  r.assist_engine.start_recipe('x',[{'ms':500,'axes':{'RX':-1},'buttons':{'L1':True}}],time.monotonic_ns(),config=r.profile['assists'],relative=False)
  r.on_frame();self.assertTrue(telemetry(r)['output']['buttons']['L1'])
  r.last_output_ns-=1_000_000_000;t=telemetry(r)['output']
  self.assertFalse(any(t['buttons'].values()));self.assertFalse(any(t['axes'].values()))
 def test_physical_shot_wins_over_skill_even_while_trigger_held(self):
  self.tick(1000);self.tick(1010,R3=True);_,b=self.tick(1120,R3=True);self.assertTrue(b['L1'])
  _,b=self.tick(1140,R3=True,Circle=True)
  self.assertTrue(b['Circle']);self.assertFalse(b['L1']);self.assertFalse(b['R3'])
  self.assertIsNone(self.r.assist_engine.active_recipe)
  _,b=self.tick(1170,R3=True,Circle=True);self.assertTrue(b['Circle']);self.assertFalse(b['L1'])
 def test_cancel_keeps_held_button_edge_memory(self):
  e=self.r.assist_engine;e.previous['Square']=True;e.cancel();self.assertTrue(e.previous['Square'])
  e.reset();self.assertFalse(e.previous['Square'])
