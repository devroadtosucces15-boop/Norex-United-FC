"""Evidence separate from executable local recipes. Unknown is never zero stars.

Reviewed 2026-10-06. Community menu transcriptions are reported evidence,
not official EA confirmation or proof of a successful game animation.
"""
import copy

MENU = 'https://proclubshq.com/blog/fc27-skill-moves/'
EA26 = 'https://forums.ea.com/blog/ea-sports-fc-game-info-hub-en/ea-sports-fc-26--pitch-notes---gameplay-deep-dive/12371925'
EA27 = 'https://www.ea.com/able/resources/ea-sports-fc/fc-27'
FACING = 'Forward/back/left/right refer to player facing. Set facing manually; Lab cannot observe the player or camera.'

# Concise factual control notation; no animation/timing claims are inferred.
REPORTED = {
    'Giant Fake Shot': (1, 'Hold L2 + fake shot (Square or Circle, then Cross)', 'Standing', 'giant-fake-shot'),
    'Stop And Go': (2, 'Hold L2; RS back, then forward', 'Ball on ground; additional constraints unverified', 'stop-and-go'),
    'Drag To Drag': (2, 'Hold L2; Square or Circle then Cross; hold RS back', 'Ball on ground; additional constraints unverified', 'drag-to-drag'),
    'Foot To Foot': (3, 'Hold L2 + fake shot + LS forward', 'Ball on ground; additional constraints unverified', 'foot-to-foot'),
    'Lateral Heel To Heel': (3, 'Hold L1; flick RS left then right, or right then left', 'Ball on ground; additional constraints unverified', 'lateral-heel-to-heel'),
    'Drag Turn': (4, 'Flick RS back, then left or right', 'Ball on ground; additional constraints unverified', 'drag-turn'),
    'Standing Scoop Turn': (4, 'Fake shot + LS direction', 'Standing', 'standing-scoop-turn'),
    'Flair Roulette': (4, 'Hold L1; rotate RS (arc endpoints unconfirmed)', 'Arc must be checked in game menu', 'flair-roulette'),
    'Four Touch Skill': (4, 'Hold L2; flick RS back twice', 'Ball on ground; additional constraints unverified', 'four-touch-skill'),
    'Skilled Bridge': (4, 'Hold L2; flick RS forward then back', 'Ball on ground; additional constraints unverified', 'skilled-bridge'),
    'First Time Spin': (5, 'Hold L1 + R1', 'Receiving ball on first touch', 'first-time-spin'),
    'Alternate Elastico Chop': (5, 'Hold L2 + R1; flick RS back then left or right', 'Ball on ground; additional constraints unverified', 'alternate-elastico-chop'),
    'Running Fake Drag': (5, 'Hold L2 + fake shot + LS forward', 'Running', 'running-fake-drag'),
}
BASIC = {
    'Directional Nutmeg': (1, 'Hold L1 + R1; RS direction', 'Ball on ground'),
    'Ball Juggle': (1, 'Hold L2; tap R1', 'Standing'),
    'Body Feint Left': (2, 'Flick RS left', 'Ball on ground'),
    'Body Feint Right': (2, 'Flick RS right', 'Ball on ground'),
    'Ball Roll Left': (2, 'Hold RS left', 'Ball on ground'),
    'Ball Roll Right': (2, 'Hold RS right', 'Ball on ground'),
    'Drag Back': (2, 'Hold L1 + R1; flick LS back', 'Ball on ground'),
    'Heel Flick': (3, 'Flick RS forward then back', 'Ball on ground'),
    'Ball Hop': (4, 'Hold L1; press R3', 'Standing'),
}
LEGACY = {
    'Explosive Stepover': (3, 'Hold L1; RS arc forward to left/right; LS exit', 'Standing or jogging'),
    'Advanced Heel Flick': (4, 'Flick RS forward then back; LS forward or diagonal forward', 'Jogging'),
    'Drag To Chop': (4, 'Hold L2; RS arc left-back-right or right-back-left', 'Standing'),
    'Elastico Variation': (5, 'Hold L2; RS arc right-back-left or left-back-right', 'Jogging'),
}

def reference(name):
    row = {'canonical_name': name, 'stars': None, 'game_status': 'uncertain',
           'ps5_input': None, 'direction_semantics': FACING,
           'context': 'Not established', 'playstyle_dependency': None,
           'verification': {'source': 'unverified', 'implementation': 'not checked', 'game': 'unverified'},
           'sources': [], 'reviewed_on': '2026-10-06',
           'notes': 'Historical name/alias; current FC27 membership and controls are not established. No sourced timing or PlayStyle requirement.'}
    if name in REPORTED:
        stars, controls, context, slug = REPORTED[name]
        row.update(stars=stars, ps5_input=controls, context=context, game_status='FC27 reported',
                   sources=['https://proclubshq.com/blog/fc27-how-to-'+slug+'/'])
    elif name in BASIC:
        stars, controls, context = BASIC[name]
        row.update(stars=stars, ps5_input=controls, context=context, game_status='FC27 reported', sources=[MENU])
    elif name in LEGACY:
        stars, controls, context = LEGACY[name]
        row.update(stars=stars, ps5_input=controls, context=context, game_status='legacy FC26; FC27 uncertain', sources=[EA26])
    if row['sources']:
        row['verification']['source'] = 'official legacy' if name in LEGACY else 'community menu report'
        row['notes'] = 'Controls documented by linked source; FC27 execution and millisecond timings unverified. Simplified Skill Moves in game can change RS behavior. No PlayStyle dependency established.'
    if name == 'Giant Fake Shot':
        row['notes'] += ' Community sources disagree: 1-star on dedicated move page versus 3-star wording on basic-controls page. Confirm current game menu.'
        row['game_status'] = 'uncertain: source conflict'
    return copy.deepcopy(row)
