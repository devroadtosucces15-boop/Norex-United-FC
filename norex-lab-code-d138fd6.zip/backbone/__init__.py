"""NOREX Controller Lab v2 backend contracts."""
