"""Gateway runs inside the Controller Center HTTP process."""
import sys, json, threading, secrets, time, urllib.request, urllib.parse
from pathlib import Path
GATEWAY=Path('/mnt/DEV_WORK/projects/norex-ps5-gateway')
sys.path.insert(0,str(GATEWAY))
from core import Monitor, public_ip
import livebox
from livebox import Live
CFG=livebox.CFG

def backend():
    cfg=CFG
    monitor=Monitor(cfg);token=secrets.token_urlsafe(32);busy=threading.Semaphore(2);jobs={}; job_lock=threading.Lock();enriched={}
    allowed_hosts={f'127.0.0.1:{cfg["port"]}',f'localhost:{cfg["port"]}'}
    allowed_origins={'http://'+h for h in allowed_hosts}
    def refresh():
        while not monitor.stop_event.wait(10):
            try:monitor.agent_state={'available':True,**monitor.rpc('health')}
            except Exception as e:monitor.agent_state={'available':False,'error':str(e)}
    threading.Thread(target=refresh,daemon=True).start()
    def enrichment(p):
        ip=public_ip(p.get('target',''))
        if ip in enriched:return enriched[ip]
        req=urllib.request.Request('https://ipwho.is/'+ip,headers={'User-Agent':'NorexPS5Gateway/1.0'})
        with urllib.request.urlopen(req,timeout=6) as response:
            if not response.geturl().startswith('https://'):raise ValueError('Insecure enrichment redirect')
            data=json.loads(response.read(65536))
        if not data.get('success'):raise ValueError(data.get('message','Enrichment unavailable'))
        out={k:data.get(k) for k in ['ip','country','region','city','latitude','longitude']};out['connection']=data.get('connection',{});out['caveat']='IP database estimate; provider/location do not prove physical server location or EA ownership.';enriched[ip]=out;monitor.event('enrichment',out);return out
    def action(name,p):
        if name=='remote_scan':return monitor.remote_scan(p)
        if name=='probe':return monitor.probe(p)
        if name=='trace':return monitor.trace(p)
        if name=='enrich':return enrichment(p)
        if name=='session':
            if p.get('stop'):monitor.event('session_flows',{'session':monitor.session,'flows':monitor.status()['flows']})
            return monitor.session_action(p)
        if name=='nat_record':
            value=p.get('type')
            if value not in ['1','2','3','unknown']:raise ValueError('NAT type must be 1, 2, 3, or unknown')
            result={'type':value,'source':'Manually recorded PS5 connection test','time':time.time()};monitor.event('nat_test',result);return result
        if name=='capture_start':return monitor.capture_start(p)
        if name=='capture_stop':return monitor.capture_stop()
        if name in ['qos','qos_off','emulate','vpn','vpn_off','confirm','recover','forwarding']:return monitor.rpc(name,p)
        raise ValueError('Unknown action')
    def perform(job,name,p):
        try:
            result=action(name,p);jobs[job]={'state':'done','result':result};monitor.event(name,result)
        except Exception as e:jobs[job]={'state':'error','error':str(e)};monitor.log(name+': '+str(e))
        finally:busy.release()
    return monitor,jobs,action,perform,busy

class Network(Live):
    def __init__(self):
        self.monitor,self.jobs,self.action,self.perform,self.busy=backend()
        self.jobs_lock=threading.RLock()
        super().__init__()
    def connect(self):self.client=True
    def get(self,path):
        if path=='/api/status':return self.monitor.status()
        if path=='/api/history':return self.monitor.history()
        if path=='/api/jobs':
            with self.jobs_lock:return dict(self.jobs)
        if path=='/api/captures':return [{'name':p.name,'bytes':p.stat().st_size} for p in (Path(CFG['data'])/'captures').glob('*.pcapng')]
        raise ValueError('Unknown network view')
    def api_action(self,action,params):
        if not self.busy.acquire(blocking=False):raise ValueError('Two checks are already running. Try again shortly.')
        job=secrets.token_hex(8)
        with self.jobs_lock:
            for key in list(self.jobs):
                if len(self.jobs)<=100:break
                if self.jobs[key]['state']!='running':self.jobs.pop(key)
            self.jobs[job]={'state':'running','action':action}
        threading.Thread(target=self.perform,args=(job,action,params),daemon=True).start()
        return {'job':job}
    def close(self):
        self.automation.close()
        self.monitor.shutdown()

def serve(handler):
    path=handler.path.split('?',1)[0];network=handler.server.network
    if path=='/network':
        page=(Path(__file__).parent/'network/livebox.html').read_bytes().replace(b'__TOKEN__',handler.server.network_token.encode())
        handler.reply(page,kind='text/html; charset=utf-8');return True
    assets={'/livebox.js','/livebox.css','/play.js','/gateway.js','/surface.js','/scrollcraft.css','/norex-crest.png','/inter.ttf','/oswald.ttf','/help.css'}
    if path in assets:
        kind='text/javascript' if path.endswith('.js') else 'text/css' if path.endswith('.css') else 'image/png' if path.endswith('.png') else 'font/ttf'
        handler.reply((Path(__file__).parent/'network'/path[1:]).read_bytes(),kind=kind);return True
    views={'/api/live':network.snapshot,'/api/automation':network.automation.snapshot,'/api/events':network.events_snapshot,'/api/experience':network.experience_snapshot,'/api/storage':lambda:livebox.storage_summary(CFG)}
    if path in views:handler.reply(views[path]());return True
    if path.startswith('/api/gateway/api/'):
        try:handler.reply(network.get(path[len('/api/gateway'):]))
        except ValueError as e:handler.reply({'error':str(e)},404)
        return True
    if path.startswith('/gateway/capture/'):
        import re
        name=path.rsplit('/',1)[-1]
        if not re.fullmatch(r'ps5-[A-Za-z0-9-]+\.pcapng',name):handler.reply({'error':'Invalid recording'},400);return True
        p=Path(CFG['data'])/'captures'/name
        if not p.is_file() or p.stat().st_size>64*1024*1024:handler.reply({'error':'Recording unavailable'},404);return True
        handler.reply(p.read_bytes(),kind='application/octet-stream');return True
    return False

def post(handler):
    path=handler.path
    if path not in ('/api/automation','/api/preset','/api/play','/api/gateway/action'):return False
    import hmac
    if not handler.allowed() or handler.headers.get('Origin')!='http://'+handler.headers.get('Host','') or not hmac.compare_digest(handler.headers.get('X-CSRF-Token',''),handler.server.network_token):handler.reply({'error':'Reload this page to reconnect'},403);return True
    try:
        size=int(handler.headers.get('Content-Length','0'))
        if not 0<size<=8192:raise ValueError('Settings are too large')
        data=json.loads(handler.rfile.read(size))
        if not isinstance(data,dict):raise ValueError('Expected settings')
        n=handler.server.network
        with n.automation.operation_lock:
            result=n.gateway_action(data) if path=='/api/gateway/action' else n.experience_action(data) if path=='/api/play' else n.automation.preset(data.get('name'),data.get('enabled')) if path=='/api/preset' else n.automation.update(dict(n.automation.settings,**data))
        handler.reply(result)
    except (ValueError,KeyError,TypeError,OSError) as e:handler.reply({'error':str(e)},400)
    return True
