import unittest
from pipeline import neutral_frame
from backbone.engine import BackboneEngine
class EngineTests(unittest.TestCase):
 def setUp(self):
  f=neutral_frame();self.a=f.axes;self.b=f.buttons;self.e=BackboneEngine()
 def test_raw_is_exact_bypass(self):
  self.a['LX']=.371;self.b['Cross']=True
  self.e.set_mode('RAW');a,b,m=self.e.process(self.a,self.b,{'precision_stick':{'enabled':True,'strength':100}},1)
  self.assertEqual(a,self.a);self.assertEqual(b,self.b);self.assertEqual(m['trace'],[])
 def test_helpers_never_generate_buttons(self):
  self.a['LX']=.5;self.b['R1']=True
  cfg={'controlled_dribble_response':{'enabled':True,'strength':100}}
  a,b,m=self.e.process(self.a,self.b,cfg,1);self.assertLess(a['LX'],.5);self.assertEqual(b,self.b)
 def test_sprint_can_shape_without_claiming_speed(self):
  self.a.update(LX=.5,R2=1);a,_,m=self.e.process(self.a,self.b,{'sprint_response':{'enabled':True,'strength':100}},1)
  self.assertGreater(a['LX'],.5);self.assertIn('sprint_response',m['trace'])
 def test_bounds(self):
  self.a.update(LX=1,LY=1)
  a,_,_=self.e.process(self.a,self.b,{'outer_response':{'enabled':True,'strength':100}},1)
  self.assertTrue(all(-1<=a[k]<=1 for k in ('LX','LY')))
if __name__=='__main__':unittest.main()
