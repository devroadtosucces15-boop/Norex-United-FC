import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import master_portal as portal

class PortalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.original=copy.deepcopy(portal.data);self.addCleanup(lambda:portal.data.clear() or portal.data.update(self.original))
        self.state=patch.object(portal,'STATE',Path(self.temp.name)/'state.json');self.state.start();self.addCleanup(self.state.stop)
        portal.data.update(cache={},errors={},revision=0,network_saved=None)
    def test_duplicate_on_does_not_restart(self):
        with patch.object(portal,'active',return_value=True),patch.object(portal,'unit') as unit:
            portal.power('network',True);portal.power('network',True)
            unit.assert_not_called()
    def test_failed_on_stops_started_service(self):
        with patch.object(portal,'active',return_value=False),patch.object(portal,'ready',side_effect=ValueError('not ready')),patch.object(portal,'unit') as unit:
            with self.assertRaisesRegex(ValueError,'not ready'):portal.power('controller',True)
            self.assertEqual(unit.call_args_list,[unittest.mock.call('controller','start'),unittest.mock.call('controller','stop')])
            self.assertIn('not ready',portal.data['errors']['controller'])
    def test_failed_off_still_stops_owned_service(self):
        with patch.object(portal,'active',return_value=True),patch.object(portal,'call',return_value=(json.dumps({'error':'reset failed'}).encode(),400)),patch.object(portal,'unit') as unit:
            with self.assertRaisesRegex(ValueError,'reset failed'):portal.power('controller',False)
            unit.assert_called_once_with('controller','stop')
    def test_crashed_controller_cannot_report_on(self):
        portal.data['cache']['/api/state']={'master_enabled':True,'chiaki_running':True}
        portal.data['off_cache']={'/api/state':{'master_enabled':False}}
        with patch.object(portal,'active',return_value=False):s=portal.snapshot()
        self.assertFalse(s['controller']);self.assertFalse(portal.data['cache']['/api/state']['master_enabled'])
        self.assertIn('stopped',s['errors']['controller'])
    def test_off_retains_saved_network_preferences(self):
        portal.data['network_saved']={'download_mbps':123}
        portal.data['cache']['/api/automation']={'settings':{'download_mbps':123}}
        portal.mark_off('network')
        self.assertEqual(portal.data['cache']['/api/automation']['settings'],portal.DEFAULT)
        self.assertEqual(portal.data['network_saved']['download_mbps'],123)
