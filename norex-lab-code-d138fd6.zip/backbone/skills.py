"""Canonical user-authored local recipes. Source facts never become timing code."""
from copy import deepcopy
from .fc27_data import SKILL_BY_ID
from pipeline import AXES,BUTTONS,number


def defaults():return {'recipes':{},'bindings':[]}

def validate_recipe(skill_id,row):
    if skill_id not in SKILL_BY_ID:raise ValueError('Unknown canonical skill')
    if SKILL_BY_ID[skill_id]['input_status'] in ('TBA','AMBIGUOUS'):
        raise ValueError('TBA or ambiguous source inputs cannot be executable')
    if not isinstance(row,dict) or set(row)!={'relative','steps'} or type(row['relative']) is not bool:
        raise ValueError('Recipe requires relative and steps')
    steps=row['steps']
    if not isinstance(steps,list) or not 1<=len(steps)<=128:raise ValueError('Recipe needs 1–128 steps')
    total=0
    for step in steps:
        if not isinstance(step,dict) or set(step)!={'ms','axes','buttons'}:raise ValueError('Invalid recipe step')
        number(step['ms'],5,2000);total+=step['ms']
        if not isinstance(step['axes'],dict) or not isinstance(step['buttons'],dict):raise ValueError('Invalid recipe frame')
        for key,value in step['axes'].items():
            if key not in AXES.values():raise ValueError('Unknown recipe axis')
            number(value,0 if key in ('L2','R2') else -1,1)
        if any(k not in BUTTONS.values() or type(v) is not bool for k,v in step['buttons'].items()):raise ValueError('Invalid recipe button')
    if total>10000:raise ValueError('Recipe cannot exceed 10 seconds')
    return deepcopy(row)

def validate_config(value):
    if not isinstance(value,dict) or set(value)!={'recipes','bindings'}:raise ValueError('Invalid canonical skill configuration')
    if not isinstance(value['recipes'],dict) or len(value['recipes'])>len(SKILL_BY_ID):raise ValueError('Invalid canonical recipes')
    recipes={key:validate_recipe(key,row) for key,row in value['recipes'].items()}
    from play_tools import CHORDS
    rows=value['bindings']
    if not isinstance(rows,list) or len(rows)>len(CHORDS):raise ValueError('Too many canonical bindings')
    used=set()
    for row in rows:
        if not isinstance(row,dict) or set(row)!={'trigger','skill'} or row['trigger'] not in CHORDS or row['skill'] not in recipes:
            raise ValueError('Binding requires a configured canonical recipe')
        if row['trigger'] in used:raise ValueError('Canonical triggers must be unique')
        used.add(row['trigger'])
    return {'recipes':recipes,'bindings':deepcopy(rows)}

def validate_bindings(profile,mode_bank=None):
    from play_tools import occupied
    reserved={row['trigger'] for row in profile['play_tools']['skill_bindings']}
    if mode_bank is not None and mode_bank.enabled:
        reserved|={f"{r['trigger']} + D-pad {r['direction']}" for r in mode_bank.bindings.values() if r['trigger']!='both'}
        for r in mode_bank.bindings.values():
            if r['trigger']=='both':reserved|={f'{m} + D-pad {r["direction"]}' for m in ('L2','R2')}
    blocked=occupied(profile)
    for row in profile['backbone_skills']['bindings']:
        if row['trigger'] in reserved or row['trigger'].split(' + ')[0] in blocked:
            raise ValueError('Canonical binding conflicts with a legacy shortcut or mode hotkey: '+row['trigger'])

def catalog_rows(config,**filters):
    from .fc27_data import search_skills
    rows=search_skills(**filters)
    for row in rows:
        recipe=config['recipes'].get(row['id'])
        row['recipe']=deepcopy(recipe)
        row['executable']=recipe is not None
        row['recipe_status']='User-authored local recipe; game unverified' if recipe else 'Recipe not configured'
        row['shortcut']=[b['trigger'] for b in config['bindings'] if b['skill']==row['id']]
        row['verification']['implementation']='validated local recipe' if recipe else 'not_tested'
    return rows
