import math,unittest
from assists import AssistEngine,defaults,validate
from pipeline import neutral_frame

class SkillOrientationTests(unittest.TestCase):
 def setUp(self):
  self.e=AssistEngine();self.c=defaults();self.frame=neutral_frame()
  self.steps=[{'ms':150,'axes':{'RX':0,'RY':-1},'buttons':{}}]
 def start(self,relative=True):
  self.e.start_recipe('orientation',self.steps,1_000_000_000,config=self.c,relative=relative)
 def output(self,physical=None):
  return self.e.apply(self.frame.axes,self.frame.buttons,self.c,1_010_000_000,{},physical_axes=physical or self.frame.axes)[0]
 def test_all_eight_directions(self):
  for angle in range(0,360,45):
   with self.subTest(angle=angle):
    self.e.reset();x=math.cos(math.radians(angle));y=math.sin(math.radians(angle))
    self.e.observe_movement({'LX':x,'LY':y});self.start();a=self.output()
    self.assertAlmostEqual(a['RX'],x);self.assertAlmostEqual(a['RY'],y)
 def test_capture_freezes_and_tracks_next_direction(self):
  self.e.observe_movement({'LX':0,'LY':-1});self.start()
  self.c['facing_angle']=180
  a=self.output({'LX':-1,'LY':0})
  self.assertAlmostEqual(a['RX'],0);self.assertAlmostEqual(a['RY'],-1)
  status=self.e.orientation_status(self.c)
  self.assertEqual(status['angle'],270);self.assertEqual(status['last_movement_angle'],180)
  self.assertTrue(status['captured'])
 def test_release_and_drift_retain_history(self):
  self.e.observe_movement({'LX':1,'LY':0})
  for axes in ({'LX':0,'LY':0},{'LX':0,'LY':-.14}):self.e.observe_movement(axes)
  self.start();self.assertAlmostEqual(self.output()['RX'],1)
 def test_manual_fallback(self):
  self.c['facing_angle']=180;self.start()
  self.assertAlmostEqual(self.output()['RX'],-1)
  self.assertEqual(self.e.orientation_status(self.c)['source'],'manual_fallback')
 def test_fixed_mode_ignores_stick(self):
  self.c.update(skill_direction_mode='fixed',facing_angle=90)
  self.e.observe_movement({'LX':1,'LY':0});self.start()
  self.assertAlmostEqual(self.output()['RY'],1)
  self.assertEqual(self.e.orientation_status(self.c)['source'],'manual')
 def test_absolute_recipe_keeps_screen_coordinates(self):
  self.e.observe_movement({'LX':1,'LY':0});self.start(False)
  a=self.output();self.assertEqual(a['RX'],0);self.assertEqual(a['RY'],-1)
  self.assertEqual(self.e.orientation_status(self.c)['source'],'screen_fixed')
 def test_both_sticks_rotate_but_generated_axes_do_not_update_history(self):
  self.steps[0]['axes'].update(LX=0,LY=-1)
  self.e.observe_movement({'LX':1,'LY':0});self.start();a=self.output()
  self.assertAlmostEqual(a['LX'],1);self.assertAlmostEqual(a['LY'],0)
  self.assertEqual(self.e.movement_angle,0)
 def test_old_configuration_defaults_to_movement(self):
  old=defaults();old.pop('skill_direction_mode')
  self.assertEqual(validate(old)['skill_direction_mode'],'movement')
 def test_invalid_direction_mode_rejected(self):
  self.c['skill_direction_mode']='arbitrary'
  with self.assertRaises(ValueError):validate(self.c)

if __name__=='__main__':unittest.main()
