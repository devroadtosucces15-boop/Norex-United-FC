"""Compare the complete live snapshot against its named saved document."""
import json
from profile_store import snapshot,migrate

def save_status(runtime):
    path=runtime.data/('profile-'+runtime.profile['name']+'.json')
    try:
        saved=migrate(json.loads(path.read_text()))
        if 'snapshot_schema' not in saved:return {'state':'legacy','complete':False}
        live=snapshot(runtime,runtime.profile)
        keys=('profile','skill_recipes','mode_bank','selection','scope','snapshot_schema')
        return {'state':'saved' if all(live[k]==saved.get(k) for k in keys) else 'modified','complete':True,'saved_at':saved['saved_at']}
    except (OSError,ValueError,KeyError):return {'state':'unavailable','complete':False}
