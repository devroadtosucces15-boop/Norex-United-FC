"""Bounded complete-frame recording and strictly validated replay source."""
import json
import time
from pathlib import Path
from pipeline import validate_profile, validate_frame, neutral_frame

MAX_BYTES=20*1024*1024
MAX_NS=600_000_000_000

class FrameRecorder:
    def __init__(self,path,profile,device):
        self.file=Path(path).open('x'); self.bytes=0; self.frames=0; self.origin=time.monotonic_ns(); self.last=0
        self.write({'kind':'header','schema':2,'clock':'relative monotonic ns','profile':profile,'device':device,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'purpose':'local/single-player only','transformed':True})
        self.write(neutral_frame().to_dict())
    def write(self,row):
        line=json.dumps(row,separators=(',',':'))+'\n'
        if self.bytes+len(line)>MAX_BYTES-2048: raise ValueError('20 MiB recording limit reached')
        self.file.write(line); self.bytes+=len(line)
    def frame(self,frame):
        elapsed=time.monotonic_ns()-self.origin
        if elapsed>MAX_NS: raise ValueError('10-minute recording limit reached')
        self.last=max(self.last+1,elapsed); row=frame.to_dict(); row['t_ns']=self.last; row['sequence']=self.frames+1; self.write(row); self.frames+=1
    def finish(self,reason='stopped'):
        if self.file.closed: return
        # Reserved tail room guarantees neutral final state and closure marker.
        t=min(MAX_NS,max(self.last+1,time.monotonic_ns()-self.origin))
        line=json.dumps(neutral_frame(t,sequence=self.frames+1).to_dict())+'\n'
        self.file.write(line); self.file.write(json.dumps({'kind':'end','reason':reason,'frames':self.frames,'t_ns':t})+'\n'); self.file.flush(); self.file.close()

class ReplaySource:
    def __init__(self,path):
        p=Path(path)
        if p.stat().st_size>MAX_BYTES: raise ValueError('Replay exceeds 20 MiB')
        with p.open() as f:
            rows=[]
            for i,line in enumerate(f):
                if len(line)>(262144 if i==0 else 8192) or i>50000: raise ValueError('Replay exceeds frame/line limits')
                rows.append(json.loads(line))
        if not rows or not isinstance(rows[0],dict) or rows[0].get('kind')!='header' or rows[0].get('schema')!=2 or rows[0].get('clock')!='relative monotonic ns' or rows[0].get('transformed') is not True: raise ValueError('Only schema-2 complete-frame recordings can replay')
        self.profile=validate_profile(rows[0]['profile']); self.frames=[]; ended=False; previous=-1
        for row in rows[1:]:
            if not isinstance(row,dict): raise ValueError('Invalid recording row')
            if ended: raise ValueError('Data after end marker')
            if row.get('kind')=='end':
                if not isinstance(row.get('reason'),str) or row.get('t_ns')!=previous: raise ValueError('Invalid end marker')
                ended=True; continue
            frame=validate_frame(row)
            if frame.t_ns<previous: raise ValueError('Replay timestamps are not monotonic')
            previous=frame.t_ns; self.frames.append(frame)
        if not ended or len(self.frames)<2: raise ValueError('Incomplete recording; replay rejected')
        for f in (self.frames[0],self.frames[-1]):
            if any(f.axes.values()) or any(f.buttons.values()): raise ValueError('Replay must start and end neutral')
        self.duration_ns=self.frames[-1].t_ns
