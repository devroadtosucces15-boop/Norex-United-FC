import unittest
from backbone.helper_contract import HELPERS,CATEGORIES
class HelperContracts(unittest.TestCase):
 def test_every_helper_teaches_and_bounds_parameters(self):
  self.assertGreaterEqual(len(HELPERS),10)
  for key,h in HELPERS.items():
   self.assertIn(h['category'],CATEGORIES);self.assertEqual(h['id'],key)
   for field in ('what_it_does','inputs','does_not_change','example','downside','conflicts','learn_more','guided_test','parameters'):self.assertIn(field,h)
   for p in h['parameters'].values():
    self.assertLessEqual(p['min'],p['default']);self.assertLessEqual(p['default'],p['max'])
    self.assertIn('lower_means',p);self.assertIn('higher_means',p);self.assertIn('higher_is_better',p)
 def test_no_attribute_boost_claims(self):
  text=str(HELPERS)
  self.assertNotIn('+20% Shot Power',text)
if __name__=='__main__':unittest.main()
