#!/usr/bin/env python3
"""Emit touchpad-only SDL mappings for attached physical DualSense controllers.

The virtual Lab mapping remains responsible for every ordinary gamepad input.
Use the same SDL library as Chiaki so HIDAPI identities and button indexes agree.
"""
import ctypes as c
from pathlib import Path

SDL_PATH = '/mnt/DEV_WORK/tools/chiaki-ng/squashfs-root/usr/lib/libSDL2-2.0.so.0'

def touchpad_only(mapping):
    parts = mapping.split(',')
    if len(parts) < 3: raise ValueError('Invalid SDL controller mapping')
    fields = [p for p in parts[2:] if p.startswith(('touchpad:', 'platform:', 'crc:'))]
    if not any(p.startswith('touchpad:') for p in fields):
        raise ValueError('DualSense native touchpad button is unavailable; check hidraw access')
    return ','.join([parts[0], 'NOREX DualSense Touchpad Only', *fields, ''])

def mappings():
    s = c.CDLL(SDL_PATH)
    s.SDL_Init.argtypes = [c.c_uint]
    s.SDL_GetError.restype = c.c_char_p
    s.SDL_GameControllerOpen.argtypes = [c.c_int]; s.SDL_GameControllerOpen.restype = c.c_void_p
    s.SDL_GameControllerClose.argtypes = [c.c_void_p]
    s.SDL_GameControllerGetVendor.argtypes = [c.c_void_p]; s.SDL_GameControllerGetVendor.restype = c.c_uint16
    s.SDL_GameControllerGetProduct.argtypes = [c.c_void_p]; s.SDL_GameControllerGetProduct.restype = c.c_uint16
    s.SDL_GameControllerMapping.argtypes = [c.c_void_p]; s.SDL_GameControllerMapping.restype = c.c_void_p
    s.SDL_GameControllerGetNumTouchpads.argtypes = [c.c_void_p]
    s.SDL_free.argtypes = [c.c_void_p]
    if s.SDL_Init(0x2000 | 0x200) != 0: raise RuntimeError(s.SDL_GetError().decode())
    result = []
    try:
        for i in range(s.SDL_NumJoysticks()):
            if not s.SDL_IsGameController(i): continue
            g = s.SDL_GameControllerOpen(i)
            if not g: continue
            try:
                if (s.SDL_GameControllerGetVendor(g), s.SDL_GameControllerGetProduct(g)) != (0x054c, 0x0ce6): continue
                if s.SDL_GameControllerGetNumTouchpads(g) < 1:
                    raise RuntimeError('DualSense native touchpad is unavailable; check hidraw access')
                ptr = s.SDL_GameControllerMapping(g)
                if not ptr: raise RuntimeError('DualSense SDL mapping unavailable')
                try: result.append(touchpad_only(c.string_at(ptr).decode()))
                finally: s.SDL_free(ptr)
            finally: s.SDL_GameControllerClose(g)
    finally: s.SDL_Quit()
    return list(dict.fromkeys(result))

if __name__ == '__main__':
    print('\n'.join(mappings()))
