"""Read-only skill membership and evidence from the two user-approved videos.

This module never compiles video captions into executable controller recipes.
"""
import copy,json,re
from functools import lru_cache
from pathlib import Path

def norm(name):
    return re.sub('[^a-z0-9]','',name.lower().replace('&','and'))

@lru_cache(maxsize=1)
def document():
    return json.loads(Path(__file__).with_name('ui').joinpath('fc27-approved-videos.json').read_text())

# Spelling/label differences visible between the approved description and footage.
ALIASES={'balljuggle':'balljuggling','scissorsfeints':'scissorsfeint',
         'elastico variation':'elastico variations','alternateelasticochop':'alternativeelasticochop',
         'okochasombreroflick':'okochasombrero','doublearoundtheworld':'2xaroundtheworld',
         'touzani around the world':'t around the world','thighcatchrainbow':'tighcatchrainbow','180degreesombrero':'180sombrero',
         'jugglingrainbowflick':'jugglingrainbow','jugglingsombreroflick':'jugglingsombrero',
         'scissorfeint':'scissorsfeint','vdragmove':'vdrag','feintforwardturn':'feintforwardandturn',
         'feintfwdturn':'feintforwardandturn','flairnutmegs':'flairnutmeg'}
ALIASES={norm(k):norm(v) for k,v in ALIASES.items()}

def key(name):
    n=norm(name)
    return ALIASES.get(n,n)

def video_names():
    return sorted({r['name'] for r in document()['observations']}|{r['name'] for r in document()['published_entries']})

def reference(name):
    d=document();k=key(name)
    obs=[r for r in d['observations'] if key(r['name'])==k]
    published=[r for r in d['published_entries'] if key(r['name'])==k]
    fc27=bool(obs) or any(r['video_id']=='AFjd0Y29HAc' for r in published)
    sources=list(dict.fromkeys([r['source_url'] for r in obs]+[d['sources'][r['video_id']]['url'] for r in published]))
    stars={r['stars'] for r in obs if r['stars'] is not None}
    inputs=list(dict.fromkeys(r['screen_notation'] for r in obs if r['screen_notation']))
    deps={r['playstyle_dependency'] for r in obs if r['playstyle_dependency']}
    notes=['Only the two user-approved YouTube videos support membership. Measured controller-animation timing is kept separate from unverified game-execution timing; recipe provenance identifies the playback source.']
    if len(stars)>1 or len(deps)>1 or (deps and stars):notes.append('Source requirement conflict or context variants: keep the linked observations separate.')
    notes.extend(dict.fromkeys(r['notes'] for r in obs if r['notes']))
    if published and not obs:notes.append('Name appears in the published description; on-screen input has not been transcribed.')
    return {'canonical_name':name,'stars':next(iter(stars)) if len(stars)==1 and not deps else None,
            'game_status':'FC27 video reference; game unverified' if fc27 else 'FC26 video reference; FC27 not established' if published else 'Historical/custom slot; not established by supplied videos',
            'ps5_input':' / '.join(inputs) if inputs else ('See linked video; exact input not transcribed' if sources else None),
            'direction_semantics':'Screen-relative notation; FC27 tutorial faces right. Physical player facing is not game telemetry.',
            'context':'See source chapter and individual observations','playstyle_dependency':next(iter(deps)) if len(deps)==1 and not stars else None,
            'verification':{'source':'video samples' if obs else 'video description' if published else 'unverified','implementation':'not checked','game':'unverified'},
            'sources':sources,'reviewed_on':'2026-10-16','notes':' '.join(notes),
            'video_evidence':copy.deepcopy(obs),'video_match_key':k,'video_aliases':sorted({r['name'] for r in obs+published}),
            'video_membership':'FC27' if fc27 else 'FC26 only' if published else 'not established'}
