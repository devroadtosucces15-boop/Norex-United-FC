"""User-made skill lists: map one trigger to a list and each press plays one move from it.

A list is bound like a skill under the name 'List: <name>'. The pick happens when the trigger fires, so
the lists can be edited without touching saved profiles. Lists are local data only (data/skill-lists.json).
"""
import json,random,re
from profile_store import write_atomic

PREFIX='List: '
MODES=('random','shuffle','order')
MAX_LISTS=20
MAX_MEMBERS=200
LISTS={}      # 'List: X' -> {'members': [...], 'mode': ...}
_state={}     # per-list pick memory (not saved)

def is_list(name):
    return isinstance(name,str) and name.startswith(PREFIX) and 0<len(name)-len(PREFIX)<=40

def _path(data):return data/'skill-lists.json'

def _clean_name(name):
    name=re.sub(r'\s+',' ',str(name or '')).strip()
    if not 1<=len(name)<=40 or not re.fullmatch(r"[A-Za-z0-9 _+&.'-]+",name):raise ValueError('List name: 1–40 letters, numbers or spaces')
    return name

def read(data):
    p=_path(data)
    if not p.exists():return {'lists':[]}
    row=json.loads(p.read_text())
    if not isinstance(row,dict) or not isinstance(row.get('lists'),list):raise ValueError('Invalid skill lists file')
    return {'lists':row['lists']}

def load(data):
    """Refresh the in-memory copy; a damaged file never stops the Lab, it just leaves lists empty."""
    LISTS.clear();_state.clear()
    try:rows=read(data)['lists']
    except Exception:return
    for r in rows:
        try:LISTS[PREFIX+_clean_name(r['name'])]={'members':list(r['members']),'mode':r['mode'] if r['mode'] in MODES else 'random'}
        except Exception:continue

def snapshot():
    return [{'name':k[len(PREFIX):],'members':list(v['members']),'mode':v['mode']} for k,v in sorted(LISTS.items())]

def save(data,name,members,mode,old_name=None):
    from skills import CATALOG
    name=_clean_name(name)
    if mode not in MODES:raise ValueError('Mode must be random, shuffle or order')
    if not isinstance(members,list) or not 1<=len(members)<=MAX_MEMBERS:raise ValueError('A list needs 1–%d moves'%MAX_MEMBERS)
    if len(set(members))!=len(members) or any(m not in CATALOG for m in members):raise ValueError('List members must be distinct, known moves')
    rows={r['name']:r for r in read(data)['lists']}
    if old_name and old_name!=name:
        if name in rows:raise ValueError('A list with that name already exists')
        rows.pop(old_name,None)
    elif name not in rows and len(rows)>=MAX_LISTS:raise ValueError('At most %d lists'%MAX_LISTS)
    rows[name]={'name':name,'members':list(members),'mode':mode}
    write_atomic(_path(data),{'lists':sorted(rows.values(),key=lambda r:r['name'])})
    load(data);return {'lists':snapshot()}

def delete(data,name):
    rows={r['name']:r for r in read(data)['lists']}
    rows.pop(name,None)
    write_atomic(_path(data),{'lists':sorted(rows.values(),key=lambda r:r['name'])})
    load(data);return {'lists':snapshot()}

def ready_members(list_name,ready):
    return [m for m in LISTS.get(list_name,{}).get('members',[]) if m in ready]

def _draw(list_name,pool,st,rng):
    """Choose the next move in this list's pattern (does not play it)."""
    mode=LISTS[list_name]['mode']
    if mode=='order':
        m=pool[st['i']%len(pool)];st['i']+=1
    elif mode=='shuffle':
        st['bag']=[m for m in st['bag'] if m in pool]
        if not st['bag']:
            st['bag']=pool[:];rng.shuffle(st['bag'])
            if len(pool)>1 and st['bag'][-1]==st['last']:st['bag'][0],st['bag'][-1]=st['bag'][-1],st['bag'][0]  # no repeat across rounds
        m=st['bag'].pop()
    else:
        options=[x for x in pool if x!=st['last']] or pool
        m=rng.choice(options)
    return m

def upcoming(list_name,ready,rng=random):
    """The move the next press of this list will play, so the screen can show it in advance."""
    pool=ready_members(list_name,ready)
    if not pool:return None
    st=_state.setdefault(list_name,{'last':None,'bag':[],'i':0,'next':None})
    if st.get('next') not in pool:st['next']=_draw(list_name,pool,st,rng)
    return st['next']

def pick(list_name,ready,rng=random):
    """The move to play for this press, or None when the list is empty or none of its moves has a recipe."""
    m=upcoming(list_name,ready,rng)
    if m is None:return None
    st=_state[list_name];st['last']=m;pool=ready_members(list_name,ready)
    st['next']=_draw(list_name,pool,st,rng)
    return m
