import tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import lab
from output_backend import OutputBackend, delivery_test_frame
from pipeline import neutral_frame

class FakeBackend(OutputBackend):
    backend_id='fake'; destination='test receiver'; transport='memory'
    def __init__(self): self.sent=[]; self.closed=False; self.fail=False
    def emit(self,frame):
        if self.fail: raise OSError('write failed')
        self.sent.append(frame)
    def neutralize(self): self.sent.append(neutral_frame())
    def close(self):
        if not self.closed: self.neutralize(); self.closed=True

class BackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        with patch.object(lab,'DATA',Path(self.tmp.name)): self.lab=lab.Lab()
        self.lab.status='Connected'; self.sink=FakeBackend(); self.lab.output_factory=lambda:self.sink
    def start(self): self.lab.runtime_action({'action':'delivery_test_start','local_only':True})
    def test_backend_lifecycle_and_status(self):
        self.lab.new_output('physical'); self.lab.emit_output(neutral_frame())
        state=self.lab.runtime_state()['output']
        self.assertEqual(state['destination'],'test receiver'); self.assertEqual(state['game_receipt'],'unverified')
        with self.assertRaises(ValueError): self.lab.new_output('physical')
        self.lab.close_output(); self.lab.close_output(); self.assertTrue(self.sink.closed)
        self.assertFalse(any(self.sink.sent[-1].buttons.values()))
        self.assertFalse(self.lab.runtime_state()['output']['transport_connected'])
    def test_output_failure_closes_and_disarms(self):
        self.lab.new_output('physical'); self.lab.assists_armed=True; self.sink.fail=True
        self.lab.emit_output(neutral_frame())
        self.assertIsNone(self.lab.output); self.assertFalse(self.lab.assists_armed); self.assertTrue(self.sink.closed)
        self.assertEqual(self.lab.output_error,'write failed')
    def test_test_requires_confirmation_and_exclusion(self):
        with self.assertRaises(ValueError): self.lab.runtime_action({'action':'delivery_test_start'})
        self.lab.new_output('physical')
        with self.assertRaises(ValueError): self.start()
    def test_manual_swap_neutral_other_controls(self):
        frame=delivery_test_frame({'LX':1},{'Cross':True,'Circle':True,'PS':True},123,4)
        self.assertTrue(frame.buttons['Square']); self.assertFalse(frame.buttons['Cross'])
        self.assertFalse(frame.buttons['Circle']); self.assertFalse(frame.buttons['PS']); self.assertFalse(any(frame.axes.values()))
        released=delivery_test_frame({}, {},124,5); self.assertFalse(any(released.buttons.values()))
    def test_test_bypasses_assists_profile_and_never_persists(self):
        before=self.lab.profile.copy(); self.lab.assists_armed=True; self.start()
        self.assertFalse(self.lab.assists_armed); self.assertEqual(before,self.lab.profile)
        self.lab.buttons={'Cross':True}; self.lab.on_frame()
        self.assertTrue(self.sink.sent[-1].buttons['Square']); self.assertFalse(self.sink.sent[-1].buttons['Cross'])
        with self.assertRaises(ValueError): self.lab.runtime_action({'action':'arm_assists','local_only':True})
        self.lab.runtime_action({'action':'emergency_stop'}); self.assertTrue(self.sink.closed); self.assertEqual(self.lab.delivery_test_until,0)
    def test_expiration_disconnect_and_initial_neutral(self):
        self.start(); self.assertFalse(any(self.sink.sent[-1].buttons.values()))
        self.lab.delivery_test_until=1; self.lab.on_frame(); self.assertIsNone(self.lab.output)
        self.sink=FakeBackend(); self.start(); self.lab.disconnect_runtime('unplugged')
        self.assertTrue(self.sink.closed); self.assertFalse(self.lab.runtime_state()['delivery_test']['active'])
    def test_open_failure_keeps_output_inactive(self):
        def fail(): raise OSError('permission')
        self.lab.output_factory=fail
        with self.assertRaises(ValueError): self.start()
        self.assertIsNone(self.lab.output); self.assertEqual(self.lab.delivery_test_until,0)

class IdleExpiryTests(unittest.TestCase):
    setUp=BackendTests.setUp
    start=BackendTests.start
    def test_idle_deadline(self):
        self.start(); deadline=self.lab.delivery_test_until
        self.lab.expire_delivery_test(deadline-1); self.assertIsNotNone(self.lab.output)
        self.lab.expire_delivery_test(deadline); self.assertIsNone(self.lab.output)
    def test_cleanup_error_still_clears_state(self):
        self.start()
        self.sink.close=lambda: (_ for _ in ()).throw(OSError('cleanup failed'))
        self.lab.close_output(); self.assertIsNone(self.lab.output)
        self.assertEqual(self.lab.output_error,'cleanup failed')

class HelperSwitchTests(BackendTests):
    def test_jockey_off_releases_both_trigger_channels_without_disconnect(self):
        self.lab.profile['assists']['auto_jockey']=True
        self.lab.new_output('physical'); self.lab.arm_current(); self.lab.on_frame()
        self.assertEqual(self.sink.sent[-1].axes['L2'],1)
        self.assertFalse(self.sink.sent[-1].buttons['L2 button'])
        self.lab.runtime_action({'action':'set_assist_enabled','key':'auto_jockey','enabled':False})
        self.assertEqual(self.sink.sent[-1].axes['L2'],0)
        self.assertFalse(self.sink.sent[-1].buttons['L2 button'])
        self.assertIs(self.lab.output,self.sink)
    def test_master_off_cancels_pending_and_keeps_physical_input(self):
        self.lab.profile['assists']['auto_jockey']=True
        self.lab.new_output('physical'); self.lab.arm_current(); self.lab.on_frame()
        self.lab.runtime_action({'action':'disarm_assists'})
        self.assertFalse(self.lab.assists_armed); self.assertFalse(self.lab.startup_arm_pending)
        self.assertFalse(self.sink.closed); self.assertFalse(self.sink.sent[-1].buttons['L2 button'])
        self.lab.buttons={'Cross':True}; self.lab.on_frame()
        self.assertTrue(self.sink.sent[-1].buttons['Cross'])
    def test_switch_validation(self):
        for b in [{'key':'unknown','enabled':False},{'key':'auto_jockey','enabled':'false'}]:
            with self.assertRaises(ValueError): self.lab.runtime_action({'action':'set_assist_enabled',**b})
