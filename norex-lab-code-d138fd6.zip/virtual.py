"""Explicit Linux uinput gamepad sink; never enabled on startup."""
import fcntl
import os
import struct
from pipeline import AXES, BUTTONS, neutral_frame

EVENT=struct.Struct('@llHHi')
NAME='NOREX Controller Lab Virtual'

from output_backend import OutputBackend

class UInputOutput(OutputBackend):
    backend_id = 'uinput'
    destination = 'Local Linux virtual gamepad'
    transport = 'Linux uinput; no console transport'

    def status(self):
        state = super().status()
        state.update(transport_connected=self.fd is not None and self.created,
                     receipt='local writes only', frames=self.frames)
        return state

    def __init__(self,path='/dev/uinput'):
        self.fd=None; self.created=False; self.frames=0
        from command_center import Owner
        directory=__import__('pathlib').Path(os.environ.get('XDG_RUNTIME_DIR',f'/run/user/{os.getuid()}'))
        self.output_owner=Owner(directory/'norex-controller-output.lock',error=ValueError)
        try:
            self.fd=os.open(path,os.O_WRONLY|os.O_NONBLOCK)
            for typ in (1,3): fcntl.ioctl(self.fd,0x40045564,typ)
            for code in BUTTONS: fcntl.ioctl(self.fd,0x40045565,code)
            for code,name in AXES.items():
                fcntl.ioctl(self.fd,0x40045567,code)
                lo,hi=(-32767,32767) if name in ('LX','LY','RX','RY') else ((0,255) if name in ('L2','R2') else (-1,1))
                fcntl.ioctl(self.fd,0x401c5504,struct.pack('@H2x6i',code,0,lo,hi,0,0,0))
            # BUS_VIRTUAL, generic local identity. Never impersonates a Sony device.
            fcntl.ioctl(self.fd,0x405c5503,struct.pack('@HHHH80sI',6,0,0x4e58,1,NAME.encode(),0))
            fcntl.ioctl(self.fd,0x5501); self.created=True; self.neutralize()
        except BaseException:
            self.close(); raise
    def emit(self,frame):
        if self.fd is None: raise OSError('Virtual output closed')
        events=[]
        for code,name in AXES.items():
            v=frame.axes.get(name,0)
            if name in ('LX','LY','RX','RY'): v=round(max(-1,min(1,v))*32767)
            elif name in ('L2','R2'): v=round(max(0,min(1,v))*255)
            else: v=round(max(-1,min(1,v)))
            events.append(EVENT.pack(0,0,3,code,v))
        for code,name in BUTTONS.items(): events.append(EVENT.pack(0,0,1,code,int(frame.buttons.get(name,False))))
        events.append(EVENT.pack(0,0,0,0,0))
        blob=b''.join(events)
        if os.write(self.fd,blob)!=len(blob): raise OSError('Incomplete uinput frame write')
        self.frames+=1
    def neutralize(self):
        if self.fd is not None and self.created: self.emit(neutral_frame())
    def close(self):
        if self.fd is None:
            if getattr(self,'output_owner',None):self.output_owner.close();self.output_owner=None
            return
        try:
            if self.created:
                try: self.neutralize()
                finally: fcntl.ioctl(self.fd,0x5502)
        finally:
            os.close(self.fd); self.fd=None; self.created=False
            if getattr(self,'output_owner',None):self.output_owner.close();self.output_owner=None
