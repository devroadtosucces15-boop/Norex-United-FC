import io,json,unittest
from types import SimpleNamespace
from network_integration import post
import threading
class Settings:
    def __init__(self):self.operation_lock=threading.RLock();self.settings={'download_mbps':250,'upload_mbps':80,'latency_watch':True}
    def update(self,data):self.settings=data;return {'settings':data}
class Request:
    path='/api/automation'
    def __init__(self,origin='http://127.0.0.1:8790',token='local-token'):
        self.rfile=io.BytesIO(b'{"download_mbps":251}')
        self.headers={'Host':'127.0.0.1:8790','Origin':origin,'X-CSRF-Token':token,'Content-Length':'21'}
        self.server=SimpleNamespace(network=SimpleNamespace(automation=Settings()),network_token='local-token')
    def allowed(self):return self.headers['Origin']=='http://'+self.headers['Host']
    def reply(self,data,status=200,**_):self.result=data;self.status=status
class NetworkIntegrationTests(unittest.TestCase):
    def test_partial_change_preserves_other_shared_settings(self):
        request=Request();self.assertTrue(post(request));self.assertEqual(request.status,200)
        self.assertEqual(request.result['settings'],{'download_mbps':251,'upload_mbps':80,'latency_watch':True})
    def test_foreign_origin_cannot_change_settings(self):
        request=Request(origin='http://foreign.invalid');post(request);self.assertEqual(request.status,403)
    def test_wrong_token_cannot_change_settings(self):
        request=Request(token='wrong');post(request);self.assertEqual(request.status,403)
