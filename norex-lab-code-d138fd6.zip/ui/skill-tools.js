/* Skill tools: filters, custom skill lists, review notes and the move viewer.
   Loaded before app.js; everything here reads app.js globals (state, effective, skills, esc, $, notice…) only when called. */
const skillTools=(()=>{'use strict';
const GROUPS=[['rating','Star rating'],['where','Where it happens'],['situation','Situation'],['fake','Fake shot'],['buttons','Buttons held'],['stick','Stick used'],['side','Side'],['playstyle','PlayStyle'],['pace','Speed'],['recipe','Recipe'],['review','Our notes'],['favorite','Favorites'],['source','Source']];
const ORDER={rating:['1 star','2 star','3 star','4 star','5 star','juggling','unrated'],where:['on the ground','in air'],situation:['standing','jogging','running','any situation'],fake:['fake shot','no fake shot'],buttons:['L1','R1','L2','R2','R3','no buttons'],stick:['right stick flick','right stick hold','right stick arc','left stick flick','left stick hold'],side:['left','right','either'],pace:['quick','medium','long'],recipe:['has recipe','needs recipe'],review:['correct','needs checking','not reviewed'],source:['in the FC27 menu','older game']};
const LABEL={'right stick flick':'Right stick flick','right stick hold':'Right stick hold','right stick arc':'Right stick rotate','left stick flick':'Left stick flick','left stick hold':'Left stick hold',either:'Either / mirrored','correct':'✓ Correct','needs checking':'⚠ Needs checking','not reviewed':'Not reviewed',quick:'Quick (≤ 0.3 s)',medium:'Medium (≤ 0.6 s)',long:'Long (> 0.6 s)'};
const label=v=>LABEL[v]||v.charAt(0).toUpperCase()+v.slice(1);
const mk=n=>moveKey(n);
const catalogFor=name=>state.assists.catalog.find(x=>mk(x.name)===mk(name)||x.video_aliases?.some(alias=>mk(alias)===mk(name)));
const playabilityHint=name=>{const c=catalogFor(name);return c?.ready?(c.playback_kind==='video controller replay'?'Play one measured video-controller sequence; game outcome is unverified':playHint):(c?.playback_reason||'No playable input sequence is configured for this move yet.')};

/* ---------- facts about a move ---------- */
function rowFacets(row){
  const c=catalogFor(row.name),f={...(c?.facets||{})};
  if(!c?.facets){const st=row.stars;f.rating=[st?st+' star':(row.display_group==='5'?'unrated':'unrated')];f.source=['in the FC27 menu']}
  f.recipe=[c?.ready?'has recipe':'needs recipe'];
  const n=(typeof skillNotes==='object'&&skillNotes[c?.name||row.name])||null;
  f.review=[n?.status==='correct'?'correct':n?.status==='check'?'needs checking':'not reviewed'];
  f.favorite=isFavorite(row)?['favorite']:[];
  f.source=f.menu||(row.video_membership?[row.video_membership==='FC27'?'FC27 video reference':row.video_membership==='FC26 only'?'FC26 video reference':'not established by supplied videos']:f.source)||['in the FC27 menu'];
  return f}
function matches(row,filters){
  for(const [g,sel] of Object.entries(filters||{})){if(!sel||!sel.size)continue;const vals=rowFacets(row)[g]||[];if(!vals.some(v=>sel.has(v)))return false}
  return true}
function activeCount(filters){return Object.values(filters||{}).reduce((n,s)=>n+(s?s.size:0),0)}

/* ---------- filter bar (used by the Skills page and the list builder) ---------- */
function filterBar(host,rows,filters,onChange){
  const open=host.querySelector('details')?.open??false;
  const parts=GROUPS.map(([g,title])=>{
    const counts=new Map();
    rows.forEach(r=>(rowFacets(r)[g]||[]).forEach(v=>counts.set(v,(counts.get(v)||0)+1)));
    const order=ORDER[g]||[];const vals=[...counts.keys()].sort((a,b)=>{const ia=order.indexOf(a),ib=order.indexOf(b);return (ia<0?99:ia)-(ib<0?99:ib)||a.localeCompare(b)});
    if(!vals.length)return '';
    return `<fieldset class="chip-group"><legend>${esc(title)}</legend>${vals.map(v=>`<button type="button" class="chip" data-g="${g}" data-v="${esc(v)}" aria-pressed="${filters[g]?.has(v)?'true':'false'}">${esc(label(v))} <small>${counts.get(v)}</small></button>`).join('')}</fieldset>`}).join('');
  const n=activeCount(filters);
  const body=`<div class="chip-groups">${parts}</div><div class="actions"><button type="button" data-clear-filters ${n?'':'disabled'}>Clear filters</button><small class="muted">Several in one group = any of them; groups combine.</small></div>`;
  host.innerHTML=host.classList.contains('con-filters')?body:`<details class="filter-bar" ${open||n?'open':''}><summary>Filters${n?` <span class="pill">${n} on</span>`:''}</summary>${body}</details>`;
  host.querySelectorAll('.chip').forEach(b=>b.onclick=()=>{const g=b.dataset.g,v=b.dataset.v;(filters[g]??=new Set());filters[g].has(v)?filters[g].delete(v):filters[g].add(v);onChange()});
  host.querySelector('[data-clear-filters]').onclick=()=>{Object.keys(filters).forEach(k=>delete filters[k]);onChange()}}

/* ---------- review notes ---------- */
function reviewBadge(name,dot){const c=catalogFor(name),n=skillNotes?.[c?.name||name];
  if(dot)return n?.note?'<span class="note-dot" title="'+esc(n.note)+'">✎</span>':'';
  return n?.status==='correct'?'<span class="pill ok" title="'+esc(n.note||'Marked correct')+'">✓ Correct</span>':n?.status==='check'?'<span class="pill warn" title="'+esc(n.note||'Needs checking')+'">⚠ Needs checking</span>':''}
async function setReview(name,status,note){
  const c=catalogFor(name),target=c?.name||name;
  const r=await fetch('/api/skill-notes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:target,status,note:note||''})});
  const d=await r.json();if(!r.ok||d.error)throw Error(d.error||'Could not save the note');skillNotes=d.notes}
function reviewButtons(name,compact){
  const c=catalogFor(name),n=skillNotes?.[c?.name||name]||{};
  const b=(st,txt)=>`<button type="button" data-review="${st}" data-name="${esc(name)}" aria-pressed="${n.status===st}" ${c?'':'disabled'} title="${c?'':'Only moves with a stored recipe can be reviewed'}">${txt}</button>`;
  return b('correct',compact?'✓':'✓ Correct')+b('check',compact?'⚠':'⚠ Needs checking')}
function bindReview(root,after){
  root.querySelectorAll('[data-review]').forEach(btn=>btn.onclick=async()=>{
    const name=btn.dataset.name,st=btn.dataset.review,cur=skillNotes?.[catalogFor(name)?.name||name];
    const note=root.querySelector('[data-note-for]')?.value??cur?.note??'';
    try{await setReview(name,cur?.status===st?null:st,note);after&&after();notice(cur?.status===st?'Mark cleared.':st==='correct'?'Marked correct.':'Marked as needs checking.')}catch(e){notice(e.message,true)}})}

/* ---------- play a move live ---------- */
let playPending=false;
async function playMove(name){
  if(playPending)throw Error('A move is already being sent.');
  const c=catalogFor(name);if(!c?.ready)throw Error('This move has no recipe yet.');
  playPending=true;try{const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'skill_run',name:c.name})});
  const d=await r.json().catch(()=>({}));if(!r.ok||d.error)throw Error(d.error||'Could not play the move');return d}finally{playPending=false}}
const playHint='Hold the left stick the way you are running before pressing Play: the move turns to match that direction. Needs Helpers armed and the controller ON.';

/* ---------- custom skill lists ---------- */
let draft={old:null,name:'',mode:'random',members:[]},listFilters={},listQuery='';
const emptyDraft=()=>({old:null,name:'',mode:'random',members:[]});
async function postLists(body){
  const r=await fetch('/api/skill-lists',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const d=await r.json();if(!r.ok||d.error)throw Error(d.error||'Could not save the list');skillLists=d.lists;return d}
function listChoices(){return state.assists.catalog.filter(s=>s.ready).map(s=>({name:s.name,stars:s.facets?.rating?.[0]&&/star/.test(s.facets.rating[0])?parseInt(s.facets.rating[0]):null,key:'existing:'+s.name,stars_text:s.facets?.rating?.[0]}))
  .sort((a,b)=>a.name.localeCompare(b.name))}
function listsPanel(){
  const host=$('#skillListsHost');if(!host)return;
  const bound=new Set((effective.configuration.play_tools.skill_bindings||[]).map(b=>b.skill));
  const all=listChoices().map(c=>({...state.assists.catalog.find(x=>x.name===c.name),name:c.name}));
  host.innerHTML=`<article class="card" id="skillListsCard"><div class="lb"><div class="lb-side"><h2 class="ph">My skill lists</h2>
  <div id="skillListRows">${skillLists.length?skillLists.map(l=>`<div class="skill"><div><strong>${esc(l.name)}</strong> <small>${esc(LIST_MODES[l.mode]||l.mode)} · ${l.members.length} move${l.members.length===1?'':'s'}${bound.has(LIST_PREFIX+l.name)?' · mapped':''}</small></div><div class="actions"><button data-list-edit="${esc(l.name)}">Edit</button><button data-list-delete="${esc(l.name)}" aria-label="Delete ${esc(l.name)}">✕</button></div></div>`).join(''):'<p class="muted tiny">No lists yet.</p>'}</div>
  <div id="listEditor"><h3 class="ph2">${draft.old?'Editing “'+esc(draft.old)+'”':'New list'}</h3>
  <label>Name <input id="listName" maxlength="40" value="${esc(draft.name)}" placeholder="e.g. Wing escapes"></label>
  <label>Picks <select id="listMode"><option value="random">Random (no repeats in a row)</option><option value="shuffle">Shuffle (each once, then reshuffle)</option><option value="order">In order</option></select></label>
  <p id="listCount" class="muted tiny"></p><div class="actions"><button id="saveList" class="go">Save list</button><button id="clearList" type="button">Start over</button></div>
  <p class="muted tiny">Each press of a mapped combination plays one move from its list. Pick the list in the Mapper tab.</p></div></div>
  <div class="lb-main"><input id="listSearch" aria-label="Search moves for this list" placeholder="Search by name or input" value="${esc(listQuery)}">
  <div id="listFilterHost"></div>
  <div class="actions"><button type="button" id="listSelectAll">Select all shown</button><button type="button" id="listClearShown">Clear shown</button><button type="button" id="listClearAll">Clear everything</button><small id="listShown" class="muted"></small></div>
  <div id="listPreview" class="list-preview" hidden></div>
  <div id="listPick" class="list-pick"></div></div></div></article>`;
  $('#listMode').value=draft.mode;
  const shown=()=>{const q=listQuery.toLowerCase();return all.filter(s=>matches(s,listFilters)&&(!q||[s.name,s.ps5_input].join(' ').toLowerCase().includes(q)))};
  const paint=()=>{const scroll=$('#listPick').scrollTop;const rows=shown();
    $('#listShown').textContent=`${rows.length} shown · ${draft.members.length} selected`;
    $('#listPick').innerHTML=rows.map(s=>`<div class="pick-row${previewName===s.name?' on':''}"><label><input type="checkbox" data-pick="${esc(s.name)}" ${draft.members.includes(s.name)?'checked':''}> <span>${esc(s.name)} <small class="muted">${esc((s.facets?.rating||[''])[0])}</small></span></label><span class="pick-btns"><button type="button" data-pv="${esc(s.name)}" title="See what this move does" aria-label="Preview ${esc(s.name)}">👁</button><button type="button" data-pp="${esc(s.name)}" title="${esc(playHint)}" aria-label="Play ${esc(s.name)} on PS">▶</button></span></div>`).join('')||'<span class="muted">No moves match these filters.</span>';
    $('#listPick').querySelectorAll('[data-pick]').forEach(c=>c.onchange=()=>{const n=c.dataset.pick;draft.members=c.checked?[...draft.members.filter(x=>x!==n),n]:draft.members.filter(x=>x!==n);count()});
    $('#listPick').querySelectorAll('[data-pv]').forEach(b=>b.onclick=()=>previewIn(b.dataset.pv));
    $('#listPick').querySelectorAll('[data-pp]').forEach(b=>b.onclick=async()=>{previewIn(b.dataset.pp);try{await playMove(b.dataset.pp);notice('Move sent.')}catch(e){notice(e.message,true)}});$('#listPick').scrollTop=scroll;count()};
  let previewName=null;
  const previewIn=async n=>{previewName=n;const box=$('#listPreview');if(!box)return;
    box.hidden=false;box.innerHTML=`<strong>${esc(n)}</strong> <small class="muted">loading…</small>`;
    $('#listPick').querySelectorAll('.pick-row').forEach(r=>r.classList.toggle('on',r.querySelector('[data-pick]').dataset.pick===n));
    const rec=await recipeFor(n).catch(()=>null);if(previewName!==n)return;
    const c=catalogFor(n),inList=draft.members.includes(n);
    box.innerHTML=`<div class="actions"><strong>${esc(n)}</strong><small class="muted">${esc((c?.facets?.rating||[''])[0]||'')}${c?.ps5_input?' · '+esc(c.ps5_input):''}</small><span class="pick-btns"><button type="button" id="pvPlay" title="${esc(playHint)}">▶ Play on PS</button><button type="button" id="pvToggle">${inList?'− Remove from list':'+ Add to list'}</button><button type="button" id="pvOpen">Open in viewer</button><button type="button" id="pvClose" aria-label="Close preview">✕</button></span></div>
    <p class="pv-line">${rec?describe(rec.steps).map(x=>esc(x.text.replace('right stick','RS').replace('left stick','LS').replace('release everything','release'))).join(' → '):'No recipe for this move yet.'}</p>`;
    $('#pvPlay').onclick=async()=>{try{await playMove(n);notice('Move sent.')}catch(e){notice(e.message,true)}};
    $('#pvToggle').onclick=()=>{draft.members=draft.members.includes(n)?draft.members.filter(x=>x!==n):[...draft.members,n];paint();previewIn(n)};
    $('#pvOpen').onclick=()=>show(n);
    $('#pvClose').onclick=()=>{previewName=null;box.hidden=true;paint()}};
  const count=()=>{$('#listShown').textContent=`${shown().length} shown · ${draft.members.length} selected`;$('#listCount').textContent=draft.members.length?`In this list: ${draft.members.join(' → ')}`:'Tick the moves to include (up to 200).'};
  const bar=()=>filterBar($('#listFilterHost'),all,listFilters,()=>{bar();paint()});
  bar();paint();
  $('#listSearch').oninput=e=>{listQuery=e.target.value;paint()};
  $('#listName').oninput=e=>draft.name=e.target.value;$('#listMode').onchange=e=>draft.mode=e.target.value;
  $('#listSelectAll').onclick=()=>{const add=shown().map(s=>s.name).filter(n=>!draft.members.includes(n));draft.members=[...draft.members,...add].slice(0,200);paint()};
  $('#listClearShown').onclick=()=>{const hide=new Set(shown().map(s=>s.name));draft.members=draft.members.filter(n=>!hide.has(n));paint()};
  $('#listClearAll').onclick=()=>{draft.members=[];paint()};
  $('#clearList').onclick=()=>{draft=emptyDraft();listFilters={};listQuery='';listsPanel()};
  $('#saveList').onclick=async()=>{try{await postLists({action:'save',name:draft.name,members:draft.members,mode:draft.mode,old_name:draft.old});const saved=draft.name;draft=emptyDraft();listsPanel();combinationMapper();notice(`List “${saved}” saved. Pick it in the combination mapper.`)}catch(e){notice(e.message,true)}};
  host.querySelectorAll('[data-list-edit]').forEach(b=>b.onclick=()=>{const l=skillLists.find(x=>x.name===b.dataset.listEdit);if(!l)return;draft={old:l.name,name:l.name,mode:l.mode,members:[...l.members]};listsPanel();$('#listName').focus()});
  host.querySelectorAll('[data-list-delete]').forEach(b=>b.onclick=async()=>{const n=b.dataset.listDelete;if(!confirm(bound.has(LIST_PREFIX+n)?`“${n}” is mapped to a combination. Delete it anyway? That combination will do nothing until you change it.`:`Delete the list “${n}”?`))return;try{await postLists({action:'delete',name:n});listsPanel();combinationMapper();notice(`List “${n}” deleted.`)}catch(e){notice(e.message,true)}})}

/* ---------- describing a recipe in plain words ---------- */
const ARROWS=['→','↘','↓','↙','←','↖','↑','↗'];
const arrowOf=(x,y)=>{if(Math.hypot(x,y)<.3)return '';return ARROWS[(Math.round(Math.atan2(y,x)/(Math.PI/4))+8)%8]};
const FACE={Square:'□ Square',Circle:'○ Circle',Cross:'✕ Cross',Triangle:'△ Triangle'};
function stepFacts(s){
  const a=s.axes||{},b=s.buttons||{},held=[];
  ['L1','R1','R3','L3'].forEach(k=>{if(b[k])held.push(k)});
  ['L2','R2'].forEach(k=>{if((a[k]||0)>.5||b[k+' button'])held.push(k)});
  Object.keys(FACE).forEach(k=>{if(b[k])held.push(FACE[k])});
  return {held:held.join(' + '),rs:arrowOf(a.RX||0,a.RY||0),ls:arrowOf(a.LX||0,a.LY||0),ms:s.ms}}
function describe(steps){
  const f=steps.map(stepFacts),out=[];let t=0;
  f.forEach(x=>{const last=out[out.length-1],key=x.held+'|'+x.rs+'|'+x.ls;
    if(last&&last.key===key){last.ms+=x.ms;last.end+=x.ms}
    else out.push({key,held:x.held,rs:x.rs,ls:x.ls,ms:x.ms,start:t,end:t+x.ms,sweep:[]});t+=x.ms});
  // runs of quick right-stick-only changes become one sweep
  const merged=[];
  for(const it of out){const p=merged[merged.length-1];
    if(p&&p.sweep.length&&it.ms<=40&&it.rs&&it.held===p.held&&!it.ls&&!p.ls){p.sweep.push(it.rs);p.ms+=it.ms;p.end=it.end;continue}
    if(it.ms<=40&&it.rs&&!it.ls&&out.length>3){merged.push({...it,sweep:[it.rs]});continue}
    merged.push({...it,sweep:[]})}
  return merged.map(it=>{
    const parts=[];if(it.held)parts.push('Hold '+it.held);
    if(it.sweep.length>1)parts.push('sweep right stick '+[...new Set(it.sweep.reduce((acc,x)=>acc[acc.length-1]===x?acc:[...acc,x],[]))].join(' '));
    else if(it.rs)parts.push('right stick '+it.rs);
    if(it.ls)parts.push('left stick '+it.ls);
    if(!parts.length)parts.push('release everything');
    return {text:parts.join(' + '),ms:Math.round(it.ms),start:it.start,end:it.end}})}
function frameAt(steps,t){let acc=0;for(const s of steps){acc+=s.ms;if(t<acc)return s}return null}

/* ---------- the move viewer ---------- */
const recipeCache={},recipePending={};
async function recipeFor(name){
  const c=catalogFor(name);if(!c?.ready)return null;
  if(recipeCache[c.name])return recipeCache[c.name];
  if(recipePending[c.name])return recipePending[c.name];
  const task=(async()=>{const r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'skill_get',name:c.name})});const d=await r.json();if(!r.ok)return null;return recipeCache[c.name]=d.recipe})();recipePending[c.name]=task;try{return await task}finally{delete recipePending[c.name]}}
const view={name:null,steps:null,desc:[],t:0,speed:1,playing:false,loop:false,last:0,live:false,liveAt:0,liveElapsed:0,trail:{L:[],R:[]},tel:null,telAt:0,raf:0};
function padSvg(){
  const stick=(id,cx,cy)=>`<g id="${id}"><circle cx="${cx}" cy="${cy}" r="36" class="pad-well"/><polyline id="${id}-trail" class="pad-trail" points=""/><circle id="${id}-knob" cx="${cx}" cy="${cy}" r="17" class="pad-knob"/><text id="${id}-dir" x="${cx}" y="${cy+58}" class="pad-dir" text-anchor="middle"></text></g>`;
  const face=(id,cx,cy,sym)=>`<g id="${id}"><circle cx="${cx}" cy="${cy}" r="17" class="pad-btn"/><text x="${cx}" y="${cy+6}" text-anchor="middle" class="pad-sym">${sym}</text></g>`;
  const dp=(id,pts)=>`<polygon id="${id}" points="${pts}" class="pad-btn"/>`;
  return `<svg viewBox="0 0 560 340" role="img" aria-label="Controller showing the move" class="move-pad">
  <path d="M120 70 Q60 70 38 150 L12 270 Q4 322 56 312 L132 262 H428 L504 312 Q556 322 548 270 L522 150 Q500 70 440 70Z" class="pad-body"/>
  <rect id="pad-L1" x="104" y="44" width="100" height="18" rx="9" class="pad-btn"/><text x="154" y="58" class="pad-sym" text-anchor="middle">L1</text>
  <rect id="pad-R1" x="356" y="44" width="100" height="18" rx="9" class="pad-btn"/><text x="406" y="58" class="pad-sym" text-anchor="middle">R1</text>
  <rect x="112" y="6" width="84" height="32" rx="10" class="pad-well"/><rect id="pad-L2" x="112" y="38" width="84" height="0" rx="10" class="pad-fill"/><text x="154" y="27" class="pad-sym" text-anchor="middle">L2</text>
  <rect x="364" y="6" width="84" height="32" rx="10" class="pad-well"/><rect id="pad-R2" x="364" y="38" width="84" height="0" rx="10" class="pad-fill"/><text x="406" y="27" class="pad-sym" text-anchor="middle">R2</text>
  <rect x="236" y="84" width="88" height="46" rx="12" class="pad-well"/><text x="280" y="112" class="pad-note" text-anchor="middle">touchpad</text>
  ${dp('pad-up','122,104 140,104 131,88')}${dp('pad-down','122,128 140,128 131,144')}${dp('pad-left','114,110 114,122 98,116')}${dp('pad-right','148,110 148,122 164,116')}
  ${face('pad-Triangle',428,98,'△')}${face('pad-Circle',466,128,'○')}${face('pad-Cross',428,158,'✕')}${face('pad-Square',390,128,'□')}
  ${stick('pad-L',196,226)}${stick('pad-R',364,226)}
  <text x="196" y="288" class="pad-note" text-anchor="middle">LEFT STICK</text><text x="364" y="288" class="pad-note" text-anchor="middle">RIGHT STICK</text></svg>`}
function paint(frame){
  const a=frame?.axes||{},b=frame?.buttons||{},root=$('#moveViewerHost');if(!root)return;
  const set=(id,on)=>{const e=root.querySelector('#'+id);e&&e.classList.toggle('on',!!on)};
  ['L1','R1','Triangle','Circle','Cross','Square'].forEach(k=>set('pad-'+k,b[k]));
  set('pad-up',(a.DY||0)<-.5);set('pad-down',(a.DY||0)>.5);set('pad-left',(a.DX||0)<-.5);set('pad-right',(a.DX||0)>.5);
  ['L2','R2'].forEach(k=>{const v=Math.max(a[k]||0,b[k+' button']?1:0),e=root.querySelector('#pad-'+k);if(e){e.setAttribute('height',String(32*v));e.setAttribute('y',String(38-32*v))}});
  for(const [id,x,y,c,cx,cy,click] of [['L','LX','LY','L',196,226,b.L3],['R','RX','RY','R',364,226,b.R3]]){
    const px=cx+(a[x]||0)*19,py=cy+(a[y]||0)*19,knob=root.querySelector(`#pad-${id}-knob`),dir=root.querySelector(`#pad-${id}-dir`);
    if(!knob)continue;knob.setAttribute('cx',px);knob.setAttribute('cy',py);knob.classList.toggle('on',Math.hypot(a[x]||0,a[y]||0)>.3||!!click);
    const t=view.trail[id];t.push([px,py]);if(t.length>14)t.shift();root.querySelector(`#pad-${id}-trail`).setAttribute('points',t.map(p=>p.join(',')).join(' '));
    const arrow=arrowOf(a[x]||0,a[y]||0);dir.textContent=arrow?(id==='L'?'LS ':'RS ')+arrow:''}}
function setMove(name){if(view.name===name&&view.steps){renderInfo();return}view.name=name;view.trail={L:[],R:[]};view.steps=null;view.desc=[];view.t=0;recipeFor(name).then(r=>{if(view.name!==name)return;view.steps=r?.steps||null;view.desc=view.steps?describe(view.steps):[];renderInfo();wakeViewer()})}
function renderCards(){
  const root=$('#moveViewerHost');if(!root)return;const tel=view.tel?.skill,live=view.live;
  const nm=n=>n?esc(n):'—',list=tel?.list?esc(tel.list.replace('List: ','')):null;
  const card=(cls,title,name,sub,click)=>`<button type="button" class="move-card ${cls}" ${click&&name?`data-view="${esc(name)}"`:'disabled'}><small>${title}</small><strong>${nm(name)}</strong><span>${sub||''}</span></button>`;
  root.querySelector('#moveCards').innerHTML=card('prev','Previous',tel?.previous?.name,tel?.previous?.list?'from '+esc(tel.previous.list.replace('List: ','')):'',true)
    +card('now'+(live?' live':''),live?'Playing now':'Showing',live?(tel?.now?.name||view.name):view.name,live?(tel?.now?`step ${tel.now.step+1} of ${tel.now.steps}`+(list?' · list '+list:''):'finishing move'):(view.playing?(view.loop?'preview · repeat':'preview · once'):'preview paused'),false)
    +card('next','Up next',tel?.next,tel?.next?(list?'from list '+list+' · locked in':''):(tel?.list?'':'(plays only from a list)'),true);
  root.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>setMove(b.dataset.view))}
function renderInfo(){
  const root=$('#moveViewerHost');if(!root)return;
  const c=view.name?catalogFor(view.name):null,meta=c?.facets;
  root.querySelector('#moveTitle').textContent=view.name||'Pick a move to see what it does';
  root.querySelector('#moveMeta').innerHTML=c?[(meta?.rating||[]).concat(meta?.situation||[],meta?.buttons||[]).filter(Boolean).map(x=>`<span class="pill">${esc(label(x))}</span>`).join(' '),reviewBadge(view.name)].join(' '):'';
  root.querySelector('#moveSteps').innerHTML=view.desc.length?`<ol class="move-steps">${view.desc.map((d,i)=>`<li data-step="${i}"><span>${esc(d.text)}</span><small>${d.ms} ms</small></li>`).join('')}</ol><p class="muted tiny">Facing up; the Lab turns it to match your movement. ${esc(c?.status||'')}</p>`:(view.name?'<p class="muted">Loading the recipe…</p>':'<p class="muted">Choose a move below, or press “Show on controller” in any move’s details.</p>');
  const rv=root.querySelector('#moveReview');if(rv){rv.innerHTML=view.name&&c?listButton(view.name)+reviewButtons(view.name)+`<input data-note-for="${esc(view.name)}" maxlength="200" placeholder="Note (optional)" value="${esc(skillNotes?.[c.name]?.note||'')}">`:'';bindReview(rv,()=>{renderInfo();if(typeof renderSkillRows==='function')renderSkillRows()});bindListButtons(rv)}}
function highlight(t,live){
  const root=$('#moveViewerHost');if(!root||!view.desc.length)return;
  let idx=view.desc.findIndex(d=>t<d.end);if(idx<0)idx=view.desc.length-1;
  root.querySelectorAll('.move-steps li').forEach((li,i)=>li.classList.toggle('current',i===idx));
  const bar=root.querySelector('#moveProgress'),total=view.desc.length?view.desc[view.desc.length-1].end:1;if(bar)bar.style.width=Math.min(100,100*t/total)+'%';
  const now=root.querySelector('#moveNow');if(now)now.textContent=(live?'LIVE · ':'')+(view.desc[idx]?view.desc[idx].text:'')}
function wakeViewer(){const host=$('#moveViewerHost');if(!view.raf&&!document.hidden&&host&&host.getClientRects().length){view.last=0;view.raf=requestAnimationFrame(tick)}}
function previewLabel(){const b=$('#movePause');if(b)b.textContent=view.playing?'Pause preview':'▶ Preview';}
function tick(ts){
  const root=$('#moveViewerHost');if(document.hidden||!root||!root.getClientRects().length||!root.querySelector('.move-pad')){view.raf=0;return}
  view.raf=0;
  if(view.last&&ts-view.last<33){view.raf=requestAnimationFrame(tick);return}
  const dt=Math.min(100,ts-(view.last||ts));view.last=ts;
  const tel=view.tel?.skill,fresh=view.tel&&performance.now()-view.telAt<900;
  const liveNow=fresh&&tel?.now&&tel.now.name;
  if(liveNow){
    if(view.name!==tel.now.name)setMove(tel.now.name);
    view.live=true;view.t=tel.now.elapsed_ms+(performance.now()-view.telAt);view.hold=performance.now()+700;
  }else{
    if(view.live&&performance.now()>(view.hold||0)){view.live=false;view.playing=false;view.t=0;previewLabel();renderCards()}
    if(!view.live&&view.playing&&view.steps){const total=view.desc.length?view.desc[view.desc.length-1].end+500:1000;view.t+=dt*view.speed;if(view.t>=total){if(view.loop)view.t%=total;else{view.t=total;view.playing=false;previewLabel();renderCards()}}}}
  const f=view.steps?frameAt(view.steps,view.t):null;
  paint(f);highlight(view.t,view.live);
  if(view.liveKey!==(view.live+'|'+(tel?.previous?.name||'')+'|'+(tel?.next||'')+'|'+(tel?.now?.step??''))){view.liveKey=view.live+'|'+(tel?.previous?.name||'')+'|'+(tel?.next||'')+'|'+(tel?.now?.step??'');renderCards()}
  if(view.playing||view.live)view.raf=requestAnimationFrame(tick);}
function mountViewer(){
  const host=$('#moveViewerHost');if(!host)return;
  if(host.querySelector('.move-pad')){wakeViewer();return}
  const names=state.assists.catalog.filter(s=>s.ready).map(s=>s.name).sort((a,b)=>a.localeCompare(b));
  host.innerHTML=`<article id="moveViewer"><div id="moveCards" class="move-cards"></div>
  <div class="move-grid"><div class="move-left">${padSvg()}<div class="move-bar"><span id="moveProgress"></span></div><p id="moveNow" class="move-now"></p></div>
  <div class="move-right"><h3 id="moveTitle"></h3><div id="moveMeta"></div><div id="moveSteps"></div></div></div>
  <div class="move-tools"><label>Move <select id="moveSelect"><option value="">Choose…</option>${names.map(n=>`<option>${esc(n)}</option>`).join('')}</select></label>
  <label>Speed <select id="moveSpeed"><option value="0.25">0.25×</option><option value="0.5">0.5×</option><option value="1" selected>1×</option><option value="2">2×</option></select></label>
  <button type="button" id="movePause">▶ Preview</button><label><input type="checkbox" id="moveLoop" ${view.loop?'checked':''}> Repeat preview</label><button type="button" id="movePlay" class="go" title="${esc(playHint)}">▶ Play on PS</button><span id="moveReview" class="actions"></span></div>
  <p class="muted tiny">${esc(playHint)}</p></article>`;
  $('#moveSelect').onchange=e=>{if(e.target.value){view.playing=true;view.t=0;view.trail={L:[],R:[]};setMove(e.target.value);previewLabel();wakeViewer()}};
  $('#moveSpeed').onchange=e=>view.speed=parseFloat(e.target.value);
  $('#movePause').onclick=()=>{view.playing=!view.playing;if(view.playing){view.t=0;view.trail={L:[],R:[]}}previewLabel();renderCards();wakeViewer()};
  $('#moveLoop').onchange=e=>view.loop=e.target.checked;
  $('#movePlay').onclick=async()=>{try{await playMove(view.name);notice('Move sent.')}catch(e){notice(e.message,true)}};
  if(!view.name&&names.length)setMove(names.includes('Roulette Right')?'Roulette Right':names[0]);else setMove(view.name);
  $('#moveSelect').value=view.name||'';renderCards();renderInfo();previewLabel();wakeViewer()}
function show(name){view.playing=true;view.t=0;view.trail={L:[],R:[]};setMove(name);previewLabel();wakeViewer();const sel=$('#moveSelect');if(sel)sel.value=catalogFor(name)?.name||name;if(typeof showConsoleTab==='function')showConsoleTab('viewer');document.querySelectorAll('#skillRows .srow').forEach(r=>r.classList.toggle('sel',mk(r.dataset.row)===mk(name)));renderCards()}
if(typeof document.addEventListener==='function')document.addEventListener('labs-telemetry',e=>{view.tel=e.detail;view.telAt=performance.now();wakeViewer()});


/* ---------- add a move to a list from anywhere ---------- */
function listButton(name,compact){const c=catalogFor(name);return `<button type="button" data-add-list="${esc(name)}" ${c?.ready?'':'disabled'} title="${c?.ready?'Add to one of your skill lists':'Only moves with a recipe can go in a list'}">${compact?'＋':'＋ List'}</button>`}
function closeListMenu(){document.querySelector('#listMenu')?.remove()}
async function saveMembership(list,members){await postLists({action:'save',name:list.name,members,mode:list.mode,old_name:list.name})}
function openListMenu(btn,after){
  closeListMenu();const name=catalogFor(btn.dataset.addList)?.name;if(!name)return;
  const m=document.createElement('div');m.id='listMenu';m.setAttribute('role','menu');
  const draw=()=>{m.innerHTML=`<strong>Add “${esc(name)}” to a list</strong>${skillLists.length?skillLists.map(l=>`<button type="button" role="menuitemcheckbox" aria-checked="${l.members.includes(name)}" data-l="${esc(l.name)}">${l.members.includes(name)?'✓':'＋'} ${esc(l.name)} <small>${l.members.length}</small></button>`).join(''):'<small class="muted">No lists yet.</small>'}<button type="button" data-new>＋ New list…</button>`;
    m.querySelectorAll('[data-l]').forEach(b=>b.onclick=async()=>{const l=skillLists.find(x=>x.name===b.dataset.l);if(!l)return;const has=l.members.includes(name);
      try{if(has&&l.members.length===1)throw Error('A list needs at least one move. Delete the list instead.');
        await saveMembership(l,has?l.members.filter(x=>x!==name):[...l.members,name]);listsPanel();combinationMapper();notice(has?`Removed from “${l.name}”.`:`Added to “${l.name}”.`);after&&after();draw()}catch(e){notice(e.message,true)}});
    m.querySelector('[data-new]').onclick=async()=>{const n=prompt('Name for the new list:');if(!n)return;try{await postLists({action:'save',name:n,members:[name],mode:'random'});listsPanel();combinationMapper();notice(`List “${n.trim()}” made with ${name}.`);after&&after();draw()}catch(e){notice(e.message,true)}}};
  draw();document.body.appendChild(m);
  const r=btn.getBoundingClientRect();m.style.top=Math.min(window.innerHeight-m.offsetHeight-8,r.bottom+4)+'px';m.style.left=Math.max(8,Math.min(window.innerWidth-m.offsetWidth-8,r.left))+'px';
  setTimeout(()=>document.addEventListener('pointerdown',function off(e){if(!m.contains(e.target)){closeListMenu();document.removeEventListener('pointerdown',off,true)}},true),0)}
function bindListButtons(root,after){root.querySelectorAll('[data-add-list]').forEach(b=>b.onclick=e=>{e.stopPropagation();openListMenu(b,after)})}

/* ---------- the Skills page search bar with filters ---------- */
const mainFilters={};
function mountFilters(rowsProvider,onChange){const host=$('#skillFilterHost');if(!host)return;const draw=()=>filterBar(host,rowsProvider(),mainFilters,()=>{draw();onChange()});draw()}
return {current:()=>view.name,listButton,bindListButtons,matches,rowFacets,filterBar,mainFilters,mountFilters,activeCount,reviewBadge,reviewButtons,bindReview,setReview,playMove,playHint,playabilityHint,listsPanel,mountViewer,show,describe,catalogFor};
})();
