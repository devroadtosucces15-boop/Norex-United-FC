"""Only media preferences; never exposes or rewrites authentication values."""
import os
import tempfile
from pathlib import Path

class RemotePlaySettings:
    def __init__(self, path=None, running=None):
        self.path=Path(path) if path else Path.home()/'.config/Chiaki/Chiaki.conf'
        self.running=running or self.client_running
    @staticmethod
    def client_running():
        for p in Path('/proc').glob('[0-9]*/comm'):
            try:
                if p.read_text().strip()=='chiaki': return True
            except OSError: pass
        return False
    def status(self):
        result={'available':self.path.is_file(),'running':self.running(),'video_enabled':None,'audio_enabled':None,'applies':'next connection'}
        if not result['available']: return result
        section=False; mode=0
        for line in self.path.read_text().splitlines():
            if line.startswith('['): section=line=='[settings]'
            elif section and line.startswith('audio_video_disabled='):
                try: mode=int(line.split('=',1)[1])
                except ValueError: raise ValueError('Invalid chiaki-ng media setting')
        if mode not in range(4): raise ValueError('Invalid chiaki-ng media setting')
        result.update(video_enabled=not bool(mode&2),audio_enabled=not bool(mode&1))
        return result
    def apply(self,video,audio):
        if type(video) is not bool or type(audio) is not bool: raise ValueError('Media options must be true or false')
        if self.running(): raise ValueError('Close chiaki-ng before saving media options; reconnect afterward')
        if not self.path.is_file(): raise ValueError('Set up chiaki-ng first')
        lines=self.path.read_text().splitlines(keepends=True)
        start=next((i+1 for i,l in enumerate(lines) if l.strip()=='[settings]'),None)
        if start is None: lines.extend(['\n[settings]\n']); start=len(lines)
        end=next((i for i in range(start,len(lines)) if lines[i].startswith('[')),len(lines))
        mode=(0 if video else 2)|(0 if audio else 1)
        body=[l for l in lines[start:end] if not l.startswith('audio_video_disabled=')]
        if body and not body[-1].endswith('\n'): body[-1]+='\n'
        body.append(f'audio_video_disabled={mode}\n');lines[start:end]=body
        # Private backup and atomic replacement retain registration and login fields.
        backup=self.path.with_name(self.path.name+'.before-lab-media')
        fd=os.open(backup,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'wb') as f:f.write(self.path.read_bytes())
        backup.chmod(0o600)
        fd,name=tempfile.mkstemp(dir=self.path.parent,prefix='.media-')
        try:
            with os.fdopen(fd,'w') as f:f.write(''.join(lines));f.flush();os.fsync(f.fileno())
            os.replace(name,self.path)
        finally:
            if os.path.exists(name):os.unlink(name)
        return self.status()

    def connect(self, launcher=None, spawn=None, host=None):
        import subprocess
        launcher=Path(launcher) if launcher else Path('/mnt/DEV_WORK/tools/chiaki-ng/launch-controller-lab.sh')
        if self.running(): raise ValueError('chiaki-ng is already open; use its console window')
        if not launcher.is_file(): raise ValueError('chiaki-ng Lab launcher is not installed')
        section=False; names=[];host_ids=[]
        for line in self.path.read_text().splitlines():
            if line.startswith('['): section=line=='[registered_hosts]'
            elif section and line.split('=',1)[0].endswith('\\server_nickname'):
                names.append(line.split('=',1)[1])
            elif section and line.split('=',1)[0].endswith('\\server_mac'):host_ids.append(line.split('=',1)[1])
        if len(names)!=1: raise ValueError('Register exactly one console in chiaki-ng before using quick connect')
        if host is None:host=self.discover_host(host_ids[0] if host_ids else None)
        with open(os.devnull,'w') as stream:
            proc=spawn([str(launcher),'--exit-app-on-stream-exit','stream',names[0],host]) if spawn else subprocess.Popen([str(launcher),'--exit-app-on-stream-exit','stream',names[0],host],stdout=stream,stderr=stream,start_new_session=True)
        if proc.poll() not in (None,0): raise ValueError('chiaki-ng exited while opening; use its setup window')
        return proc

    @staticmethod
    def discover_host(host_id):
        import socket,time,subprocess,json
        normalize=RemotePlaySettings.host_identity
        if not host_id:raise ValueError('Registered console identity missing; open Chiaki setup')
        addresses=json.loads(subprocess.check_output(['ip','-j','-4','addr'],text=True))
        targets={a['broadcast'] for row in addresses for a in row.get('addr_info',[]) if 'broadcast' in a}
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1);sock.bind(('',0));sock.settimeout(.25)
            for target in targets:sock.sendto(b'SRCH * HTTP/1.1\ndevice-discovery-protocol-version:00030010\n\0',(target,9302))
            until=time.monotonic()+2
            while time.monotonic()<until:
                try:data,address=sock.recvfrom(4096)
                except socket.timeout:continue
                headers={k.strip().lower():v.strip() for line in data.decode(errors='replace').splitlines() if ':' in line for k,v in [line.split(':',1)]}
                if normalize(headers.get('host-id',''))==normalize(host_id):
                    if not data.startswith(b'HTTP/1.1 200'):raise ValueError('PS5 is in rest mode; turn it on first')
                    return address[0]
        raise ValueError('Registered PS5 not discovered on this network; custom input remains OFF')

    @staticmethod
    def host_identity(value):
        if value.startswith('@ByteArray(') and value.endswith(')'):
            value=value[11:-1];data=bytearray();i=0
            while i<len(value):
                c=value[i];i+=1
                if c=='\\' and i<len(value):
                    c=value[i];i+=1
                    if c=='x':
                        digits=''
                        while i<len(value) and len(digits)<2 and value[i] in '0123456789abcdefABCDEF':digits+=value[i];i+=1
                        if not digits:raise ValueError('Invalid registered console identity')
                        data.append(int(digits,16));continue
                    c={'0':'\0','n':'\n','r':'\r','t':'\t'}.get(c,c)
                data.extend(c.encode('latin1'))
            if len(data)==6:return data.hex()
            value=data.decode('ascii')
        return ''.join(c for c in value.lower() if c in '0123456789abcdef')
