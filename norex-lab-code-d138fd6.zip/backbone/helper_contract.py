"""Machine-readable helper contracts for engine and future frontend."""
CATEGORIES=('Shooting','Passing & Crossing','Dribbling & Ball Control','Defending','Movement & Responsiveness','Goalkeeping','Accessibility / Utility')
def param(default,minimum,maximum,unit,low,high,lower,higher,tradeoff):
 return {'default':default,'min':minimum,'max':maximum,'unit':unit,'low_label':low,'high_label':high,'lower_means':lower,'higher_means':higher,'higher_is_better':False,'tradeoff':tradeoff}
HELPERS={
 'precision_stick':{'category':CATEGORIES[2],'name':'Precision Stick','kind':'TRANSFORM','inputs':['LEFT_STICK'],'what_it_does':'Adds finer response near center while preserving full outer travel.','does_not_change':['Dribbling','Agility','Balance'],'example':'Small corrections in crowded areas.','downside':'Too much precision can make initial movement feel less aggressive.','conflicts':[],'parameters':{'strength':param(70,0,100,'percent','Natural','Precise','Closer to raw response.','More center precision.','Higher is not automatically better.')}},
 'outer_response':{'category':CATEGORIES[4],'name':'Outer Stick Response','kind':'TRANSFORM','inputs':['LEFT_STICK'],'what_it_does':'Changes how quickly strong movement is reached near outer stick travel.','does_not_change':['Pace','Acceleration'],'example':'Faster transition from controlled movement to full direction.','downside':'Too aggressive can reduce fine control.','conflicts':[],'parameters':{'strength':param(55,0,100,'percent','Smooth','Aggressive','More gradual outer response.','Reaches strong output sooner.','High values can feel twitchy.')}},
 'smoothing':{'category':CATEGORIES[4],'name':'Stick Smoothing','kind':'TRANSFORM','inputs':['LEFT_STICK'],'what_it_does':'Reduces rapid small stick changes over time.','does_not_change':['Agility','Reactions'],'example':'Stabilize noisy micro-corrections.','downside':'Too much can feel delayed.','conflicts':['direction_stability'],'parameters':{'strength':param(20,0,100,'percent','Immediate','Smooth','More immediate physical response.','More temporal smoothing.','High smoothing adds perceived latency.'),'window_ms':param(12,0,40,'ms','Immediate','Long','Short memory.','Longer memory.','Long windows can feel sluggish.')}},
 'direction_stability':{'category':CATEGORIES[4],'name':'Direction Stability','kind':'TRANSFORM','inputs':['LEFT_STICK'],'what_it_does':'Suppresses tiny unintended angular oscillations without choosing a target direction.','does_not_change':['Defensive Awareness','Dribbling'],'example':'Hold a diagonal more steadily.','downside':'High values can resist intentional tiny angle changes.','conflicts':['smoothing'],'parameters':{'strength':param(50,0,100,'percent','Free','Stable','More raw angular movement.','More correction of tiny changes.','Too high can feel sticky.'),'degrees':param(5,0,15,'degrees','Narrow','Wide','Only very small changes are stabilized.','A wider angular band is stabilized.','Wide bands may suppress intended corrections.')}},
 'controlled_dribble_response':{'category':CATEGORIES[2],'name':'Controlled Dribble Response','kind':'MODIFIER','inputs':['LEFT_STICK','R1'],'what_it_does':'Applies a selected left-stick response while R1 is physically held.','does_not_change':['Dribbling','Agility','Balance'],'example':'Tune close-control feel without generating R1.','downside':'An extreme curve may feel inconsistent when releasing R1.','conflicts':[],'parameters':{'strength':param(55,0,100,'percent','Subtle','Strong','Smaller change from base response.','Stronger response shaping.','Use the smallest useful change.')}},
 'through_pass_response':{'category':CATEGORIES[1],'name':'Through Pass Aim Response','kind':'MODIFIER','inputs':['LEFT_STICK','TRIANGLE'],'what_it_does':'Shapes left-stick response while Triangle is physically held; it does not aim for a teammate.','does_not_change':['Passing attributes','Vision'],'example':'Fine directional adjustments before a through pass.','downside':'Strong shaping can make other movement during the hold feel different.','conflicts':[],'parameters':{'strength':param(45,0,100,'percent','Subtle','Precise','Closer to base stick response.','More fine directional response.','High is not inherently more accurate.')}},
 'cross_response':{'category':CATEGORIES[1],'name':'Cross Aim Response','kind':'MODIFIER','inputs':['LEFT_STICK','SQUARE'],'what_it_does':'Shapes left-stick response while Square is physically held.','does_not_change':['Crossing attribute','Curve'],'example':'More deliberate cross direction input.','downside':'May feel slower if over-tuned.','conflicts':[],'parameters':{'strength':param(40,0,100,'percent','Subtle','Precise','Closer to base response.','More center precision.','Excess precision may slow large corrections.')}},
 'shot_response':{'category':CATEGORIES[0],'name':'Shot Input Response','kind':'MODIFIER','inputs':['CIRCLE'],'what_it_does':'Provides controller-side shot input handling without claiming stronger in-game attributes.','does_not_change':['Shot Power','Finishing','Long Shots'],'example':'Consistent physical shot-button handling.','downside':'Timed behavior can conflict with deliberate manual timing if enabled.','conflicts':['timed_shot_legacy'],'parameters':{'strength':param(25,0,100,'percent','Manual','Assisted feel','Minimal controller-side shaping.','More controller-side shaping.','Prefer low values until tested in game.')}},
 'jockey_response':{'category':CATEGORIES[3],'name':'Jockey Response','kind':'MODIFIER','inputs':['LEFT_STICK','L2'],'what_it_does':'Shapes movement only while physical L2 is held; never detects defending or creates L2.','does_not_change':['Defensive Awareness','Pace','Strength'],'example':'Tune manual jockey micro-movement.','downside':'Aggressive shaping can over-correct positioning.','conflicts':[],'parameters':{'strength':param(45,0,100,'percent','Natural','Responsive','Closer to base movement.','Stronger jockey-specific response.','Manual positioning remains decisive.')}},
 'sprint_response':{'category':CATEGORIES[4],'name':'Sprint Response','kind':'MODIFIER','inputs':['LEFT_STICK','R2'],'what_it_does':'Shapes movement while physical R2 is held.','does_not_change':['Pace','Acceleration'],'example':'Tune directional feel while sprinting.','downside':'Strong curves can feel abrupt.','conflicts':[],'parameters':{'strength':param(35,0,100,'percent','Natural','Aggressive','Closer to base movement.','Stronger sprint-specific response.','Does not make the footballer faster.')}},
 'goalkeeper_stick':{'category':CATEGORIES[5],'name':'Goalkeeper Right-Stick Response','kind':'MODIFIER','inputs':['RIGHT_STICK','R3'],'what_it_does':'Optional right-stick response while configured goalkeeper modifier is held; NOREX cannot detect goalkeeper state.','does_not_change':['Goalkeeper attributes'],'example':'Manual local training for a chosen goalkeeper layout.','downside':'Wrong layout/context can make this irrelevant.','conflicts':[],'parameters':{'strength':param(40,0,100,'percent','Natural','Responsive','Closer to base RS response.','Stronger response shaping.','Enable only when it matches your controls.')}},
 'raw_compare':{'category':CATEGORIES[6],'name':'Raw vs NOREX Compare','kind':'UTILITY','inputs':[],'what_it_does':'Temporarily compares untransformed logical input with the selected NOREX processing profile.','does_not_change':['Controller transport','PS5 connection'],'example':'A/B test whether a helper actually feels better.','downside':'None; comparison results are subjective until game-tested.','conflicts':[],'parameters':{}},
}
for k,v in HELPERS.items():
 v['id']=k;v['learn_more']=v['what_it_does']+' '+v['downside'];v['guided_test']=['Enter a safe local practice mode.','Compare Raw input for 10 seconds.','Enable this helper and repeat the same movement.','Record Raw better, NOREX better, or Cannot tell.']

# Every advertised helper is implemented by the v2 engine. Timing parameters
# describe local filters only, never FC27 animation or shot timing.
from copy import deepcopy
import math

_EXPONENTS={'precision_stick':1.8,'outer_response':.7,'controlled_dribble_response':1.7,
            'through_pass_response':1.7,'cross_response':1.7,'shot_response':1.7,
            'jockey_response':1.6,'sprint_response':.75,'goalkeeper_stick':.8}
for _key,_exponent in _EXPONENTS.items():
    HELPERS[_key]['parameters']['exponent']=param(_exponent,.25,4,'ratio','Aggressive','Precise',
        'Reaches stronger output earlier when below one.','More fine control near center when above one.',
        'One is linear; extreme values change feel rather than attributes.')
HELPERS['shot_response'].update(inputs=['LEFT_STICK','CIRCLE'],
    what_it_does='Shapes left-stick magnitude only while the physical Circle button is held; no press, release or timing is generated.',
    example='Tune manual directional feel during a shot hold.',
    downside='Strong shaping can slow directional corrections.',conflicts=['through_pass_response','cross_response'])
for _key in HELPERS:
    h=HELPERS[_key]
    h.update(implementation='AVAILABLE',enabled_by_default=False,requires_arming=_key!='raw_compare',
             game_verification='UNVERIFIED',availability='All positions and archetypes',
             learn_more=h['what_it_does']+' '+h['downside'])

CONTEXT_ORDER=('shot_response','cross_response','through_pass_response','controlled_dribble_response','jockey_response','sprint_response')
for _key in CONTEXT_ORDER:
    HELPERS[_key]['conflicts']=list(dict.fromkeys([*HELPERS[_key]['conflicts'],*[x for x in CONTEXT_ORDER if x!=_key]]))
HELPERS['smoothing']['conflict_policy']='direction_stability wins when both are enabled'
HELPERS['direction_stability']['conflict_policy']='wins over smoothing'

def defaults():
    return {k:{'enabled':False,**{name:p['default'] for name,p in h['parameters'].items()}}
            for k,h in HELPERS.items() if h['kind']!='UTILITY'}

def validate_config(value):
    if not isinstance(value,dict) or set(value)-set(defaults()):raise ValueError('Unknown v2 helper')
    result=defaults()
    for key,row in value.items():
        if not isinstance(row,dict) or set(row)-set(result[key]):raise ValueError('Unknown v2 helper parameter')
        result[key].update(deepcopy(row))
    for key,row in result.items():
        if type(row['enabled']) is not bool:raise ValueError('Helper enabled must be true/false')
        for name,p in HELPERS[key]['parameters'].items():
            v=row[name]
            if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not p['min']<=v<=p['max']:
                raise ValueError(key+'.'+name+' must be finite and within its declared range')
    return result

def effective_config(value,armed=True):
    configured=validate_config(value); effective=deepcopy(configured); suppressed=[]
    if not armed:
        for key,row in effective.items():
            if row['enabled']:suppressed.append({'helper':key,'winner':'helpers disarmed'})
            row['enabled']=False
    elif effective['smoothing']['enabled'] and effective['direction_stability']['enabled']:
        effective['smoothing']['enabled']=False
        suppressed.append({'helper':'smoothing','winner':'direction_stability'})
    return configured,effective,suppressed
