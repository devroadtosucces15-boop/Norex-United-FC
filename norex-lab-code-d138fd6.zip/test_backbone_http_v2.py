"""Real HTTP integration tests using an isolated ephemeral localhost server."""
import json,tempfile,threading,unittest,urllib.request,urllib.error,copy
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
import lab

class HttpV2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work')
        cls.data=Path(cls.tmp.name)
        with patch.object(lab,'DATA',cls.data):cls.r=lab.Lab()
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),lab.Handler);cls.server.lab=cls.r
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.base='http://127.0.0.1:'+str(cls.server.server_port)
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join();cls.tmp.cleanup()
    def request(self,path,body=None,headers=None):
        req=urllib.request.Request(self.base+path,data=json.dumps(body).encode() if body is not None else None,headers=headers or {})
        try:
            with urllib.request.urlopen(req,timeout=3) as response:return response.status,json.load(response),response.headers
        except urllib.error.HTTPError as e:return e.code,json.load(e),e.headers
    def test_all_get_routes_freeze_json_envelopes(self):
        for path in ('fc27','helpers','effective','skills','comparison','profiles','contracts'):
            status,data,headers=self.request('/api/v2/'+path)
            self.assertEqual(status,200,path);self.assertEqual(data['schema'],1);self.assertEqual(data['api_version'],2)
            self.assertEqual(headers['Cache-Control'],'no-store')
    def test_skill_search_rating_tba_and_readiness(self):
        status,data,_=self.request('/api/v2/skills?q=elastico&stars=5&ready=false')
        self.assertEqual(status,200);self.assertTrue(data['skills']);self.assertTrue(all(row['stars']==5 for row in data['skills']))
        _,data,_=self.request('/api/v2/skills?status=TBA')
        self.assertEqual(data['count'],0);self.assertTrue(all(row['recipe'] is None and not row['executable'] for row in data['skills']))
        _,data,_=self.request('/api/v2/skills?kind=juggling');self.assertEqual(data['count'],9)
    def test_invalid_filter_errors_are_structured(self):
        for query in ('stars=6','stars=nan','q=x&q=y','unknown=1','ready=1','status=VERIFIED'):
            status,data,_=self.request('/api/v2/skills?'+query)
            self.assertEqual(status,400,query);self.assertFalse(data['ok']);self.assertEqual(data['error']['code'],'INVALID_REQUEST')
    def test_reference_does_not_claim_ps5_receipt(self):
        _,data,_=self.request('/api/v2/effective')
        self.assertEqual(data['output']['ps5_receipt'],'UNVERIFIED');self.assertEqual(data['output']['game_receipt'],'UNVERIFIED')
        self.assertIn('configuration',data);self.assertIn('configured',data['helpers_v2']);self.assertIn('effective',data['helpers_v2'])
    def test_post_mode_changes_output_and_preserves_profile(self):
        before=copy.deepcopy(self.r.profile)
        status,data,_=self.request('/api/v2/action',{'action':'set_mode','mode':'RAW'})
        self.assertEqual(status,200);self.assertTrue(data['ok']);self.assertEqual(data['effective']['mode'],'RAW');self.assertEqual(self.r.profile,before)
        status,data,_=self.request('/api/v2/action',{'action':'set_mode','mode':'NOREX'});self.assertEqual(status,200)
    def test_invalid_post_preserves_state_and_reports_reason(self):
        before=copy.deepcopy(self.r.profile)
        for body in ({'action':'helpers_configure','helpers':{'jockey_response':{'enabled':True,'strength':101}}},{'action':'set_mode','mode':'RAW','extra':1},{'action':'unknown'},[],{'action':'skill_recipe_save','skill_id':'fake_turn','recipe':{},'local_only':True}):
            status,data,_=self.request('/api/v2/action',body)
            self.assertEqual(status,400);self.assertFalse(data['ok']);self.assertTrue(data['error']['message'])
        self.assertEqual(self.r.profile,before)
    def test_profile_save_load_v2_reports_complete_success(self):
        p=copy.deepcopy(self.r.profile);p['backbone_helpers']['precision_stick'].update(enabled=True,strength=63)
        status,data,_=self.request('/api/v2/action',{'action':'profile_save','name':'http_fixture','profile':p})
        self.assertEqual(status,200);result=data['effective']['profile_result'];self.assertEqual(result['operation'],'saved');self.assertEqual(result['name'],'http_fixture');self.assertTrue(result['saved_at']);self.assertEqual(result['snapshot_schema'],2)
        self.r.profile['backbone_helpers']['precision_stick']['strength']=5
        status,data,_=self.request('/api/v2/action',{'action':'profile_load','name':'http_fixture'})
        self.assertEqual(status,200);self.assertEqual(data['effective']['configuration']['backbone_helpers']['precision_stick']['strength'],63)
    def test_legacy_state_and_action_remain_available(self):
        status,data,_=self.request('/api/state');self.assertEqual(status,200);self.assertEqual(data['profile']['schema'],2)
        status,data,_=self.request('/api/action',{'action':'reset'});self.assertEqual(status,200);self.assertIn('metrics',data)
    def test_origin_and_host_restrictions_preserved(self):
        for headers in ({'Origin':'https://other.example'},{'Host':'other.example'}):
            status,_,_=self.request('/api/v2/effective',headers=headers);self.assertEqual(status,403)
            status,_,_=self.request('/api/v2/action',{'action':'set_mode','mode':'RAW'},headers=headers);self.assertEqual(status,403)
    def test_unknown_route_and_wrong_method(self):
        status,data,_=self.request('/api/v2/made-up');self.assertEqual(status,404)
        status,data,_=self.request('/api/v2/effective',{'action':'set_mode','mode':'RAW'});self.assertEqual(status,404)

    def test_single_console_and_legacy_redirect_are_local_and_available(self):
        for path,content_type,marker in (
            ('/','text/html',b'Your NOREX controls'),
            ('/lab','text/html',b'SINGLE COMMAND CENTER'),
            ('/legacy','text/html',b'url=/lab'),
            ('/ui/app.js','text/javascript',b'/api/center'),
            ('/ui/style.css','text/css',b'@media')):
            with urllib.request.urlopen(self.base+path,timeout=3) as response:
                self.assertEqual(response.status,200)
                self.assertIn(content_type,response.headers['Content-Type'])
                self.assertIn(marker,response.read())
        for path in ('/ui/../data/startup-profile.json','/ui/unknown.js'):
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.urlopen(self.base+path,timeout=3)
            self.assertEqual(error.exception.code,404)
