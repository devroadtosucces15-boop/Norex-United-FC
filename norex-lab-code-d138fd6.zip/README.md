# NOREX Network and Controller Center

Current address: http://127.0.0.1:8790/. Open **Network Console** at `/network` or **Controller Lab** at `/lab`.

## Master buttons (installed 2026-10-11)

Each UI has one master ON/OFF button. Network Console uses the fixed button at the top. Controller Lab uses **Controller + Remote Play** in its header. ON restores the saved setup and starts exactly one managed system service for that tool. OFF restores its defaults, stops that service and its owned helpers, and leaves the other tool alone.

- Controller service: `norex-controller-managed.service`. It runs the unprivileged controller engine plus its owned Chiaki child. OFF neutralizes and destroys the virtual controller, cancels recording/replay/helpers, and closes only Lab-owned Remote Play sessions. Successful setting changes and OFF save a complete atomic setup in `data/master-saved.json`, separate from named profile archives and the default OFF startup profile. Section switches and their suspended values survive service restarts. Connect the physical DualSense to Kali first, ideally by USB. The registered PS5 must be awake and discoverable. Missing prerequisites fail OFF with a local explanation. Direct PS5 Bluetooth reconnection remains a physical action: press PS; this app cannot guarantee it.
- Network service: `norex-network-managed.service`. One supervisor owns the constrained root broker, unprivileged network engine, and its packet readers. OFF stops captures and removes only the broker-owned temporary queue/VPN changes. Normal shared internet forwarding stays available. Saved automation preferences are retained separately from the default OFF settings; ON restores them. Existing match protections and bounded trial timers still apply.
- Control page: `norex-master-portal.service`, enabled at boot. This small loopback-only control surface stays available when both tool services are OFF. It does not run controller processing, Chiaki, packet collection or automatic network trials. Root-owned installed code performs only fixed service operations and proxies the two loopback backends. The historical `norex-center.service` name aliases this control page so old launchers reuse it.

Both managed engines start OFF after boot. Network engine failures restart one supervised instance and recover owned temporary network state. Controller crashes fail safely OFF: the service group removes its helpers and the kernel removes its virtual device; press ON to reconnect. Closing Remote Play or losing the controller also turns Controller Lab OFF. Refreshes and other tabs read server state rather than making new processes.

DEV_WORK UUID `270f1795-e1d3-4e87-85c8-c0bc729f2a07` must be mounted. Canonical code remains here; Gateway backend/history stay under `/mnt/DEV_WORK/projects/norex-ps5-gateway`. No folders were relocated. Rollback source/unit snapshots are in `work/master-20261011/`; the old service definition is backed up there. Older standalone service instructions below are historical and superseded.

Use the UI buttons for everyday operation. This directory's `labs start` opens/reuses the control service, `labs on`/`labs off` control Controller Lab, and `labs status` reads its state. If the page is unavailable after attaching the USB, run `labs start` from this directory; local administrator authentication may be needed to restart the control service. No ChatGPT connection is required.

Validation: see `MASTER_BUTTONS.md` for the actual live results and hardware limits. PS5/game input receipt remains unverified.

---

The earlier standalone Lab documentation below describes controller capabilities. Its standalone launch/service instructions are superseded by the combined service above.

# NOREX Controller Lab

Standalone local DualSense lab for Kali PC ME2001. Project/data live on mounted KaliStorage at `/home/mrsuccess/ExtraStorage/projects/norex-controller-lab`. No packages or build required: Python 3 standard library only. Independent of PS5 Gateway and unrelated NOREX repositories.

Dashboard: http://127.0.0.1:8790

## Run and storage

The transient user service `norex-controller-lab.service` is running. It survives this chat, but is not enabled at boot. Stop it with `systemctl --user stop norex-controller-lab`.

After reboot, verify the USB is mounted before running:

```
findmnt -T /home/mrsuccess/ExtraStorage
python3 /home/mrsuccess/ExtraStorage/projects/norex-controller-lab/lab.py
```

Expected filesystem UUID: `e9b830a8-ba46-419d-a240-53bff5ca7227`. Do not run if only the underlying internal-disk directory is present. `--port` selects another local port. The service binds only to loopback and checks HTTP Host/Origin; it should never be exposed publicly. It runs as the desktop user, never root.

## FC27 first profile

`data/profile-fc27.json` is created if absent and loaded on startup. Defaults are 8% radial stick dead zone, 2% trigger dead zone, linear curves, identity button/axis mappings, no inversion, no calibrated centers/ranges, and all optional input assists disabled. This is a conservative local test baseline, not an EA-certified tuning preset or proof of FC27 gameplay compatibility. The previous `baseline` profile and schema-1 captures are preserved. Old profiles load through schema migration; saves use schema 2.

Use the editor to select linear, power, smoothstep or custom monotonic piecewise curves for each stick and the triggers. Power exponent is 0.25–4; custom points must start at 0:0, end at 1:1, increase in input and never decrease in output. The plot previews the curve after dead-zone scaling. Apply response/mappings first, then save under a profile name. Unsaved settings are session-only.

Button mappings can target another gamepad button or Disabled. Multiple sources mapping to one destination use held-state OR logic. Stick axes can be permuted and destination axes inverted. Triggers and D-pad retain their own axis roles; no keyboard/mouse mapping or turbo is implemented. Named local skill recipes are available in the assist panel.

Pipeline: kernel raw state -> center/range normalization -> radial stick/trigger dead zone -> response curve -> axis/button remap -> optional explicitly armed FC27 input assists/skill recipe -> complete processed frame -> dashboard / frame recorder / optional virtual output.

## Calibration and drift

Center: put the controller down, leave sticks untouched for 10 seconds, then review the means, ranges and standard deviations. Sampling targets 50 Hz and includes unchanged states. Suggested dead zone is the 99th percentile uncorrected resting radius plus .02, capped at .5; it is not applied automatically. It is not a controller-wear diagnosis.

Range: rotate both sticks fully and cycle both triggers during the 10-second window. An axis range is accepted only when travel covers at least half its kernel-reported span, to reject idle noise. Incomplete travel still cannot establish full range. Calibration updates analysis settings, not the controller firmware. Stop frame recording/replay before editing profiles or calibrating.

## Recording, export and replay

Raw recording keeps schema-1 kernel events for diagnostics. Complete-frame recording uses schema 2 and records already transformed axes and buttons with relative monotonic timestamps, source/sequence, profile/device metadata, neutral start/end states and an end reason.

Choose Record complete frames, move controls, then Stop frame recording. Select the resulting file and Preview replay. Replay speed ranges from 0.25x to 2x. Preview never creates a virtual device. Replay displays all complete recorded states using their timestamps; it does not apply the current profile twice. The last state resets to neutral on completion/cancel. Large scheduler backlog stops replay instead of bursting obsolete input; lateness is shown as a scheduling diagnostic, not game latency.

Replay to virtual controller uses exactly one replay source; live input cannot simultaneously feed that same output. Frame recording and replay cannot run together. Incomplete/legacy/oversized recordings, missing neutral boundaries, bad axis/button values or timestamps are rejected. Complete-frame captures are limited to 10 minutes, 20 MiB and replay validation to 50,000 rows. Raw capture is limited to 20 MiB per file. The 200 MiB archive threshold blocks starting new recordings; nothing is automatically deleted.

JSONL logs and CSV conversions are available through dashboard links. Analysis JSON exports live state, profile, metrics and replay/output status. No upload or remote service is involved.

## Linux virtual output

Select local/single-player test mode, then Enable live virtual controller or Replay to virtual controller. Virtual output is off on startup and never restored automatically. The separate gamepad is named `NOREX Controller Lab Virtual`, uses BUS_VIRTUAL with a generic local identity, and advertises gamepad buttons, signed stick axes, triggers and D-pad. It does not impersonate a Sony device or implement rumble, haptics, adaptive triggers, touchpad or gyro output.

Physical input is not grabbed. Applications can see both physical and virtual gamepads: select one device in the local application to avoid duplicate input. Game/device recognition depends on the application. There is no automatic FC27 launcher, game integration, console connection or game-specific driver installed.

Stop replay & output is the emergency control. Stop, disconnect, input queue overrun, output failure and normal shutdown release controls and destroy the virtual device. Opening/closing the device creates/destroys its Linux input node. Capture discovery selects only physical Sony 054c:0ce6 devices, avoiding feedback from the virtual device.

This session's operator granted current-user access to `/dev/uinput` using:

```
sudo setfacl -m u:$(id -u):rw /dev/uinput
```

That ACL is temporary and may disappear on device recreation or reboot. No persistent udev rule, broad input-group membership or service elevation was installed. If access is absent, the dashboard disables virtual start controls. To revoke the grant:

```
sudo setfacl -x u:$(id -u) /dev/uinput
```

`python3 uinput_smoke.py` creates only a neutral gamepad, verifies neutral axis/button state via evdev, and verifies teardown. It does not press controls. Mock tests verify active values and frame packets.

## Timing and verification

Kernel EVIOCSCLOCKID requests monotonic event timestamps; realtime fallback is explicitly labeled. The metric window covers 4096 intervals between Linux SYN_REPORT frames containing changes. It reports mean, p50/p95/p99, jitter and reciprocal mean frequency. An idle controller may emit sparse events; this is not transport polling rate, transport latency or end-to-end game latency. Dashboard refresh is independent at 10 Hz.

`python3 -m unittest -v` runs 30 focused Python tests, including curves, remap collisions, inversion, calibration, profile migration, invalid/incomplete replay rejection, neutral endpoints/timing, mocked uinput packets/teardown, source exclusion and disconnect handling. Real hardware and HTTP/browser checks are separate.

Verified in this session: physical DualSense capture; curve/remap editor apply/restore/save; complete-frame record and JSONL/CSV export; preview replay; actual uinput registration/neutral state/teardown; actual physical passthrough and replay to uinput; emergency stop. FC27 gameplay and every physical control's full travel remain operator checks, not claims from software tests.

No PS5 authentication/security bypass, console-authentication emulation, anti-cheat workaround or online replay integration is implemented. Recording/replay and virtual output are intended for local/single-player tests.

Kernel references: https://docs.kernel.org/input/event-codes.html and https://docs.kernel.org/input/uinput.html.

## FC27 input assists and skill recipes

The local assist panel implements independent input behaviors described at https://www.cronuszencentral.com/library/ea-fc-27-corex-flick. No proprietary script was downloaded/copied. The referenced page calls several holds “Perfect”; Lab controls are labeled timed pass/cross/shot because fixed input durations cannot predict outcomes. Configure features, Apply assist settings, Save profile, select local/single-player test mode, then Arm local assists. Arming is session-only and does not turn on virtual output. Defaults remain off. Stop replay & output also disarms/cancels assists. Profile application resets the assist engine and disarms it; disconnects and output failures disarm it too.

Timing holds release after 50–500 ms and do not re-trigger while a physical button stays held. Sprint strength is 0–100%. Precision pass adds R1 with the configured pass action. Dribble adds R1 during movement when action/sprint conditions are absent. Jockey supplies L2 when attack/sprint inputs are absent; this does not detect real possession or defending state. Sprint-triggered flick uses the current movement vector. Low-driven follow-up uses configurable second-press delay/duration; select which existing shot modifier combinations qualify. L1-only chip-style shots are excluded, matching EA’s current low-driven guidance at https://help.ea.com/en/articles/ea-sports-fc/how-to-shoot/. Auto power adds L1+R1 during shot input. Power aim uses a fixed manually chosen screen direction, not target tracking. Angle conventions: right 0°, down 90°, left 180°, up 270°; 0 disables power aim. Action buttons default to Classic-style Cross pass, Square cross, Circle shot and can be changed.

Normal right-stick flicks select one of four Skill slots; held L1+R1 plus a flick selects one of four Flex slots, with nine named Flex choices. A flick latches until the stick returns near center. A currently running recipe is not retriggered. Recipes use a maximum of 128 steps and 10 seconds; each step declares duration, axis values and button states. Only declared controls are overlaid; their state releases when the recipe ends. Relative recipes use the manually supplied facing angle. No game/player-facing/skill-star state is read.

The reference exposes 84 distinct skill names. 57 have independent editable training templates based on the older public EA controls at https://www.ea.com/able/resources/fifa/fifa-22/ps4/skill-moves, with chosen Lab timings. They are explicitly FC27-unverified. The 27 other labels have no input recipe and remain blocked; load a label in the editor, supply a valid recipe from your game’s controls, or import a trimmed local complete-frame recording. Names with no recipes are not represented as working functions. Verify moves in Practice Arena. The import includes all captured axes/buttons; inspect the recipe before running it, as those declared controls are overridden for its duration. Edited/recorded recipes persist in data/skill-recipes.json separately from profiles.

Visual options adapt the reference device-menu concepts to this browser dashboard: dark/light theme, brightness 1–10, idle dim 10–60 seconds, border style, focus style, progress style, layout and 2–5 visible recipe-list rows. Apply/save with the profile. They do not control Cronus hardware. Idle dimming does not stop capture, so stop/disarm input separately when needed.

The assist scheduler targets updates every 10 ms while armed; physical change frames can arrive in between. A scheduler gap over 200 ms cancels pending synthetic timers/recipes. This is a local input scheduler, not an assurance of game responsiveness. Recordings preserve processed assisted frames and profile settings; replay does not run assists again. Edited curves/mappings apply before assists; set action-button labels to the resulting layout.


## V3 reference enhancements

Reference: https://www.cronuszencentral.com/library/ea-fc-27-v3 . Independent additions:

- Two button skill bindings: select a distinct physical trigger and recipe for each. Triggers are consumed while armed and edge-latched until release. Empty recipes report an error message rather than inventing a move.
- One-button player lock: choose a distinct trigger; emits L3+R3 for the configured 20–200 ms, default 80. Held triggers never repeat. Actual game player-lock availability is a game setting/operator check.
- Finesse finish: adds R1 to shoot and emits one second press after release, with configurable delay 20–1000 ms, default 180. Timing is operator-tuned and cannot promise a successful finish. Mutually exclusive with low-drive/power automation. Existing shot hold can be enabled separately.
- Controller draft editing: Enter controller settings mode closes output, stops replay/recording and disarms. D-pad left/right selects a numeric assist setting; L2 plus left/right changes one unit; L2 plus up/down changes ten, bounded to valid limits with 200 ms repeat. Circle exits. This browser mode only edits drafts; Apply then Save profile commits them. Mode exits if output/assists/recording/replay becomes active or the device disconnects. Browser sampling is 100 ms, so very quick taps can be missed.
- 41 additional normalized V3 move slots, bringing the combined catalog to 125. 57 older EA training templates remain; 68 labels require user-provided or recorded recipes. Directional variants and combo aliases from the V3 marketing list do not imply verified sequences. Ea Ping and other undefined generic labels are not implemented: the page supplies no behavior to validate.

All new bindings/toggles default disabled. The saved FC27 baseline is disabled; output is off. Run `node test_controller_edit.js` for the additional settings-mode checks (selection, adjustment, clamp, exit, output guard). 30 Python tests cover the engine, profile rules and previous functions. Browser apply and settings-mode entry were verified; physical D-pad editing and in-game FC27 outcome remain unverified.


## Current FC27 default and compatibility update

Supersedes the earlier disabled-baseline and mutually-exclusive configuration notes above: the operator requested all assist toggles ON. All 12 toggles and all low-driven shot-type selections are now saved enabled, with valid default numeric values. FC27 has arm_on_startup=true: saved assists arm once on the first physical connection after service startup, for local processed preview. Emergency stop/disarm continues to stop the session; it does not automatically rearm on reconnect. Virtual output never starts automatically.

Response normalization, dead zones, curves and remapping compose before assists. Apply retains an already armed session, cancels pending synthetic operations and primes the new mapped held state to avoid accidental input edges. Arm applies the current draft atomically. Save applies and persists the current draft while retaining arming; editing remains blocked during complete-frame recording/replay. Assist action labels refer to the mapped controller layout.

Shot routing when all switches are enabled: physically holding mapped R1 without L1 at shot start selects finesse and its configured follow-up; that shot suppresses automatic power modifiers and low-drive scheduling. Other shots retain enabled automatic power/low-drive behavior. One second-press sequence is scheduled per shot, including when both low-drive switches are enabled. Fixed-angle power direction remains 0 (off) unless a valid direction is supplied; no facing or aiming direction is invented.

32 Python tests and controller-edit checks passed. Browser Apply with a temporary power response curve retained ARMED state; Save restored the original linear curve and retained ARMED state. Numeric defaults: sprint100%, holds pass200/cross300/shot150 ms, finesse delay180 ms, follow-up delay80/press40 ms, flick80 ms, lock80 ms, manual facing270 degrees. Screenshot values outside allowed ranges (0 holds,500% sprint,5000 degree angles) were replaced with valid defaults. Actual FC27 outcomes remain unverified.


## Output architecture and delivery proof (2026-10-05)

`output_backend.OutputBackend` defines emit, neutralize, close and structured status.
UInputOutput retains its existing generic Linux identity and implements this contract.
Runtime accepts an output factory so lifecycle tests and future explicitly supported
transports do not depend on Linux uinput. Constructor creates/neutralizes the device;
close releases controls and destroys it. Only one source may own output at a time.
Successful frame writes mean local backend acceptance, never console/game receipt.
The API and dashboard show backend, destination, transport, connection, local frame
count and separate PS5/game receipt fields. Receipt remains unverified.

Delivery test: stop recording/replay/output, select local/single-player use, then
Start 60-second remap test. This disarms assists and cancels pending startup arming
for the session without changing the saved profile. Only manually held physical
Cross and Square are exchanged; all other buttons and axes are neutral. No timed
macro, automatic shot or gameplay assist is emitted. Other runtime actions are
blocked until Stop delivery test or emergency stop. Disconnect, failure, expiry
(including idle expiry), shutdown and stop close/neutralize the backend. Test mode
is never persisted or auto-started.

First select NOREX Controller Lab Virtual in a local controller viewer and observe
Cross producing Square and release returning neutral. For end-to-end proof, select
that same virtual device in a chosen legitimate transport, use an offline game
practice session, press Cross/Square manually and observe the corresponding swapped
action in the actual game. Record client/version, selected device, game/control
layout and observed press/release. Dashboard counters cannot establish this proof;
physical and virtual inputs must not both reach the receiver. No PS5/FC27 delivery
has been demonstrated in this change.

Delivery options checked against primary documentation:
- Sony PS Remote Play on Windows/macOS with a supported physical DualSense and
  the user's PlayStation sign-in/console setup. This is an officially supported
  console-control route, but does not validate Linux uinput or transformed Lab
  delivery: https://www.playstation.com/en-si/support/games/playstation-remote-play-on-pc-and-mac/
- chiaki-ng on Linux is a third-party Remote Play client, not Sony-supported.
  Its SDL controller support makes it a candidate for local virtual-gamepad testing;
  compatibility/mapping must be demonstrated before using it as a Lab transport.
  Authorized console registration/account identification or sign-in remains a
  user step. https://github.com/streetpea/chiaki-ng/blob/main/docs/setup/controlling.md
  https://streetpea.github.io/chiaki-ng/setup/
No client has been installed or console registered here. No Sony security,
authentication emulation, hardware bridge or anti-cheat bypass was added.

Rollback: work/rollback-output-20261005-103632 contains original source/dashboard,
profiles and recipes plus SHA-256 manifest. Stop only norex-controller-lab.service,
restore those files to matching relative paths, remove output_backend.py and
test_output_backend.py, then restart only that Lab service. New captures are left
untouched. Restoring profiles is optional because this update never edits them.


## Media controls and quick connect

Remote Play media controls edit only chiaki-ng's audio_video_disabled preference:
0 both enabled, 1 audio off, 2 video off, 3 both off. Saves require chiaki-ng closed
and output/replay stopped, create a private rollback backup and replace config
atomically. Registration/credentials are never included in the API response.
Open & connect chiaki-ng uses the verified Lab launcher, the sole registered
console nickname and local host 10.42.0.30. It retains the explicit SDL mapping and
physical DualSense exclusion. A running process blocks duplicate launch. A new
process does not itself prove connection or input receipt. This fixed local-host
shortcut is specific to the current console; other networks need configuration.
The button never enables Lab output or assists.

Browser invalid numeric drafts are highlighted and block Apply/Save/Arm. Reload
active profile resets the editor to actual validated settings. Individual tests
cover every assist toggle's input effect and timing release, not FC27 outcomes.
At sprint strength 100%, full sprint is unchanged; power aim 0 is off; disabled
lock/skill bindings produce no behavior; 68 named recipe slots remain unconfigured.
Auto jockey/dribble cannot know possession or defending state. Follow-up timings
need manual tuning and observation in offline FC27 practice.

## Input Profiler pages and helper switches
The main Input Profiler page owns controller enable/disable, Remote Play media, FC27 response/mapping, helpers and save/load. Tests & Logs owns telemetry, calibration, timing, delivery testing, capture, replay and raw diagnostics. More game tabs can be added later.
Helper checkboxes now update the active session immediately via set_assist_enabled; Save profile persists them. Turning helpers off clears pending generated actions and sends manual input through the existing controller. Loading a saved profile turns helpers off. Fixed shot/pass/cross holds are button-duration overrides, not timed finishing. Finesse follow-up is labelled as a low-driven second press. Precision shooting must be selected inside FC27. Advanced shortcuts and all recipes remain available but gameplay outcomes are unverified.

## Advanced FC27 options
`advanced.py` adds opt-in context-specific aiming curves, separate stick dead zones and per-trigger curves. Analog response is part of normal profiling; contextual aim, digital trigger helpers and action shortcuts require Helpers ON. Manual Defending mode can gate automatic L2 hold and enable a separate right-stick switching curve. Modes/latches reset on disconnect and output shutdown; Helper OFF clears generated actions while retaining manual output.
Shortcuts: finesse, chip, power, low-driven, controlled sprint, curved run, pass-and-follow, player lock, precision aim clutch. Bind unused remapped buttons; physical trigger buttons are consumed on both analog and digital channels if assigned. Hold shot shortcuts to choose power yourself. Run/lock shortcuts are bounded taps. Controlled-sprint toggle expires after ten seconds and scheduler gaps cancel pending activity. Precision clutch uses the shooting curve without firing. Duplicate/legacy conflicts and old automatic shot conflicts are rejected. Low-driven shortcut is a normal shot plus one second press; it does not select shot power or aim from game state.
Existing profiles migrate with all new options disabled. Save profile stores the settings. Profile loading safely turns helpers off and resets manual game mode. Independent stick dead zones replace the global radial zone for their respective sticks; curves preserve direction. In-game Precision Shot Assistance, Analog Sprint and switching settings must be selected in FC27 itself.
Tests & Logs includes A/B input summaries, bounded to 30 seconds and eight in-memory results. Repeated scheduler ticks do not inflate changed-input-frame counts. Changing profile/helper settings ends the current sample. Export analysis JSON preserves summaries and settings snapshots; results are not PS5 latency or gameplay measurements.
Validation: 77 Python tests plus JavaScript controller-editor and dashboard syntax checks.


### Play modes and skill mappings
Play Modes contains three independent editable full profiles: Defender, Creator and Finisher. Select a mode, edit Input Profiler, apply, then save the current settings to that mode. Controller mode hotkeys are off by default and require Helpers on. Default hotkeys hold both triggers plus D-pad Left/Up/Right for 250 ms. Recognized hotkeys consume their D-pad and trigger input. Profiles and combinations persist in data/play-modes.json. Switching cancels existing helper sequences.

Skill Mappings provides a six-move advanced pack and editable modifier + D-pad bindings. Apply resolves duplicate bindings and bindings reserved by existing helper shortcuts or single-trigger mode combinations, reporting every reassignment. It rejects moves without a recipe and makes no changes if no free combination exists. Recipes remain training templates until tested in the offline practice arena; the catalog is not a claim of complete verified FC27 coverage. The existing recipe editor and capture importer remain available.

Additional response settings include outer stick saturation, per-shot-type aiming exponents, clutch context and a 0–40 ms modifier lead for shot shortcuts. No game mechanics or latency guarantee is implied. Host button-release diagnostics are returned separately from console receipt.


### Helper filters and visible skill library
Input Profiler includes helper-type filters (Defending, Creating/passing, Finishing/shooting, Dribbling/movement and Skill shortcuts), plus buttons to load saved Defender/Creator/Finisher full presets. Filtering only changes visibility, retaining all active settings; preset loading replaces the profile explicitly. Skill Mappings now shows a searchable recipe library, defaults to entries with actual input steps, and filters the six advanced preset moves or juggling skills. Missing recipes remain visible through an explicit filter. Mapping selectors exclude missing sequences; legacy saved choices are retained without silently replacing them. The recipe editor defaults to ready entries and has an explicit all-names option for authoring.


### Live input console and Lab power
The top black console shows physical inputs, activated input settings, the final writer for changed controls, and yellow warnings when multiple settings write the same control or compete for an aiming context. A recent-history panel and /api/inputlog download expose the local JSONL audit. Records include preset, helper/power state and host-output status. Logging caps history at 100 rows, limits repeated stick-position samples to five per second, logs button/direction changes promptly, and rotates files at 2 MiB, keeping one previous file. This describes host processing, never proven PS5 receipt.

The top Lab power switch bypasses all user curves, dead zones, remaps, helpers, skill and mode combinations when OFF; it retains the physical output connection and keeps settings visible/editable. ON applies the selected custom settings and helpers together, without individually re-enabling each option. Power state persists in data/lab-controls.json. It does not reset FC27's in-game settings or set an EA-certified profile. Replay, recording and delivery tests must be stopped before changing power.

The top preset selector displays selected and currently active settings. No preset restores the personal profile captured before choosing a preset. Presets do not detect game possession or constrain which game actions may be attempted. EA player PlayStyles are not observable from controller inputs.

Manual Circle/Square priority defaults ON. It restores those physical buttons and L1/R1/L2/R2 modifiers and cancels pending generated sequences while Circle/Square is held, in every preset. This protects physical tackle/shot/cross buttons, including from consuming bindings and fixed durations. Consequently physical shot/cross helper automation is overridden; dedicated shortcut buttons still provide automation. Disable this explicit option if you intentionally want the helpers to control physical Circle/Square, and validate offline.


## 2026-10-06 implementation update

Current navigation is Overview, Helpers, Skills, Controller, Profiles and Advanced. New opt-in response helpers live in helpers.py; all default OFF. Skills now separate source evidence from executable recipe readiness. There are 139 historical/reference entries, 26 sourced/reported star requirements, 113 requiring current confirmation, 57 existing game-unverified recipes and 82 entries without configured recipes. This is not complete verified FC27 coverage.

Named profile saves use snapshot_schema 1 and atomically include the validated main profile, recipe definitions, mode profiles/bindings and preset selection/base profile. Legacy flat profiles still load. Loading disarms helpers and cancels generated work; session output, transport and Lab power are excluded.

Validation: 111 deterministic Python tests, JavaScript controller-editor tests, dashboard syntax checks and browser save/change/load restoration passed. Local neutral uinput output and physical capture were verified; PS5/Remote Play receipt and FC27 gameplay remain unverified. Later intelligence/conflict/logging expansion is deferred until gameplay testing.
