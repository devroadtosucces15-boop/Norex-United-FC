"""Profile completeness, migrations, failures and recording round trips."""
import copy,json,os,tempfile,unittest,concurrent.futures
from pathlib import Path
from unittest.mock import patch
import lab
from profile_store import snapshot,validate_snapshot,write_atomic,SNAPSHOT_SCHEMA
from pipeline import default_profile,neutral_frame
from recording import FrameRecorder,ReplaySource
from backbone.actions import act

class ProfileV2Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent/'work');self.addCleanup(self.tmp.cleanup);self.data=Path(self.tmp.name)
        with patch.object(lab,'DATA',self.data):self.r=lab.Lab()
    def restarted(self):
        with patch.object(lab,'DATA',self.data):return lab.Lab()
    def test_save_mutate_load_restart_named_complete_v2(self):
        p=copy.deepcopy(self.r.profile);p['backbone_helpers']['precision_stick'].update(enabled=True,strength=72,exponent=2.3)
        p['backbone_skills']['recipes']['ball_roll_left']={'relative':True,'steps':[{'ms':70,'axes':{'RX':-.5},'buttons':{}}]}
        p['backbone_skills']['bindings']=[{'trigger':'R1 + D-pad left','skill':'ball_roll_left'}]
        p['visual']['theme']='light';p['arm_on_startup']=True
        self.r.action({'action':'save','name':'named_profile','profile':p})
        saved=snapshot(self.r,self.r.profile)
        self.r.profile=default_profile();self.r.mode_bank.profiles['Creator']['deadzone']=.3
        self.r.action({'action':'load','name':'named_profile'})
        for r in (self.r,self.restarted()):
            restored=snapshot(r,r.profile)
            for field in ('profile','skill_recipes','mode_bank','selection','scope'):self.assertEqual(restored[field],saved[field],field)
            self.assertFalse(r.assists_armed);self.assertFalse(r.startup_arm_pending);self.assertIsNone(r.output)
        self.assertTrue((self.data/'profile-named_profile.json').exists())
        self.assertEqual(json.loads((self.data/'profile-named_profile.json').read_text())['snapshot_schema'],2)
    def test_load_non_fc27_restores_recipe_and_modes_after_restart(self):
        self.r.skill_library.save({'name':'Stop And Go','relative':True,'steps':[{'ms':60,'axes':{'RX':.4},'buttons':{}}]})
        self.r.mode_bank.profiles['Creator']['deadzone']=.27
        self.r.action({'action':'save','name':'complete'})
        self.r.skill_library.save({'name':'Stop And Go','relative':True,'steps':[{'ms':80,'axes':{'RX':.7},'buttons':{}}]})
        self.r.mode_bank.profiles['Creator']['deadzone']=.1;self.r.mode_bank.persist()
        self.r.action({'action':'load','name':'complete'})
        restarted=self.restarted();self.assertEqual(restarted.skill_library.recipes['Stop And Go']['steps'][0]['ms'],60)
        self.assertEqual(restarted.mode_bank.profiles['Creator']['deadzone'],.27)
    def test_saved_active_mode_uses_edited_profile_and_preserves_base(self):
        base=copy.deepcopy(self.r.profile);self.r.select_mode('Creator')
        edited=copy.deepcopy(self.r.profile);edited['backbone_helpers']['through_pass_response']['enabled']=True
        self.r.action({'action':'save','name':'creator_fixture','profile':edited})
        self.assertEqual(self.r.mode_bank.profiles['Creator'],self.r.profile);self.assertEqual(self.r.base_profile,base)
        restarted=self.restarted();self.assertEqual(restarted.active_mode,'Creator');self.assertEqual(restarted.base_profile,base)
        restarted.select_mode('None');self.assertEqual(restarted.profile,base)
    def test_migrate_snapshot_one_without_losing_legacy_configuration(self):
        doc=snapshot(self.r,self.r.profile);doc['snapshot_schema']=1;doc['scope']={'legacy':'scope'}
        for profile in [doc['profile'],doc['selection']['base_profile'],*doc['mode_bank']['profiles'].values()]:
            profile.pop('backbone_helpers');profile.pop('backbone_skills')
        p,recipes,bank,selection=validate_snapshot(doc,self.r.mode_bank)
        self.assertIn('backbone_helpers',p);self.assertEqual(p['helpers'],self.r.profile['helpers'])
    def test_flat_profile_migration_saved_as_complete_startup(self):
        flat=copy.deepcopy(self.r.profile);flat.pop('backbone_helpers');flat.pop('backbone_skills');flat['schema']=1
        write_atomic(self.data/'profile-flat.json',flat);self.r.action({'action':'load','name':'flat'})
        self.assertEqual(self.restarted().profile,self.r.profile);self.assertEqual(self.r.profile_result['snapshot_schema'],0)
    def test_corrupt_migration_rejected_before_live_or_startup_changes(self):
        self.r.action({'action':'save','name':'good'});before=snapshot(self.r,self.r.profile);startup=(self.data/'startup-profile.json').read_bytes()
        for corrupt in ('skill_recipes','mode_bank','selection','profile'):
            doc=copy.deepcopy(before);doc[corrupt]=None;write_atomic(self.data/'profile-bad.json',doc)
            with self.assertRaises((ValueError,TypeError,KeyError)):self.r.action({'action':'load','name':'bad'})
            self.assertEqual(self.r.profile,before['profile']);self.assertEqual((self.data/'startup-profile.json').read_bytes(),startup)
    def test_failed_save_before_commit_preserves_disk_memory_and_no_tmp(self):
        self.r.action({'action':'save','name':'fail'});before=(self.data/'profile-fail.json').read_bytes();profile=copy.deepcopy(self.r.profile)
        changed=copy.deepcopy(profile);changed['deadzone']=.2
        with patch('profile_store.os.replace',side_effect=OSError('simulated rename failure')):
            with self.assertRaises(OSError):self.r.action({'action':'save','name':'fail','profile':changed})
        self.assertEqual((self.data/'profile-fail.json').read_bytes(),before);self.assertEqual(self.r.profile,profile)
        self.assertEqual(list(self.data.glob('.*.tmp')),[])
    def test_atomic_parallel_saves_are_complete_and_no_tmp(self):
        path=self.data/'parallel.json';documents=[{'id':i,'rows':[i]*1000} for i in range(12)]
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(lambda d:write_atomic(path,d),documents))
        actual=json.loads(path.read_text());self.assertIn(actual,documents);self.assertEqual(list(self.data.glob('.*.tmp')),[])
    def test_legacy_recipe_write_failure_preserves_memory(self):
        before=copy.deepcopy(self.r.skill_library.recipes)
        with patch('profile_store.write_atomic',side_effect=OSError('disk failure')):
            with self.assertRaises(OSError):self.r.skill_library.save({'name':'Stop And Go','relative':True,'steps':[{'ms':80,'axes':{'RX':.7},'buttons':{}}]})
        self.assertEqual(self.r.skill_library.recipes,before)
    def test_profile_with_many_recipe_steps_records_and_replays(self):
        p=copy.deepcopy(self.r.profile)
        p['backbone_skills']['recipes']['ball_roll_left']={'relative':True,'steps':[{'ms':50,'axes':{'RX':.5},'buttons':{}} for _ in range(128)]}
        self.assertGreater(len(json.dumps(p)),8192)
        path=self.data/'capture-20261006-1.jsonl';record=FrameRecorder(path,p,{});record.frame(neutral_frame());record.finish()
        source=ReplaySource(path);self.assertEqual(source.profile,p);self.assertTrue(all(not any(f.buttons.values()) for f in source.frames))
    def test_future_schema_and_boolean_version_rejected(self):
        doc=snapshot(self.r,self.r.profile)
        for version in (True,3,'2'):
            doc['snapshot_schema']=version
            with self.assertRaises(ValueError):validate_snapshot(doc,self.r.mode_bank)
    def test_disallowed_profile_name_cannot_escape_storage(self):
        for name in ('../outside','a/b','',None,False):
            with self.assertRaises(ValueError):self.r.action({'action':'save','name':name})

class StartupRecoveryTests(unittest.TestCase):
    setUp=ProfileV2Tests.setUp
    restarted=ProfileV2Tests.restarted
    def test_complete_startup_ignores_stale_corrupt_auxiliary_files(self):
        self.r.action({'action':'save','name':'authoritative'})
        for name in ('skill-recipes.json','play-modes.json'):(self.data/name).write_text('broken legacy auxiliary file')
        restarted=self.restarted();self.assertEqual(restarted.profile,self.r.profile)
        self.assertEqual(restarted.skill_library.recipes,self.r.skill_library.recipes)
    def test_interrupted_save_recovers_startup_selection(self):
        from profile_store import write_atomic as real_write
        def interrupted(path,document):
            if Path(path).name=='startup-profile.json':raise OSError('simulated interruption')
            return real_write(path,document)
        p=copy.deepcopy(self.r.profile);p['backbone_helpers']['precision_stick']['strength']=64
        with patch('profile_store.write_atomic',side_effect=interrupted):self.r.action({'action':'save','name':'recover','profile':p})
        self.assertTrue(self.r.profile_result['startup_recovery_pending']);self.assertEqual(self.r.profile_result['operation'],'saved')
        self.assertTrue((self.data/'pending-profile-save.json').exists())
        restarted=self.restarted();self.assertEqual(restarted.profile,self.r.profile)
        self.assertFalse((self.data/'pending-profile-save.json').exists())
    def test_uncommitted_recovery_journal_does_not_activate_profile(self):
        from profile_store import recover_save
        old=snapshot(self.r,self.r.profile);changed=copy.deepcopy(old);changed['profile']['deadzone']=.2
        write_atomic(self.data/'profile-uncommitted.json',old)
        write_atomic(self.data/'pending-profile-save.json',{'schema':1,'file':'profile-uncommitted.json','document':changed})
        recover_save(self.data);self.assertFalse((self.data/'startup-profile.json').exists());self.assertFalse((self.data/'pending-profile-save.json').exists())
    def test_invalid_journal_path_never_writes_outside_data(self):
        from profile_store import recover_save
        write_atomic(self.data/'pending-profile-save.json',{'schema':1,'file':'../outside.json','document':{}})
        with self.assertRaises(ValueError):recover_save(self.data)
