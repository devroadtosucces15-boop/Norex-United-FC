import unittest
from backbone.fc27_data import CONTROLS,SKILLS
class CatalogContract(unittest.TestCase):
 def test_tba_never_has_input(self):
  t=[r for r in SKILLS if r['input_status']=='TBA']
  self.assertEqual({r['name'] for r in t},set())
  self.assertTrue(all(r['ps5_input'] is None for r in t))
 def test_evidence_is_separate_from_game_verification(self):
  self.assertTrue(SKILLS)
  for r in SKILLS:
   self.assertIn(r['stars'],range(1,6));self.assertEqual(r['direction_reference'],'PLAYER_FACING')
   self.assertEqual(r['verification']['game'],'not_tested');self.assertTrue(r['sources'])
 def test_control_registry(self):
  self.assertEqual(CONTROLS['finesse_shot']['ps5_input'],'R1 + Circle')
  self.assertEqual(CONTROLS['sprint_jockey']['ps5_input'],'L2 + R2')
if __name__=='__main__':unittest.main()
