/* Cockpit: one console for fast in-game changes. Loaded before app.js; reads app.js globals only when called.
   Every control writes the same profile paths and actions the classic pages use, so nothing here changes what the Lab does. */
const cockpit=(()=>{'use strict';
const store={get(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v??d}catch{return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}};
const getPath=(o,p)=>p.split('.').reduce((n,k)=>n?.[k],o);
const cfg=()=>effective.configuration;
const commit=fn=>{const q=structuredClone(effective.configuration);fn(q);return act('configure',{profile:q})};
const B='backbone_helpers.',H='helpers.contexts.',A='assists.',X='advanced.contexts.';
const alt=(k,l,p,o={})=>({k,l,p,...o});
const nums=(...rows)=>rows.map(([l,p,min,max,step])=>({l,p,min,max,step}));

/* ---------- the goals: one row per thing you want, old and new engines folded together ---------- */
const PHASES=[['move','Movement','🏃'],['drib','Dribbling','⚽'],['pass','Passing & crossing','🎯'],['shoot','Shooting','🥅'],['def','Defending','🛡'],['gk','Goalkeeper','🧤'],['misc','Timing & extras','⏱']];
const GOALS=[
 {id:'filter',phase:'move',name:'Stick filter',tip:'Calms tiny left-stick wobble. Pick one: Smoothing softens motion, Direction lock holds angles steady. They cannot run together.',alts:[alt('smooth','Smoothing',B+'smoothing.enabled',{h:'smoothing'}),alt('lock','Direction lock',B+'direction_stability.enabled',{h:'direction_stability'}),alt('smooth_old','Smoothing · old','helpers.smoothing.enabled',{old:1}),alt('lock_old','Direction lock · old','helpers.direction_stability.enabled',{old:1})]},
 {id:'outer',phase:'move',name:'Outer stick speed',tip:'How quickly the stick reaches full push near the edge of its travel.',alts:[alt('new','New',B+'outer_response.enabled',{h:'outer_response'}),alt('old','Old','play_tools.outer.enabled',{old:1})]},
 {id:'sprintresp',phase:'move',name:'Sprint feel',tip:'Shapes left-stick response while R2 is held.',alts:[alt('new','New',B+'sprint_response.enabled',{h:'sprint_response'}),alt('old','Old',H+'sprint.enabled',{old:1})]},
 {id:'perfect_sprint',phase:'move',name:'Perfect sprint',tip:'Stored sprint input behaviour. Game effect depends on controls and context.',alts:[alt('on','On',A+'perfect_sprint',{nums:nums(['Strength %',A+'sprint_strength',0,100,1])})]},
 {id:'speed_boost',phase:'move',name:'Speed boost',tip:'Stored speed-boost input.',alts:[alt('on','On',A+'speed_boost',{nums:nums(['Boost ms',A+'boost_ms',20,300,1])})]},
 {id:'sprint_toggle',phase:'move',name:'Sprint toggle',tip:'Tap sprint once to keep sprinting, tap again to stop.',alts:[alt('on','On','advanced.sprint_toggle')]},
 {id:'sc_run',phase:'move',name:'Run shortcuts',shortcuts:['controlled_sprint','curved_run']},
 {id:'precision',phase:'drib',name:'Precision stick',tip:'Finer left-stick control near the centre; full travel is kept.',alts:[alt('on','On',B+'precision_stick.enabled',{h:'precision_stick'})]},
 {id:'cdr',phase:'drib',name:'Controlled dribble feel',tip:'A chosen left-stick response while you hold the controlled-dribble input.',alts:[alt('new','New',B+'controlled_dribble_response.enabled',{h:'controlled_dribble_response'}),alt('old','Old',H+'controlled_dribble.enabled',{old:1})]},
 {id:'fast_dribble',phase:'drib',name:'Fast dribble',tip:'Stored fast-dribble input behaviour.',alts:[alt('on','On',A+'fast_dribble')]},
 {id:'sc_drib',phase:'drib',name:'Dribble shortcut',shortcuts:['precision_clutch']},
 {id:'through',phase:'pass',name:'Through-ball aim',tip:'Left-stick response while aiming a through pass.',alts:[alt('new','New',B+'through_pass_response.enabled',{h:'through_pass_response'}),alt('old','Old',H+'through_pass.enabled',{old:1})]},
 {id:'cross',phase:'pass',name:'Cross aim',tip:'Left-stick response while aiming a cross.',alts:[alt('on','On',B+'cross_response.enabled',{h:'cross_response'})]},
 {id:'ctx_pass',phase:'pass',name:'Pass response',tip:'Reshapes stick response only while the pass button is held.',alts:[alt('on','On',X+'pass.enabled',{nums:nums(['Exponent',X+'pass.exponent',.25,4,.05])})]},
 {id:'ctx_cross',phase:'pass',name:'Cross response',tip:'Reshapes stick response only while the cross button is held.',alts:[alt('on','On',X+'cross.enabled',{nums:nums(['Exponent',X+'cross.exponent',.25,4,.05])})]},
 {id:'precision_pass',phase:'pass',name:'Precision pass',tip:'Stored precision-pass input.',alts:[alt('on','On',A+'precision_pass')]},
 {id:'timed_pass',phase:'pass',name:'Timed pass',tip:'Stored timed-pass input.',alts:[alt('on','On',A+'timed_pass',{nums:nums(['Press ms',A+'pass_ms',50,500,1])})]},
 {id:'timed_cross',phase:'pass',name:'Timed cross',tip:'Stored timed-cross input.',alts:[alt('on','On',A+'timed_cross',{nums:nums(['Press ms',A+'cross_ms',50,500,1])})]},
 {id:'sc_pass',phase:'pass',name:'Pass shortcut',shortcuts:['pass_follow']},
 {id:'shotmode',phase:'shoot',name:'Shot response or timing',tip:'Shot input response reshapes the stick while shooting. Timed shot is a stored shot sequence. They cannot run together.',alts:[alt('resp','Shot response',B+'shot_response.enabled',{h:'shot_response'}),alt('timed','Timed shot',A+'timed_shot',{nums:nums(['Press ms',A+'shot_ms',50,500,1])})]},
 {id:'shot_type',phase:'shoot',name:'Per-shot-type response',tip:'A different stick exponent for normal, finesse and power shots.',alts:[alt('on','On','play_tools.shot_response.enabled',{nums:nums(['Normal','play_tools.shot_response.normal',.25,4,.05],['Finesse','play_tools.shot_response.finesse',.25,4,.05],['Power','play_tools.shot_response.power',.25,4,.05])})]},
 {id:'ctx_shoot',phase:'shoot',name:'Shoot response',tip:'Reshapes stick response only while the shoot button is held.',alts:[alt('on','On',X+'shoot.enabled',{nums:nums(['Exponent',X+'shoot.exponent',.25,4,.05])})]},
 {id:'lowdrive',phase:'shoot',name:'Low driven',tip:'Stored low-driven shot. Pick one version.',alts:[alt('low','Low driven',A+'low_driven'),alt('perfect','Perfect lowdrive',A+'perfect_lowdrive')]},
 {id:'finish',phase:'shoot',name:'Finish style',tip:'Stored finesse finish or auto power shot. Pick one.',alts:[alt('fin','Finesse finish',A+'finesse_finish',{nums:nums(['Delay ms',A+'finesse_delay_ms',20,1000,1])}),alt('pow','Auto power shot',A+'auto_power_shot')]},
 {id:'shot_timing',phase:'shoot',name:'Shot follow-up timing',nums:nums(['Follow-up delay ms',A+'followup_delay_ms',20,300,1],['Follow-up press ms',A+'followup_press_ms',20,150,1],['Low-shot delay ms','advanced.low_delay_ms',20,300,1],['Low-shot press ms','advanced.low_press_ms',20,150,1])},
 {id:'sc_shoot',phase:'shoot',name:'Shot shortcuts',shortcuts:['finesse','chip','power','low_driven']},
 {id:'jockey',phase:'def',name:'Jockey feel',tip:'Shapes movement only while you physically hold jockey.',alts:[alt('new','New',B+'jockey_response.enabled',{h:'jockey_response'}),alt('old','Old',H+'jockey.enabled',{old:1})]},
 {id:'auto_jockey',phase:'def',name:'Auto jockey',tip:'Stored auto-jockey input.',alts:[alt('on','On',A+'auto_jockey')]},
 {id:'ctx_switch',phase:'def',name:'Switch-player response',tip:'Reshapes stick response only while the switch button is held.',alts:[alt('on','On',X+'switching.enabled',{nums:nums(['Exponent',X+'switching.exponent',.25,4,.05])})]},
 {id:'defonly',phase:'def',name:'Jockey only in Defender mode',alts:[alt('on','On','advanced.defense_only_jockey')]},
 {id:'sc_def',phase:'def',name:'Player lock',shortcuts:['player_lock'],nums:nums(['Lock ms',A+'lock_ms',20,200,1])},
 {id:'gk',phase:'gk',name:'Goalkeeper right stick',tip:'Optional right-stick response while controlling the goalkeeper.',alts:[alt('new','New',B+'goalkeeper_stick.enabled',{h:'goalkeeper_stick'}),alt('old','Old',H+'goalkeeper.enabled',{old:1})]},
 {id:'timing',phase:'misc',name:'Shortcut and mapping timing',nums:nums(['Shortcut tap ms','advanced.tap_ms',20,200,1],['Skill mapping dwell ms','play_tools.mapping_dwell_ms',0,500,1])},
 {id:'angles',phase:'misc',name:'Aim and facing angles',nums:nums(['Aim angle °',A+'aim_angle',0,359,1],['Facing angle °',A+'facing_angle',0,359,1])}
];
const toggles=()=>GOALS.filter(g=>g.alts);
const byId=id=>GOALS.find(g=>g.id===id);
const isOn=a=>!!getPath(cfg(),a.p);
const activeAlt=g=>g.alts?.find(isOn)||null;
const blocked=a=>{const g=GOALS.find(x=>x.alts?.includes(a)),own=new Set((g?.alts||[]).map(x=>x.p)),r=(effective.global_rules?.blocked?.[a.p]||[]).filter(c=>!(c.options||[]).every(o=>o===a.p||own.has(o)));return r.length&&!isOn(a)?r.map(c=>c.names.join(' + ')+': '+c.reason).join('\n'):''};
function selectAlt(g,a){commit(q=>{g.alts.forEach(x=>setProfilePath(q,x.p,false));if(a)setProfilePath(q,a.p,true)})}
function toggleGoal(g){const cur=activeAlt(g);if(cur)return selectAlt(g,null);const last=store.get('norex_lastalt',{})[g.id];selectAlt(g,g.alts.find(a=>a.k===last&&!blocked(a))||g.alts.find(a=>!a.old&&!blocked(a))||g.alts.find(a=>!blocked(a)))}
const rememberAlt=(g,a)=>{const m=store.get('norex_lastalt',{});m[g.id]=a.k;store.set('norex_lastalt',m)};
const pins=()=>store.get('norex_pins',['sprint_toggle','filter','precision','jockey','auto_jockey','shotmode','lowdrive','finish','timed_pass','perfect_sprint']);
const isPinned=id=>pins().includes(id);
const togglePin=id=>{const p=pins();store.set('norex_pins',p.includes(id)?p.filter(x=>x!==id):[...p,id])};

/* ---------- cards: icon, name, small description, switch, version pills, knobs ---------- */
const ICONS={filter:'🌊',outer:'🎚',sprintresp:'💨',perfect_sprint:'⚡',speed_boost:'🚀',sprint_toggle:'🔁',sc_run:'⌨️',precision:'🎯',cdr:'⚽',fast_dribble:'💫',sc_drib:'⌨️',through:'🧭',cross:'📐',ctx_pass:'↗️',ctx_cross:'↪️',precision_pass:'🎯',timed_pass:'⏱',timed_cross:'⏱',sc_pass:'⌨️',shotmode:'🥅',shot_type:'🎛',ctx_shoot:'💥',lowdrive:'⬇️',finish:'✨',shot_timing:'⏱',sc_shoot:'⌨️',jockey:'🛡',auto_jockey:'🤖',ctx_switch:'🔀',defonly:'🧱',sc_def:'🔒',gk:'🧤',timing:'⏲',angles:'🧭'};
/* Plain words, from a player's seat in FC27. */
const TIPS={
 filter:'Calms a shaky thumb, so your player runs where you meant to point instead of where the stick wobbled.',
 outer:'Sets how quickly your player reaches full run speed as you push the stick toward the edge.',
 sprintresp:'Changes how the stick feels only while you hold sprint (R2), for example gentler steering at top speed.',
 perfect_sprint:'While you hold sprint (R2), sets its press to your chosen strength. Release R2 to stop.',
 speed_boost:'When you start sprinting while moving, briefly flicks the right stick in your running direction. Your game controls decide the result.',
 sprint_toggle:'Tap sprint once to keep running, tap again to stop. No need to hold R2.',
 sc_run:'Pick the buttons that trigger the Controlled Sprint and Curved Run helpers. Disabled means off.',
 precision:'Finer control for small stick movements, great for tight 1v1 dribbling. Full push still gives full speed.',
 cdr:'Changes the stick feel only while you hold R1, so close control and small touches are easier.',
 fast_dribble:'Adds R1 while you move the stick without sprinting or pressing an attacking button. Your game controls decide the dribble style.',
 sc_drib:'Pick the button that triggers the Precision Clutch dribble helper.',
 through:'Changes the stick feel while you aim a through ball (Triangle held), so you can place it more accurately.',
 cross:'Changes the stick feel while you aim a cross (Square held), for steadier placement.',
 ctx_pass:'While you hold the pass button, the stick reacts softer or sharper so aiming the pass is easier.',
 ctx_cross:'While you hold the cross button, the stick reacts softer or sharper so aiming the cross is easier.',
 precision_pass:'Holds R1 together with your pass button every time.',
 timed_pass:'Holds the pass button for a fixed time, so every pass has the same power. You set the time.',
 timed_cross:'Holds the cross button for a fixed time, so every cross has the same power.',
 sc_pass:'Pick the button that triggers the pass-and-follow helper.',
 shotmode:'Shot response changes the stick feel while you shoot. Timed shot holds shoot for a set time so every shot has the same power. Pick one.',
 shot_type:'A different stick feel for normal, finesse and power shots.',
 ctx_shoot:'While you hold shoot, the stick reacts softer or sharper to help you place the shot.',
 lowdrive:'Adds the low-driven shot press for you right after you shoot. Pick Low driven, or Perfect lowdrive (works with Timed shot).',
 finish:'Finesse finish adds another shot tap after you release an R1 shot. Auto power shot adds L1 + R1 to your shot. Pick one.',
 shot_timing:'Fine timing for the extra presses sent after a shot: how soon they come and how long they press.',
 sc_shoot:'Pick the buttons that trigger Finesse, Chip, Power and Low-driven shot shortcuts.',
 jockey:'Changes the stick feel only while you hold jockey (L2), so you can shuffle with the attacker more precisely.',
 auto_jockey:'Adds L2 while you are not pressing an attacking button or sprinting. It cannot tell who has the ball; your game controls decide the result.',
 ctx_switch:'While you hold switch player, the stick reacts softer or sharper.',
 defonly:'Only use the jockey feel when you are in the Defender mode.',
 sc_def:'Pick the button that locks onto a player, and how long the lock press lasts.',
 gk:'Changes the right-stick feel while you control your keeper (R3 held).',
 timing:'How long shortcut taps last, and how long a skill combination must be held before it counts.',
 angles:'Which way "forward" points for stored aim and skill moves when there is no stick direction to follow.'};
const descOf=g=>TIPS[g.id]||'';
const KLABEL={strength:'Strength',exponent:'Curve',window_ms:'Smooth time (ms)',degrees:'Lock range (°)'};
const KTIP={strength:'How much of the effect is used. 0 = none, 100 = full.',exponent:'1 = normal. Above 1 = soft start and more control for small pushes. Below 1 = reacts sooner.',window_ms:'Longer = smoother but a touch slower to react.',degrees:'Wobbles smaller than this angle are ignored.'};
const HOW={
 radial:'The Lab looks at how far you push the stick and bends it along a curve before the game sees it. Strength is how much of that bend is used. Curve above 1 gives a soft start and more control for small pushes. Curve below 1 makes your player react sooner.',
 smooth:'Each new stick reading is blended with the one before it, so sudden jerks are softened. Higher strength or a longer time feels smoother but a little slower to react. Full push is never held back.',
 lock:'If the stick angle moves by less than the lock range between two readings, the angle is pulled back toward where it was, so tiny wobble is ignored. Real turns are never held back.',
 press:'Every time you press the button, the Lab keeps it held for the time you set, so the result is the same each time.'};
const OLDNEW='Old and New do the same job. Old is the first version of these tweaks, kept so profiles you saved earlier feel exactly the same. New is the rebuilt version with cleaner limits, and it also has a few extras (shot, cross, precision stick, outer speed). Pick one version here; the Lab switches the other version off in the same update. Use New unless an old profile depends on the old numbers.';
const decimals=st=>st>=1?0:Math.min(3,Math.ceil(-Math.log10(st)));
const fmt=(v,st)=>Number(v).toFixed(decimals(st));
const polar=(a)=>[36+28*Math.cos(a*Math.PI/180),36+28*Math.sin(a*Math.PI/180)];
const arcPath=(a0,a1)=>{const [x0,y0]=polar(a0),[x1,y1]=polar(a1);return `M${x0.toFixed(2)} ${y0.toFixed(2)} A28 28 0 ${(a1-a0)>180?1:0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`};
function knob(label,val,min,max,step,attr,tip){const st=step==='any'?(max-min)/100:step,v=Number(val);
  return `<div class="kn" tabindex="0" role="slider" aria-label="${esc(label)}" title="${esc(tip||'')}" aria-valuemin="${min}" aria-valuemax="${max}" aria-valuenow="${v}" data-min="${min}" data-max="${max}" data-step="${st}" data-val="${v}" ${attr}><svg viewBox="0 0 72 72" aria-hidden="true"><path class="kn-track" d="${arcPath(135,405)}"/><path class="kn-val" d=""/><circle class="kn-dot" r="4.5"/></svg><b class="kv"></b><span class="kl">${esc(label)}</span></div>`}
function paintKnob(el,v){const min=+el.dataset.min,max=+el.dataset.max,st=+el.dataset.step,pct=max>min?(v-min)/(max-min):0,a=135+270*pct;
  el.querySelector('.kn-val').setAttribute('d',pct>0.001?arcPath(135,Math.max(135.5,a)):'');const [x,y]=polar(a),d=el.querySelector('.kn-dot');d.setAttribute('cx',x.toFixed(2));d.setAttribute('cy',y.toFixed(2));
  const kv=el.querySelector('.kv');if(kv)kv.textContent=fmt(v,st);el.setAttribute('aria-valuenow',String(v))}
function helperKnobs(a){const h=a.h&&helpers?.helpers?.[a.h];if(!h)return '';const conf=effective.helpers_v2.configured[a.h]||{};
  return Object.entries(h.parameters).map(([key,p])=>knob(KLABEL[key]||key.replaceAll('_',' '),conf[key]??p.default,p.min,p.max,'any',`data-gh="${a.h}" data-gk="${key}"`,KTIP[key])).join('')}
const numKnobs=list=>(list||[]).map(n=>knob(n.l,getPath(cfg(),n.p)??n.min,n.min,n.max,n.step,`data-gn="${n.p}"`)).join('');
function commitKnob(el,v){if(el.dataset.gh){const next=structuredClone(effective.helpers_v2.configured);next[el.dataset.gh][el.dataset.gk]=v;act('helpers_configure',{helpers:next})}else commit(q=>setProfilePath(q,el.dataset.gn,v))}
function bindKnobs(root){root.querySelectorAll('.kn').forEach(el=>{
  const min=+el.dataset.min,max=+el.dataset.max,st=+el.dataset.step;let val=+el.dataset.val,timer=null,typing=false;
  const clamp=v=>Math.min(max,Math.max(min,Math.round((v-min)/st)*st+min));
  const done=()=>{clearTimeout(timer);el.dataset.val=val;commitKnob(el,Number(fmt(val,st)))};
  const set=(v,soon)=>{val=clamp(v);paintKnob(el,val);liveChart(el,val);clearTimeout(timer);if(soon)timer=setTimeout(done,soon)};
  paintKnob(el,val);
  el.onpointerdown=e=>{if(el.getAttribute('aria-disabled')==='true')return;if(typing||e.button>0)return;el.setPointerCapture(e.pointerId);const y0=e.clientY,x0=e.clientX,v0=val;el.classList.add('drag');
    el.onpointermove=ev=>{uiInteraction.until=Date.now()+800;set(v0+((y0-ev.clientY)+(ev.clientX-x0))/170*(max-min))};
    el.onpointerup=el.onpointercancel=()=>{el.onpointermove=el.onpointerup=el.onpointercancel=null;el.classList.remove('drag');if(val!==+el.dataset.val)done()}};
  el.addEventListener('wheel',e=>{if(el.getAttribute('aria-disabled')==='true')return;e.preventDefault();uiInteraction.until=Date.now()+900;set(val+(e.deltaY<0?1:-1)*st*(e.shiftKey?10:1),500)},{passive:false});
  el.onkeydown=e=>{if(el.getAttribute('aria-disabled')==='true')return;const k={ArrowUp:1,ArrowRight:1,ArrowDown:-1,ArrowLeft:-1,PageUp:10,PageDown:-10}[e.key];if(k){e.preventDefault();set(val+k*st,500)}else if(e.key==='Home'){e.preventDefault();set(min,500)}else if(e.key==='End'){e.preventDefault();set(max,500)}};
  el.ondblclick=()=>{if(el.getAttribute('aria-disabled')==='true')return;if(typing)return;typing=true;const kv=el.querySelector('.kv'),inp=document.createElement('input');inp.type='number';inp.min=min;inp.max=max;inp.step='any';inp.value=fmt(val,st);inp.className='kv-in';inp.setAttribute('aria-label','Type a value');kv.replaceWith(inp);inp.focus();inp.select();
    const fin=ok=>{if(!typing)return;typing=false;if(ok&&inp.value!=='')set(Number(inp.value));const b=document.createElement('b');b.className='kv';inp.replaceWith(b);paintKnob(el,val);if(ok&&val!==+el.dataset.val)done()};
    inp.onkeydown=ev=>{if(ev.key==='Enter')fin(true);else if(ev.key==='Escape')fin(false)};inp.onblur=()=>fin(true)}})}

/* ---------- live "without it / with it" previews ---------- */
const HOLD={shotmode:'Circle held',cross:'Square held',through:'Triangle held',cdr:'R1 held',jockey:'L2 held',sprintresp:'R2 held',gk:'R3 held · right stick',ctx_pass:'pass held',ctx_cross:'cross held',ctx_shoot:'shoot held',ctx_switch:'switch held'};
const confOf=a=>a.h?effective.helpers_v2.configured[a.h]:null;
/* what the numbers currently are for a version; null if it has no stick/time shape to draw */
function shapeOf(g,a){const c=cfg();
  if(a.h&&['precision_stick','outer_response','shot_response','cross_response','through_pass_response','controlled_dribble_response','jockey_response','sprint_response','goalkeeper_stick'].includes(a.h)){const r=confOf(a)||{};return {kind:'radial',s:(r.strength??50)/100,e:r.exponent??1.5,rs:a.h==='goalkeeper_stick'}}
  if(a.h==='smoothing'){const r=confOf(a)||{};return {kind:'smooth',ms:r.window_ms??12,s:(r.strength??20)/100}}
  if(a.h==='direction_stability'){const r=confOf(a)||{};return {kind:'lock',deg:r.degrees??5,s:(r.strength??50)/100}}
  if(a.p.startsWith('helpers.contexts.')){const r=getPath(c,a.p.replace(/\.enabled$/,''))||{};return {kind:'radial',s:r.strength??1,e:r.exponent??1,rs:a.p.includes('goalkeeper')}}
  if(a.p==='helpers.smoothing.enabled'){const r=c.helpers.smoothing;return {kind:'smooth',ms:r.ms,s:r.strength}}
  if(a.p==='helpers.direction_stability.enabled'){const r=c.helpers.direction_stability;return {kind:'lock',deg:r.degrees,s:r.strength}}
  if(a.p.startsWith('advanced.contexts.')){const r=getPath(c,a.p.replace(/\.enabled$/,''))||{};return {kind:'radial',s:1,e:r.exponent??1.15}}
  if(a.p==='play_tools.outer.enabled'){const r=c.play_tools.outer;return {kind:'radial',s:1,e:1,outer:r.left??1}}
  if(a.p==='assists.speed_boost'||a.p==='assists.finesse_finish')return null;
  const ms=a.nums?.find(n=>/_ms$/.test(n.p));if(ms)return {kind:'press',ms:getPath(c,ms.p)};
  return null}
const radialY=(m,s,e)=>m+(Math.pow(m,e)-m)*s;
function chartSvg(sh){const W=200,H=104,x0=22,x1=192,y0=8,y1=86,X=t=>x0+(x1-x0)*t,Y=v=>y1-(y1-y0)*v;let body='',cap='',legend='<span class="lg off">Without it</span><span class="lg on">With it</span>';
  if(sh.kind==='radial'){const pts=[];for(let i=0;i<=40;i++){const m=i/40;pts.push(X(m).toFixed(1)+','+Y(Math.min(1,sh.outer?m/sh.outer:radialY(m,sh.s,sh.e))).toFixed(1))}
    body=`<line class="c-off" x1="${X(0)}" y1="${Y(0)}" x2="${X(1)}" y2="${Y(1)}"/><polyline class="c-on" points="${pts.join(' ')}"/><circle class="c-dot you" visibility="hidden" r="3.5" cx="${X(0)}" cy="${Y(0)}" data-live="radial" data-rs="${sh.rs?1:0}" data-strength="${sh.s}" data-exponent="${sh.e}" data-outer="${sh.outer||0}"/><text class="c-t" x="${x0}" y="100">push the stick →</text><text class="c-t" x="${x0-4}" y="${y0+4}" text-anchor="end">↑</text>`;
    cap='Grey: what the game gets with no help. Red: what it gets with your numbers. The dot models this card alone when you move your stick. Other settings and game results are not included.'}
  else if(sh.kind==='smooth'){const dt=8,ret=sh.ms>0?Math.exp(-dt/sh.ms)*sh.s:0;let o=0;const pts=[];for(let n=0;n<=24;n++){pts.push(X(n/24).toFixed(1)+','+Y(o).toFixed(1));o=.5*(1-ret)+o*ret}
    body=`<polyline class="c-off" points="${[X(0)+','+Y(0),X(0.02)+','+Y(.5),X(1)+','+Y(.5)].join(' ')}"/><polyline class="c-on" points="${pts.join(' ')}"/><text class="c-t" x="${x0}" y="100">time after a sudden push →</text>`;
    cap='Grey: a sudden half-stick push. Red: it eases in (full push and reversals bypass smoothing), so jerks are softened. Longer time or more strength = slower, smoother.'}
  else if(sh.kind==='lock'){const A=Math.min(sh.deg*.8,14),raw=[],out=[];let prev=0;for(let n=0;n<=36;n++){const th=A*(Math.sin(n*1.7)+.5*Math.sin(n*.8));raw.push(th);const d=th-prev;const o=Math.abs(d)<sh.deg?th-d*sh.s:th;out.push(o);prev=o}
    const mx=Math.max(8,...raw.map(Math.abs)),Yy=v=>(y0+y1)/2-(v/mx)*((y1-y0)/2-2);
    body=`<line class="c-grid" x1="${x0}" x2="${x1}" y1="${Yy(0)}" y2="${Yy(0)}"/><polyline class="c-off" points="${raw.map((v,n)=>X(n/36).toFixed(1)+','+Yy(v).toFixed(1)).join(' ')}"/><polyline class="c-on" points="${out.map((v,n)=>X(n/36).toFixed(1)+','+Yy(v).toFixed(1)).join(' ')}"/><text class="c-t" x="${x0}" y="100">your aim angle over time →</text>`;
    cap='Grey: a wobbling thumb. Red: the angle the game gets. Wobble smaller than the lock range is ignored.'}
  else if(sh.kind==='press'){const tmax=Math.max(500,sh.ms*1.2),T=ms=>X(ms/tmax);
    body=`<rect class="b-off" x="${T(0)}" y="22" width="${Math.max(2,T(60)-T(0))}" height="16" rx="3"/><rect class="b-on" x="${T(0)}" y="52" width="${Math.max(2,T(sh.ms)-T(0))}" height="16" rx="3"/><text class="c-t" x="${x0}" y="18">your quick tap (about 60 ms)</text><text class="c-t" x="${x0}" y="48">held by the Lab: ${Math.round(sh.ms)} ms</text><text class="c-t" x="${x0}" y="100">time →</text>`;
    cap='How long the button is held down each time. The Lab keeps it the same every press.'}
  return `<div class="pv"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Without it versus with it">${sh.kind==='radial'?`<rect class="c-box" x="${x0}" y="${y0}" width="${x1-x0}" height="${y1-y0}" rx="3"/>`:''}${body}</svg><div class="pv-leg">${legend}</div><p class="pv-cap">${cap}</p></div>`}
function liveChart(knobEl,val){/* redraw the chart inside this card while a knob moves */
  const w=knobEl.closest('.gwrap');if(!w)return;const g=byId(w.dataset.goal);if(!g?.alts)return;const a=activeAlt(g)||g.alts.find(a=>!a.old)||g.alts[0];if(!a)return;
  const sh=shapeOf(g,a);if(!sh)return;const k=knobEl.dataset;
  if(k.gk==='strength'){if(sh.kind==='press')return;sh.s=val/100}else if(k.gk==='exponent')sh.e=val;else if(k.gk==='window_ms')sh.ms=val;else if(k.gk==='degrees')sh.deg=val;
  else if(k.gn&&sh.kind==='press'&&/_ms$/.test(k.gn))sh.ms=val;
  else if(k.gn&&sh.kind==='radial'&&/exponent$/.test(k.gn))sh.e=val;
  const box=w.querySelector('.pv');if(box){box.outerHTML=chartSvg(sh)}}
document.addEventListener?.('labs-telemetry',e=>{const t=e.detail;document.querySelectorAll('.gwrap.hot .c-dot[data-live=radial]').forEach(d=>{d.setAttribute('visibility',t.input_connected&&t.input&&(t.input_age_ms??Infinity)<750?'visible':'hidden');const ax=t.input?.axes||{},rs=d.dataset.rs==='1',m=Math.min(1,Math.hypot(ax[rs?'RX':'LX']||0,ax[rs?'RY':'LY']||0)),o=+d.dataset.outer?Math.min(1,m/+d.dataset.outer):radialY(m,+d.dataset.strength,+d.dataset.exponent);d.setAttribute('cx',(22+170*m).toFixed(1));d.setAttribute('cy',(86-78*o).toFixed(1))})});

function infoHtml(g,a){const sh=a&&shapeOf(g,a),how=sh?HOW[sh.kind]||'':'';
  const old=g.alts?.some(x=>x.old);
  return `${how?`<p><b>How it works.</b> ${esc(how)}</p>`:''}${old?`<p><b>Old vs New.</b> ${esc(OLDNEW)}</p>`:''}${HOLD[g.id]?`<p class="muted">Active while: ${esc(HOLD[g.id])}.</p>`:''}${!how&&!old?`<p>${esc(descOf(g))}</p>`:''}`}
function shortcutSelect(key){const p=cfg(),v=p.advanced.shortcuts[key];return `<label class="sc"><span>${esc(key.replaceAll('_',' '))}</span><select data-global-shortcut="${key}">${['Disabled',...Object.keys(p.button_map).filter(k=>k!=='PS')].map(b=>`<option ${v===b?'selected':''}>${esc(b)}</option>`).join('')}</select></label>`}
const openCards=new Set();
function goalCard(g,live){const cur=activeAlt(g),on=!!cur,multi=g.alts?.length>1;
  const sw=g.alts?`<button type="button" class="sw" role="switch" aria-checked="${on}" aria-label="${esc(g.name)}" data-sw="${g.id}"><i class="sw-k"></i></button>`:'';
  const vers=multi?`<div class="vers" role="group" aria-label="Version">${g.alts.map(a=>{const b=blocked(a);return `<button type="button" data-g="${g.id}" data-alt="${a.k}" aria-pressed="${cur===a}" ${b?`disabled title="${esc(b)}"`:''}>${esc(a.l)}</button>`}).join('')}</div>`:'';
  const preview=cur||g.alts?.find(a=>!a.old)||g.alts?.[0];
  const sh=preview?shapeOf(g,preview):null;
  const knobs=g.alts?(preview?helperKnobs(preview)+numKnobs(preview.nums):''):numKnobs(g.nums);
  const sc=(g.shortcuts||[]).map(shortcutSelect).join('');
  const v=g.alts?tileValue(g):'';
  const sum=g.alts?(on?(multi?cur.l:'On')+(v?' · '+v:''):'Off'):(sc?'Pick buttons':'Adjust');
  const hint=!g.alts&&!sc&&!knobs?'':'';
  return `<div class="gwrap${openCards.has(g.id)?' open':''}" data-goal="${g.id}"><article class="gcard${on?' on':''}${live?' live':''}" tabindex="0" aria-label="${esc(g.name)} settings"><div class="gc-head"><span class="gc-ico" aria-hidden="true">${ICONS[g.id]||'🎮'}</span><div class="gc-title"><b>${esc(g.name)}</b></div>${sw}</div><p class="gc-desc">${esc(descOf(g))}</p><div class="gc-sum"><span>${esc(sum)}</span><span class="gc-more" aria-hidden="true">hover for settings ▾</span></div></article>
  <div class="gdrawer" role="group" aria-label="${esc(g.name)} settings">${vers}${sh?chartSvg(sh):(cur?`<p class="pv-none">${esc(descOf(g))}</p>`:'')}${sc?`<div class="scs">${sc}</div>`:''}${knobs?`<div class="knobs">${knobs}</div>`:''}${g.alts&&!sh?'<p class="pv-cap">This input pattern has no single stick curve to plot. Compare actual local input in Live pads; the Lab cannot show its in-game result.</p>':''}<div class="gd-foot">${g.alts?`<button type="button" class="ico" data-pin="${g.id}" aria-pressed="${isPinned(g.id)}" title="Show on the Live page">${isPinned(g.id)?'★ Pinned':'☆ Pin to Live'}</button>`:''}<button type="button" class="ico" data-info="${g.id}" aria-expanded="false">ⓘ How it works</button></div><div class="gc-info" hidden>${infoHtml(g,cur||g.alts?.[0])}</div></div></div>`}
function bindGoals(root,afterPin,live){
  root.querySelectorAll('[data-sw]').forEach(b=>b.onclick=e=>{e.stopPropagation();toggleGoal(byId(b.dataset.sw))});
  root.querySelectorAll('[data-alt]').forEach(b=>b.onclick=()=>{const g=byId(b.dataset.g),a=g.alts.find(x=>x.k===b.dataset.alt)||null;if(a){rememberAlt(g,a);selectAlt(g,cur(g)===a?null:a)}});
  root.querySelectorAll('[data-pin]').forEach(b=>b.onclick=()=>{togglePin(b.dataset.pin);const y=isPinned(b.dataset.pin);b.textContent=y?'★ Pinned':'☆ Pin to Live';b.setAttribute('aria-pressed',String(y));afterPin&&afterPin()});
  root.querySelectorAll('[data-info]').forEach(b=>b.onclick=()=>{const box=b.closest('.gdrawer').querySelector('.gc-info');box.hidden=!box.hidden;b.setAttribute('aria-expanded',String(!box.hidden))});
  root.querySelectorAll('[data-global-shortcut]').forEach(el=>el.onchange=()=>commit(q=>q.advanced.shortcuts[el.dataset.globalShortcut]=el.value));
  root.querySelectorAll('.gwrap').forEach(w=>{const id=w.dataset.goal,card=w.querySelector('.gcard'),drawer=w.querySelector('.gdrawer');
    const place=()=>{w.classList.remove('up');const sc=document.querySelector('#settingsBody').getBoundingClientRect(),r=w.getBoundingClientRect(),h=drawer.offsetHeight;if(r.bottom+h>sc.bottom-4&&r.top-h>sc.top)w.classList.add('up')};
    w.onmouseenter=()=>{w.classList.add('hot');place()};w.onmouseleave=()=>{if(!w.contains(document.activeElement))w.classList.remove('hot')};
    w.addEventListener('focusin',()=>{w.classList.add('hot');place()});w.addEventListener('focusout',e=>{if(!w.contains(e.relatedTarget))w.classList.remove('hot')});
    card.onclick=e=>{if(e.target.closest('.sw'))return;w.classList.toggle('open');w.classList.contains('open')?openCards.add(id):openCards.delete(id);place()};
    card.onkeydown=e=>{if(e.target!==card)return;if(e.key===' '||e.key==='Enter'){e.preventDefault();card.click()}else if(e.key==='Escape'){w.classList.remove('open','hot');openCards.delete(id);card.blur()}};
    if(w.classList.contains('open'))place()});
  bindKnobs(root);if(typeof blockShortcutSelections==='function')blockShortcutSelections()}
const cur=g=>activeAlt(g);

/* ---------- game types: League / Rush / Grounds, each with Base / Attack / Defend variations ---------- */
const GAMES=['League','Rush','Grounds'],VARIANTS=['Base','Attack','Defend'];
const presetPaths=()=>[...new Set(GOALS.flatMap(g=>[...(g.alts||[]).flatMap(a=>[a.p,...(a.nums||[]).map(n=>n.p),...(a.h?Object.keys(helpers?.helpers?.[a.h]?.parameters||{}).map(k=>B+a.h+'.'+k):[])]),...(g.nums||[]).map(n=>n.p),...(g.shortcuts||[]).map(k=>'advanced.shortcuts.'+k)]))];
const snapshotValues=()=>Object.fromEntries(presetPaths().map(p=>[p,getPath(cfg(),p)]).filter(([,v])=>v!==undefined));
const savedPreset=(g,v)=>(typeof gamePresets==='object'&&gamePresets?.[g]?.[v])||null;
const presetMatches=pr=>!!pr&&Object.entries(pr.values).every(([p,v])=>getPath(cfg(),p)===v);
let gameSel=store.get('norex_game',{game:'League',variant:'Base'});
const afterPreset=()=>{sideSig='';renderSide();if(page==='Live')live()};
const pickGame=(game,variant)=>{gameSel={game,variant};store.set('norex_game',gameSel)};
function applyPreset(game,variant){const pr=savedPreset(game,variant);pickGame(game,variant);
  if(!pr){notice(game+' · '+variant+' is empty. Set things up, then press “Save here”.');return afterPreset()}
  return commit(q=>Object.entries(pr.values).forEach(([p,v])=>{try{setProfilePath(q,p,v)}catch{}})).then(()=>notice('Loaded '+game+' · '+variant+'.'))}
async function postPreset(body){const r=await fetch('/api/game-presets',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok||d.error)throw Error(d.error||'Could not save the preset');gamePresets=d.presets;return d}
async function savePreset(){const {game,variant}=gameSel;try{await postPreset({action:'save',game,variant,values:snapshotValues()});notice('Saved the current settings as '+game+' · '+variant+'.');afterPreset()}catch(e){notice(e.message,true)}}
async function clearPreset(){const {game,variant}=gameSel;if(!savedPreset(game,variant))return;if(!confirm('Remove the saved '+game+' · '+variant+' preset?'))return;try{await postPreset({action:'delete',game,variant});notice('Removed '+game+' · '+variant+'.');afterPreset()}catch(e){notice(e.message,true)}}
function gameStrip(){const {game,variant}=gameSel,cur=savedPreset(game,variant),match=presetMatches(cur);
  const has=g=>VARIANTS.some(v=>savedPreset(g,v));
  return `<div class="cp-group"><span class="cp-label">Game</span><span class="seg" id="cpGame">${GAMES.map(g=>`<button type="button" data-game="${g}" aria-pressed="${game===g}">${g}${has(g)?' <i class="dot" aria-label="has presets">●</i>':''}</button>`).join('')}</span><span class="seg" id="cpVariant">${VARIANTS.map(v=>`<button type="button" data-variant="${v}" aria-pressed="${variant===v}">${v}${savedPreset(game,v)?' <i class="dot">●</i>':''}</button>`).join('')}</span><button type="button" id="cpPresetSave" title="Store the current toggles, numbers and shortcuts as ${esc(game)} · ${esc(variant)}">💾 Save here</button><button type="button" id="cpPresetClear" class="ico" ${cur?'':'disabled'} title="Remove this saved preset" aria-label="Remove preset">✕</button><small class="muted">${cur?(match?'✓ live settings match':'● changed since loaded'):'empty slot'}</small></div>`}

/* ---------- LIVE: the in-game page ---------- */
let liveFilter='pinned',liveQuery='';
const tileValue=g=>{const a=activeAlt(g);if(!a)return '';const h=a.h&&effective.helpers_v2.configured[a.h];if(h&&h.strength!=null)return Math.round(h.strength)+'%';const n=a.nums?.[0];return n?String(getPath(cfg(),n.p)):''};
function tiles(){const q=liveQuery.toLowerCase();
  return toggles().filter(g=>(liveFilter==='pinned'?isPinned(g.id):liveFilter==='on'?!!activeAlt(g):liveFilter==='all'||g.phase===liveFilter)&&(!q||g.name.toLowerCase().includes(q))).map(g=>goalCard(g,true)).join('')||'<p class="muted pad">Nothing here yet. Open a card in Tune and press “☆ Pin to Live”.</p>'}
function sectionChips(){return ['Helpers','Skills','Controller'].map(s=>{const on=state.sections?.[s]!==false;return `<button type="button" class="chip-sw" data-section="${s}" aria-pressed="${on}" ${state.master_enabled?'':'disabled'} title="${s} enhancements. OFF restores plain defaults for this group; ON brings your settings back.">${s}: ${on?'ON':'OFF'}</button>`}).join('')}
function live(){const m=state.play_modes,c=effective.comparison;
  $('#content').innerHTML=`<div class="cp-live"><div class="cp-strip"><div class="cp-group"><span class="cp-label">Compare</span><button type="button" data-cmp="RAW">Try Normal</button><button type="button" data-cmp="NOREX">Try Custom</button><button type="button" id="cpEnd" ${c.active?'':'disabled'}>End</button><small class="muted">${c.active?'Sampling '+esc(c.active.mode):'RAW '+(c.samples?.RAW?.frames||0)+' · NOREX '+(c.samples?.NOREX?.frames||0)}</small></div><div class="cp-group"><button type="button" id="cpActionsOff" title="Turns off every stored action (auto jockey, timed pass and so on)">All actions off</button></div></div>
  <div class="cp-bar"><span class="seg" id="cpFilters">${[['pinned','★ Pinned'],['on','On now'],['all','All'],...PHASES.filter(p=>toggles().some(g=>g.phase===p[0])).map(p=>[p[0],p[2]+' '+p[1]])].map(([id,l])=>`<button type="button" data-lf="${id}" aria-pressed="${liveFilter===id}">${l}</button>`).join('')}</span><input id="cpSearch" type="search" placeholder="Find a toggle…" value="${esc(liveQuery)}" aria-label="Find a toggle"><button type="button" id="cpPalBtn" title="Ctrl+K">⌘ Commands</button></div>
  <div class="tiles" id="tiles">${tiles()}</div>
  <div class="cp-skill" id="cpSkill"><div class="cp-label">Skills</div><div class="sk prev"><small>Previous</small><b id="skPrev">—</b></div><div class="sk now"><small>Playing now</small><b id="skNow">—</b></div><div class="sk next"><small>Up next</small><b id="skNext">—</b></div><button type="button" id="cpOpenSkills">Open skills ›</button></div></div>`;
  bindLive();paintSkill(globalThis.labsTelemetry)}
function bindLive(){const root=$('#content');
  root.querySelectorAll('[data-cmp]').forEach(b=>b.onclick=()=>act('comparison_start',{mode:b.dataset.cmp}));$('#cpEnd').onclick=()=>act('comparison_stop');
  $('#cpActionsOff').onclick=()=>commit(q=>Object.keys(q.assists).forEach(k=>{if(typeof q.assists[k]==='boolean')q.assists[k]=false}));
  root.querySelectorAll('[data-lf]').forEach(b=>b.onclick=()=>{liveFilter=b.dataset.lf;live()});
  $('#cpSearch').oninput=e=>{liveQuery=e.target.value;$('#tiles').innerHTML=tiles();bindTiles()};
  $('#cpPalBtn').onclick=openPalette;$('#cpOpenSkills').onclick=()=>navigate('Skills');bindTiles()}
function bindTiles(){bindGoals($('#tiles'),null,true)}
function closePop(){}
function refreshPop(){}
function paintSkill(t){const s=t?.skill;if(!$('#skNow'))return;const set=(id,v)=>{const e=$(id);if(e&&e.textContent!==v)e.textContent=v};set('#skPrev',s?.previous?.name||'—');set('#skNow',s?.now?s.now.name+' · step '+(s.now.step+1)+'/'+s.now.steps:'—');set('#skNext',s?.next||'—');$('#cpSkill')?.classList.toggle('live',!!s?.now)}
document.addEventListener?.('labs-telemetry',e=>paintSkill(e.detail));

/* ---------- TUNE: every adjustable thing, grouped by what you are doing in the game ---------- */
function tune(){
  $('#content').innerHTML=`<div class="cp-jump" role="navigation" aria-label="Jump to">${PHASES.map(([id,n,i])=>`<button type="button" data-jump="${id}">${i} ${n}</button>`).join('')}</div>${PHASES.map(([id,name,ico])=>`<section class="phase" id="ph-${id}"><h2 class="phase-h"><span class="ph-i">${ico}</span>${name}</h2><div class="gcards">${GOALS.filter(g=>g.phase===id).map(g=>goalCard(g)).join('')}</div></section>`).join('')}`;
  $('#content').querySelectorAll('[data-jump]').forEach(b=>b.onclick=()=>document.querySelector('#ph-'+b.dataset.jump)?.scrollIntoView({behavior:'smooth',block:'start'}));
  bindGoals($('#content'))}

/* ---------- SETUPS: profiles, modes, compare, who owns which button ---------- */
function harvest(fn){const c=$('#content');fn();const nodes=[...c.childNodes].filter(n=>!(n.classList?.contains('page-heading')));c.textContent='';return nodes}
function owners(){const o=effective.global_rules?.trigger_owners||[];const el=document.createElement('article');el.className='card';el.innerHTML=`<h3>Button owners</h3><p class="muted">Every button combination in use and what owns it. Two things cannot own the same one.</p>${o.length?`<table class="cp-table">${o.map(r=>`<tr><td>${esc(r.trigger)}</td><td>${esc(r.owner)}</td></tr>`).join('')}</table>`:'<p>No shortcut assignments.</p>'}`;return [el]}
function setups(){const prof=harvest(profilePage),modes=harvest(modesPage),cmp=harvest(overview).filter(n=>n.tagName==='ARTICLE'&&n.querySelector('[data-compare]')),own=owners();
  const col=(...lists)=>{const d=document.createElement('div');d.className='cp-col';lists.flat().forEach(n=>d.append(n));return d};
  const root=$('#content');root.textContent='';const wrap=document.createElement('div');wrap.className='cp-cols';wrap.append(col(prof,own),col(modes),col(cmp));root.append(wrap)}

/* ---------- TOOLS: record/replay, compare & frames, checks, old-engine numbers ---------- */
let toolsTab='rec';
function legacyJson(){const p=cfg();const a=document.createElement('article');a.className='card';a.innerHTML=`<h3>Old-engine numbers</h3><p class="muted">The older response engines keep their numbers here as one block. Turn an old engine on in Tune (the “Old” choice), then adjust it here.</p><textarea id="legacyResponseJson" aria-label="Old engine parameters">${esc(JSON.stringify(p.helpers,null,2))}</textarea><div class="actions"><button id="legacyResponseApply">Apply numbers</button></div>`;
  a.querySelector('#legacyResponseApply').onclick=()=>{try{const q=structuredClone(effective.configuration);q.helpers=JSON.parse(a.querySelector('#legacyResponseJson').value);act('configure',{profile:q})}catch(e){notice(e.message,true)}};
  $('#content').textContent='';$('#content').append(a)}
function tools(){const tabs=[['rec','⏺ Record & replay',recordingPage],['cmp','⚖ Frames',overview],['chk','🔎 Checks & details',advancedPage],['old','🧰 Old-engine numbers',legacyJson]];const t=tabs.find(x=>x[0]===toolsTab)||tabs[0];
  const nodes=harvest(t[2]);const root=$('#content');root.innerHTML=`<div class="cp-tabs" role="tablist">${tabs.map(x=>`<button type="button" role="tab" data-tt="${x[0]}" aria-selected="${x[0]===t[0]}">${x[1]}</button>`).join('')}</div><div class="cp-cols one" id="toolsBody"></div>`;
  const body=$('#toolsBody');nodes.forEach(n=>body.append(n));root.querySelectorAll('[data-tt]').forEach(b=>b.onclick=()=>{toolsTab=b.dataset.tt;render(true)});if(typeof updateLive==='function')updateLive()}

/* ---------- left side panel: profile, game type, modes, controller feel ---------- */
let sideSig='',profilePick=null,profileSeen=null;
function selectedProfile(){if(profileSeen!==effective.profile){profileSeen=effective.profile;profilePick=effective.profile}return (profiles?.profiles||[]).includes(profilePick)?profilePick:effective.profile}
const sideBusy=()=>{const el=document.querySelector('#cpSide');return !el||el.querySelector('.kn.drag')||el.contains(document.activeElement)&&/^(SELECT|INPUT)$/.test(document.activeElement.tagName)};
function sideHtml(){const e=effective,m=state.play_modes,p=cfg(),profs=profiles?.profiles||[],{game,variant}=gameSel,cur=savedPreset(game,variant),match=presetMatches(cur),has=g=>VARIANTS.some(v=>savedPreset(g,v));
  const sd=p.advanced.stick_deadzone,selected=selectedProfile();
  return `<section class="sd sd-power"><label class="sd-sw"><span>Controller + Remote Play</span><button type="button" class="sw" role="switch" id="sdPower" aria-label="Controller and Remote Play service" aria-checked="${!!state.master_enabled}"><i class="sw-k"></i></button></label><small id="sdPowerNote">${state.master_enabled?'ON · profiles and modes can be applied.':'OFF · connect the controller by USB, then turn this on to apply profiles and modes.'}</small></section><section class="sd"><h3>📁 Profile</h3><select id="sdProfile" aria-label="Saved profile">${profs.map(n=>`<option ${n===selected?'selected':''}>${esc(n)}</option>`).join('')}</select><small id="sdProfileHint">${selected!==e.profile?'Selected: '+esc(selected)+' · press Load to apply.':'Choose a profile, then press Load.'}</small><div class="sd-row"><button type="button" id="sdLoad" title="Restore the selected profile (restoring a profile disarms helpers)">Load</button><button type="button" id="sdSave" class="go" title="Save your settings over the working profile">💾 Save</button></div><small class="muted">Working: <b>${esc(e.profile)}</b>${e.save_status?.state==='modified'?' · unsaved changes':''}</small></section>
  <section class="sd"><h3>🎮 Game type</h3><span class="seg" id="cpGame">${GAMES.map(g=>`<button type="button" data-game="${g}" aria-pressed="${game===g}">${g}${has(g)?' <i class="dot">●</i>':''}</button>`).join('')}</span><span class="seg" id="cpVariant">${VARIANTS.map(v=>`<button type="button" data-variant="${v}" aria-pressed="${variant===v}">${v}${savedPreset(game,v)?' <i class="dot">●</i>':''}</button>`).join('')}</span><div class="sd-row"><button type="button" id="cpPresetSave" class="go" title="Store your current toggles, numbers and shortcuts as ${esc(game)} · ${esc(variant)}">💾 Save here</button><button type="button" id="cpPresetClear" ${cur?'':'disabled'} title="Remove this saved preset" aria-label="Remove preset">✕</button></div><small class="muted">${cur?(match?'✓ matches your live settings':'● changed since loaded'):'Empty slot. Set things up, then Save here.'}</small></section>
  <section class="sd"><h3>🧩 Modes</h3><label class="sd-sw"><span>Controller shortcuts</span><button type="button" class="sw" role="switch" id="sdModeShortcuts" aria-label="Mode controller shortcuts" aria-checked="${!!m.enabled}"><i class="sw-k"></i></button></label><span class="seg">${m.names.map(n=>`<button type="button" data-bank="${esc(n)}" aria-pressed="${m.active===n}">${esc(n)}</button>`).join('')}</span><small class="muted">Active: <b>${esc(m.active)}</b> · <a href="#" data-goto="Setups">edit</a></small><small class="muted">Tap a mode to apply it. The switch enables its controller-button shortcuts.${state.sections?.Modes===false?' Modes group is OFF.':''}</small>${state.sections?.Modes===false?'<button type="button" id="sdModesRestore">Enable Modes group</button>':''}</section>
  <section class="sd"><h3>🕹 Controller feel</h3><div class="sd-knobs">${knob('Stick dead zone',p.deadzone,0,.5,.01,'data-gn="deadzone"','How far you can move the stick before the game notices. Raise it if your player drifts.')}${knob('Trigger dead zone',p.trigger_deadzone,0,.5,.01,'data-gn="trigger_deadzone"','How far L2 and R2 must be pressed before they count.')}</div>
  <label class="sd-sw"><span>Separate left / right dead zones</span><button type="button" class="sw" role="switch" aria-checked="${!!sd.enabled}" id="sdSplit"><i class="sw-k"></i></button></label>${sd.enabled?`<div class="sd-knobs">${knob('Left stick',sd.left,0,.5,.01,'data-gn="advanced.stick_deadzone.left"')}${knob('Right stick',sd.right,0,.5,.01,'data-gn="advanced.stick_deadzone.right"')}</div>`:''}
  ${Object.entries(p.curves).map(([k,c])=>`<label class="sc"><span>${esc(k)} curve</span><select data-curve="${k}" aria-label="${esc(k)} curve">${['linear','power','smoothstep','custom'].map(v=>`<option ${v===c.kind?'selected':''}>${v}</option>`).join('')}</select></label>${c.kind==='power'?knob(k+' sensitivity',c.exponent,.25,4,.05,`data-gn="curves.${k}.exponent"`,'1 = normal. Higher values soften small movements; lower values react sooner.'):''}`).join('')}
  <small class="muted"><a href="#" data-goto="Controller">Triggers, buttons, axes, calibration ›</a></small></section>
  <section class="sd"><h3>🧰 Groups</h3><div class="sd-chips">${sectionChips()}</div><small class="muted">OFF puts that group back to plain defaults. ON brings your settings back.</small></section>`}
function renderSide(){const box=document.querySelector('#cpSide');if(!box||!effective||!state)return;box.innerHTML=sideHtml();
  const on=(sel,fn)=>box.querySelectorAll(sel).forEach(fn);
  $('#sdPower').onclick=()=>act('master_power',{enabled:!state.master_enabled},true);
  $('#sdProfile').onchange=()=>{profilePick=$('#sdProfile').value;$('#sdProfileHint').textContent='Selected: '+profilePick+' · press Load to apply.'};
  $('#sdModeShortcuts').onclick=()=>act('mode_hotkeys',{enabled:!state.play_modes.enabled,bindings:state.play_modes.bindings},true);
  const restore=box.querySelector('#sdModesRestore');if(restore)restore.onclick=()=>act('section_power',{section:'Modes',enabled:true},true);
  $('#sdLoad').onclick=()=>act('profile_load',{name:$('#sdProfile').value});$('#sdSave').onclick=()=>act('profile_save',{name:effective.profile});
  on('[data-game]',b=>b.onclick=()=>{const g=b.dataset.game;applyPreset(g,savedPreset(g,gameSel.variant)?gameSel.variant:'Base')});
  on('[data-variant]',b=>b.onclick=()=>applyPreset(gameSel.game,b.dataset.variant));
  $('#cpPresetSave').onclick=savePreset;$('#cpPresetClear').onclick=clearPreset;
  on('[data-bank]',b=>b.onclick=()=>act('mode_select',{name:b.dataset.bank},true));
  on('[data-section]',b=>b.onclick=()=>act('section_power',{section:b.dataset.section,enabled:b.getAttribute('aria-pressed')!=='true'},true));
  on('[data-curve]',el=>el.onchange=()=>commit(q=>q.curves[el.dataset.curve].kind=el.value));
  $('#sdSplit').onclick=e=>commit(q=>q.advanced.stick_deadzone.enabled=!q.advanced.stick_deadzone.enabled);
  on('[data-goto]',a=>a.onclick=e=>{e.preventDefault();navigate(a.dataset.goto)});
  const off=!state.master_enabled,controllerOff=off||state.sections?.Controller===false;
  on('#sdLoad,#sdSave,[data-bank],#sdModeShortcuts,#sdModesRestore,[data-curve],#sdSplit',el=>el.disabled=el.matches('[data-curve],#sdSplit')?controllerOff:el.matches('[data-bank],#sdModeShortcuts')?(off||state.sections?.Modes===false):off);
  on('#sdLoad,#sdSave',el=>{if(state.sections?.Profiles===false){el.disabled=true;el.title='Profiles group is OFF. Restore it in Classic pages → Profiles.'}else if(off)el.title='Turn Controller + Remote Play ON to apply or save a profile.'});
  on('.kn',el=>{el.setAttribute('aria-disabled',String(controllerOff));el.tabIndex=controllerOff?-1:0});
  bindKnobs(box)}

/* ---------- command bar status + rail ---------- */
let sig='';
function sync(){const bar=document.querySelector('#cpStatus');if(!bar||!effective)return;const e=effective,s=state;
  const items=[[s.status==='Connected'?'ok':'warn','🎮 '+s.status,s.device?.name||'No controller'],[e.output.active?'ok':'off','⇢ Output '+(e.output.active?'ON':'OFF'),e.output.destination+' · '+e.output.frames+' writes'],['off','PS5 '+e.output.ps5_receipt,'PS5 received input'],[e.arming.helpers_armed?'ok':'off','Helpers '+(e.arming.helpers_armed?'ready':'off'),'Helpers armed state'],[e.save_status?.state==='modified'?'warn':'ok','📁 '+e.profile+(e.save_status?.state==='modified'?' ●':''),'Working profile'+(e.save_status?.state==='modified'?' · unsaved changes':'')]];
  const next=JSON.stringify(items);if(next!==sig){sig=next;bar.innerHTML=items.map(([c,t,title])=>`<span class="pill-s ${c}" title="${esc(title)}">${esc(t)}</span>`).join('')+`<button type="button" id="cpSave" title="Save the working profile">💾 Save</button>`;$('#cpSave').onclick=()=>act('profile_save',{name:effective.profile})}
  const p=cfg(),side=JSON.stringify([e.profile,profiles?.profiles,state.play_modes,gameSel,typeof gamePresets==='object'?Object.fromEntries(Object.entries(gamePresets).map(([g,v])=>[g,Object.keys(v)])):0,savedPreset(gameSel.game,gameSel.variant)&&presetMatches(savedPreset(gameSel.game,gameSel.variant)),p.deadzone,p.trigger_deadzone,p.curves,p.advanced.stick_deadzone,state.sections,state.master_enabled,e.save_status?.state]);
  if(side!==sideSig&&!sideBusy()){sideSig=side;renderSide()}}
function navHtml(current){const P=(p,l,i)=>`<button data-page="${p}" class="${p===current?'selected':''}"><span class="ni">${i||''}</span>${l||p}</button>`;
  const main=[['Live','','⚡'],['Tune','','🎚'],['Feel','','🎮'],['Controller','','🕹'],['Skills','','✦'],['Setups','','🗂'],['Tools','','🧰']].map(a=>P(...a)).join('');
  const ref=(referenceUI.pages||[]).map(p=>P(p,{'FC27 Controls & Skill Recipes':'Video & recipes'}[p]||p,'📖')).join('');
  const classic=['Overview','Builder','Responses','Actions','Helpers','Timing','Profiles','Recording','Modes','Diagnostics'].map(p=>P(p)).join('');
  return `<div class="nav-main">${main}</div><details class="nav-more"><summary>More pages</summary><div class="nav-sep">Reference</div>${ref}<div class="nav-sep">Classic pages</div>${classic}</details>`}
function init(){const h=document.querySelector('header');if(!h||document.querySelector('#cpStatus'))return;const s=document.createElement('div');s.id='cpStatus';h.insertBefore(s,h.querySelector('.actions'));
  const pad=document.createElement('button');pad.id='cpPads';pad.type='button';pad.textContent='🎮 Live pads';pad.setAttribute('aria-pressed','false');pad.title='Show or hide the two live controller pictures: what your controller is doing, and what this PC sends out.';pad.onclick=()=>{const o=$('#liveControllers').classList.toggle('open');pad.setAttribute('aria-pressed',String(o))};h.querySelector('.actions').prepend(pad);
  const side=document.createElement('div');side.id='cpSide';document.querySelector('aside')?.append(side);document.querySelector('aside')?.classList.add('setup-open');
  const setup=document.createElement('button');setup.id='cpSetup';setup.type='button';setup.textContent='⚙ Setup panel';setup.setAttribute('aria-expanded','true');setup.setAttribute('aria-controls','cpSide');setup.onclick=()=>{const open=document.querySelector('aside').classList.toggle('setup-open');setup.setAttribute('aria-expanded',String(open))};h.querySelector('.actions').prepend(setup)}

/* ---------- FEEL: movement and response tuner by role + setup delay ----------
   Pure planner (feelPlan) + one page. It only writes the same backbone helper switches and numbers the Tune cards write. */
const ROLES={
 def:{name:'Defense',icon:'🛡',mode:'Defender',needs:'Stay goal-side with quick turns, a calm jockey and sharp player switches. You still play the first safe pass out.',
  drop:{move:'sprintresp',drib:'cdr',pass:'cross',shoot:'shotmode',def:''},
  w:{move:1,sprint:.85,drib:.35,pass:.6,through:.35,cross:.25,shot:.2,jockey:1}},
 mid:{name:'Midfield',icon:'🎯',mode:'Creator',needs:'Accurate pass and through-ball aim, tight turns in traffic and steady dribbling. You still have to press and win the ball back.',
  drop:{move:'sprintresp',drib:'cdr',pass:'cross',shoot:'shotmode',def:'jockey'},
  w:{move:.85,sprint:.6,drib:.85,pass:1,through:1,cross:.7,shot:.5,jockey:.6}},
 att:{name:'Attack',icon:'🥅',mode:'Finisher',needs:'Accurate shot aim, sharp first steps and close control. Lay-offs and one-twos still decide chances, so passing stays tuned too.',
  drop:{move:'outer',drib:'cdr',pass:'cross',shoot:'',def:'jockey'},
  w:{move:.9,sprint:1,drib:1,pass:.7,through:.6,cross:.45,shot:1,jockey:.3}}};
const FRAME_MS=4,LAB_MS=4; // DualSense report spacing; Lab processing (~0.5 ms) + home network (~2.5 ms), measured 2026-10-14
const clampN=(v,lo,hi)=>Math.min(hi,Math.max(lo,v)),r2=v=>Math.round(v*100)/100;
/* average time the stick trails your thumb with smoothing at these numbers */
const smoothLag=(strength,windowMs)=>{const r=Math.exp(-FRAME_MS/Math.max(windowMs,.001))*strength/100;return r<=0?0:FRAME_MS*r/(1-r)};
/* What the player tells us about themselves. Every answer only nudges the plan; Skills is never touched, it is only filtered. */
const AREAS=[['move','Pace & movement','🏃'],['drib','Dribbling','⚽'],['pass','Passing & crossing','🎯'],['shoot','Shooting','🥅'],['def','Defending','🛡']];
const AREA_W={move:['move','sprint'],drib:['drib'],pass:['pass','through','cross'],shoot:['shot'],def:['jockey']};
const DEF_SPEC={role:'mid',remote:40,jitter:5,stars:3,wf:3,strength:'',weak:''};
const areaName=a=>(AREAS.find(x=>x[0]===a)||[])[1]||'';
let feelState=null;
const feelSt=()=>feelState||(feelState={...DEF_SPEC,...store.get('norex_feel',{})});
const skillFitOn=()=>!!store.get('norex_feel_skillfit',false);
const setSkillFit=v=>store.set('norex_feel_skillfit',!!v);
const skillFits=s=>!skillFitOn()||!s?.stars||s.stars<=feelSt().stars;
function feelPlan(roleId,remoteMs,jitterMs,cur,spec){cur=cur||{};
  const sp={...DEF_SPEC,...(spec||{})},stars=clampN(Math.round(+sp.stars||3),1,5),wf=clampN(Math.round(+sp.wf||3),1,5),
    strong=AREA_W[sp.strength]?sp.strength:'',weak=AREA_W[sp.weak]&&sp.weak!==strong?sp.weak:'';
  const R=ROLES[roleId]||ROLES.mid,w={...R.w},D=Math.max(0,+remoteMs||0)+LAB_MS,J=Math.max(0,+jitterMs||0),f=clampN(D/80,0,1),items=[];
  w.drib=clampN(w.drib*(.7+.1*stars),0,1.3);                       // more skill-move stars = more close control worth tuning
  if(weak)AREA_W[weak].forEach(k=>w[k]=Math.min(1.3,w[k]+.3));      // weak area: turn its helpers up
  if(strong)AREA_W[strong].forEach(k=>w[k]*=.7);                    // strength: lighter touch, your own feel leads
  const wfB=Math.round(10*(3-wf)/2),dropGoal=strong?R.drop[strong]:'';
  const wfWhy=wf<=2?` Passes and shots off a ${wf}★ weak foot drift most, so this aim help is turned up.`:wf>=4?` A ${wf}★ weak foot needs less help, so this is turned down a little.`:'';
  const dropWhy=`${areaName(strong)} is your strength, so this helper is left off and your own touch leads.`;
  const add=(goal,alt,h,params,why,group)=>{
    if(alt!==null&&goal===dropGoal)return items.push({goal,alt:null,h:null,params:{},why:dropWhy,group,on:false});
    items.push({goal,alt,h,params:params||{},why,group,on:alt!==null})};
  const addP=(goal,alt,paths,why,group,opt)=>{
    if(goal===dropGoal)return items.push({goal,alt:null,h:null,params:{},why:dropWhy,group,on:false});
    items.push({goal,alt,h:null,params:{},paths,group,on:true,why,opt:!!opt})};
  const add2=(id,paths,group,name,why)=>items.push({id,goal:null,name,paths,why,group,on:true});
  // 1. stick filter: smoothing only while the added lag stays tiny next to the delay you already have
  const sStrength=Math.round(clampN((28-D)*w.move,0,30));
  if(sStrength>=8&&J<8)add('filter','smooth','smoothing',{strength:sStrength,window_ms:10},`At ${D} ms total, a little smoothing calms thumb wobble and only adds about ${smoothLag(sStrength,10).toFixed(1)} ms. Above ~25 ms it starts stacking on the delay, so the tuner switches to Direction lock.`,'move');
  else add('filter','lock','direction_stability',{strength:Math.round(clampN(40+D/2-(roleId==='def'?10:0),30,75)),degrees:r2(clampN(4+D/15-(roleId==='def'?1:0),3,10))},`At ${D} ms${J>=8?` with ${J} ms of jitter`:''}, smoothing would make the stick trail your thumb. Direction lock adds no delay: it only ignores tiny angle wobbles, which you make more of when the game reacts late.${roleId==='def'?' Kept narrower for defenders so quick turns still go through.':''}`,'move');
  add('outer','new','outer_response',{strength:Math.round(clampN(40+30*f*w.move,0,100)),exponent:r2(clampN(.82-.25*f-(roleId==='def'?.05:0),.5,1))},'Your player hits full speed with a bit less stick travel. The more delay, the more this helps the run feel sharp again.','move');
  add('sprintresp','new','sprint_response',{strength:Math.round(clampN(30+30*w.sprint*(.5+f),0,100)),exponent:r2(clampN(.82-.28*f*w.sprint,.5,1))},'While R2 is held, the stick reaches full sprint direction sooner, which makes up for the late start that delay puts on sprint bursts.','move');
  add('precision','on','precision_stick',{strength:Math.round(clampN(35+35*w.drib,0,100)),exponent:r2(clampN(1.45+.5*f,1.2,2.4))},`Finer control near the centre of the stick. With delay you overcorrect small moves, so the curve gets a little finer as delay grows. Full push is unchanged.${stars>=4?` With ${stars}★ skill moves the close control gets more work, so it is a touch stronger.`:stars<=2?` With ${stars}★ skill moves it stays lighter.`:''}`,'drib');
  if(roleId==='def'&&stars<=2&&weak!=='drib')add('cdr',null,null,{},`With ${stars}★ skill moves and a defending role you will rarely do close-control dribbling, so the R1 dribble feel is left off.`,'drib');
  else add('cdr','new','controlled_dribble_response',{strength:Math.round(clampN(25+40*w.drib,0,100)),exponent:r2(clampN(1.45+.4*f,1.2,2.4))},'Tighter touches while you hold controlled dribble (R1): small stick moves turn into small turns.','drib');
  add('through','new','through_pass_response',{strength:Math.round(clampN(25+35*w.through+wfB,0,100)),exponent:r2(clampN(1.45+.5*f,1.2,2.4))},'Steadier aim on through balls, so a slight thumb wobble does not send the pass into the defender.'+wfWhy,'pass');
  add('cross','on','cross_response',{strength:Math.round(clampN(20+35*w.cross+wfB,0,100)),exponent:r2(clampN(1.45+.5*f,1.2,2.4))},'Steadier aim while you line up a cross.'+wfWhy,'pass');
  const wfHold=(wf<=2&&strong!=='pass')||weak==='pass',hold=(k,base,factor)=>Math.round(clampN((cur[k]??base)*factor,50,500)),fixHolds=D>=25||wfHold;
  // passing extras: only the types that fit this player
  if((roleId!=='def'&&w.pass>=.7||weak==='pass')&&strong!=='pass')addP('ctx_pass','on',{'advanced.contexts.pass.exponent':r2(clampN(1.2+.3*f,1.1,1.8))},'Finer stick aim while you hold the pass button, on top of the through-ball and cross aim, so short passes go where you point.','pass',weak!=='pass');
  if(((wf<=2&&roleId!=='att')||weak==='pass')&&strong!=='pass')addP('precision_pass','on',{},`Holds R1 with every pass, so you get the more careful pass type each time (your game controls decide the result).${wf<=2?` Worth trying with a ${wf}★ weak foot.`:''}`,'pass',weak!=='pass');
  // shooting: at high delay a fixed hold beats judging the power bar late; Shoot response then keeps the aim
  if(D>=40&&roleId!=='def'){
    addP('shotmode','timed',{'assists.shot_ms':hold('shot_ms',150,1)},`At ${D} ms you see the shot power bar about ${D} ms late, so shots held by eye fly high. Timed shot holds for an exact length every time. Trade-off: it replaces Shot response, so Shoot response (below) takes over the aim.`,'power');
    if(strong!=='shoot')addP('ctx_shoot','on',{'advanced.contexts.shoot.exponent':r2(clampN(1.2+.3*f,1.1,1.8))},'Finer stick aim while you hold shoot. It takes over from Shot response, which Timed shot switches off.','shoot')}
  else add('shotmode','resp','shot_response',{strength:Math.round(clampN(15+30*w.shot+wfB,0,100)),exponent:r2(clampN(1.45+.5*f,1.2,2.4))},'Finer shot aim while you hold shoot: a small push picks a corner without dragging the ball wide.'+wfWhy,'shoot');
  add('jockey','new','jockey_response',{strength:Math.round(clampN(25+45*w.jockey,0,100)),exponent:r2(clampN(1.3+.3*f-(roleId==='def'?.1:0),1.1,2))},'Calmer side-steps while you hold jockey (L2), so you stay in front of the attacker instead of over-shuffling.','def');
  if(roleId==='def'&&strong!=='def')addP('ctx_switch','on',{'advanced.contexts.switching.exponent':r2(clampN(.9-.1*f,.7,1))},'Sharper stick while you hold switch player, so a quick flick picks the defender you mean instead of the one next to him.','def',true);
  if(weak==='def'&&roleId!=='att')addP('auto_jockey','on',{},'Defending is your weak area, so L2 is held for you whenever you are not sprinting or pressing an attacking button. It cannot tell who has the ball, so switch it off when you attack.','def');
  if(fixHolds){
    items.push({goal:'timed_pass',alt:'on',h:null,params:{},paths:{'assists.pass_ms':hold('pass_ms',200,{def:.9,mid:1,att:.95}[roleId]||1)},group:'power',on:true,why:D>=25?`Holding by eye, every pass gets about ${D} ms of extra power-bar fill, because you let go when the bar looks right and the game sees it ${D} ms later. A fixed hold gives the same power every time.${roleId==='def'?' Slightly shorter for defenders: safe, firm passes out of the back.':roleId==='att'?' A touch shorter for quick lay-offs.':''}`:`A fixed hold gives every pass the same power, so power is one less thing to get wrong${wf<=2?` on passes off your ${wf}★ weak foot`:''}.`});
    if(roleId!=='def')items.push({goal:'timed_cross',alt:'on',h:null,params:{},paths:{'assists.cross_ms':hold('cross_ms',300,1)},group:'power',on:true,opt:true,why:D>=25?`Crosses have the longest power bar, so the ${D} ms overhit adds up fastest. A fixed hold keeps them from sailing over the box.`:'Crosses have the longest power bar, so a fixed hold keeps every one the same strength.'});}
  // sticks and triggers: the base layer every helper sits on top of
  const curveOf=k=>cur.curves?.[k]||{kind:'linear',exponent:1};
  add2('dz',{deadzone:r2(clampN(.08-.03*f-(roleId==='def'?.01:0),Math.min(.05,cur.deadzone??.05),.12))},'sticks','Left and right stick dead zone',`Anything inside this ring is ignored. A big ring means your first touch on the stick does nothing, which feels like extra delay on top of the ${D} ms you already have. Kept just wide enough for normal stick drift; if your player creeps when you let go, raise it a little.`);
  add2('left',{'curves.left':{...curveOf('left'),kind:'linear',exponent:1}},'sticks','Left stick base curve',`Kept straight on purpose. Precision stick, dribble, pass and shot aim already shape the left stick while you play; a curve here would stack on top and make it feel unpredictable.`);
  add2('right',{'curves.right':{...curveOf('right'),kind:'linear',exponent:1}},'sticks','Right stick base curve','Kept straight: the right stick does skill moves and player switching, which need clean flicks rather than a curve.');
  add2('tdz',{trigger_deadzone:r2(clampN(.03-.02*f,.01,.05))},'sticks','Trigger dead zone (R2 sprint, L2 jockey)',`How far you pull before sprint or jockey starts. With more delay a shorter pull helps; never 0, so a resting finger does not trigger it.`);
  const tex=r2(clampN(1-.35*f*Math.max(w.sprint,w.jockey),.6,1));
  add2('trig',{'curves.triggers':tex<.98?{...curveOf('triggers'),kind:'power',exponent:tex}:{...curveOf('triggers'),kind:'linear',exponent:1}},'sticks','Trigger curve',tex<.98?`Full sprint and full jockey arrive with less pull (curve ${tex}), which wins back some of the late start that ${D} ms puts on every burst.`:'Straight: at low delay a normal trigger pull already feels instant.');
  const notes=[D>=25?`Holding by eye with ${D} ms of delay, you overhit every pass and shot by about ${D} ms of power-bar fill. For the passes, crosses and shots you still power by hand, let go about ${D} ms before the bar looks right.`:wfHold?`At ${D} ms the overhit from holding by eye is tiny. Fixed pass holds are only added to steady your weaker-side passing.`:`At ${D} ms the overhit from holding by eye is tiny, so your pass and shot holds are left as they are. Fixed holds are suggested from 25 ms upwards.`];
  if(D>=40)notes.push(`Timed finishing: at ${D} ms your own second tap lands about ${D} ms late against what you see. The Lab's Shot follow-up keeps the gap between the two presses exact, because both presses get the same delay.`);
  if(J>=8)notes.push(`Jitter of ${J} ms changes the delay from press to press, and no setting can fully fix that. A cable between the PS5 and the PC usually removes most of it.`);
  if(weak)notes.push(`Weak area, ${areaName(weak).toLowerCase()}: its helpers are turned up${weak==='pass'||weak==='def'?' and an extra one is tried':''}. Test them in Practice Arena and back off anything that feels like too much.`);
  if(strong)notes.push(`Strength, ${areaName(strong).toLowerCase()}: its helpers are turned down so your own touch leads${dropGoal?', and one is left off':''}.`);
  return {role:R,totalMs:D,items,notes,spec:{stars,wf,strength:strong,weak},owned:GOALS.filter(g=>g.alts).map(g=>g.id)}}
const FEELG=[['sticks','Sticks & triggers','🕹'],['move','Movement','🏃'],['drib','Dribbling','⚽'],['pass','Passing','🎯'],['shoot','Shooting','🥅'],['def','Defending','🛡'],['power','Power & timing','⏱'],['sweep','Switched off: not part of this setup','🧹']];
const PLABEL={'assists.pass_ms':'Pass hold (ms)','assists.cross_ms':'Cross hold (ms)','assists.shot_ms':'Shot hold (ms)','advanced.contexts.pass.exponent':'Curve','advanced.contexts.shoot.exponent':'Curve','advanced.contexts.switching.exponent':'Curve',deadzone:'Dead zone',trigger_deadzone:'Dead zone','curves.left':'Curve','curves.right':'Curve','curves.triggers':'Curve'};
const FICON={dz:'⭕',left:'🕹',right:'🌀',tdz:'🎚',trig:'💨'};
const showV=v=>v&&typeof v==='object'?(v.kind==='linear'?'straight':v.kind+' '+r2(v.exponent)):r2(v);
const sameV=(a,b)=>a&&typeof a==='object'?!!b&&a.kind===b.kind&&(a.kind==='linear'||Math.abs((a.exponent??1)-(b.exponent??1))<1e-6):Math.abs(a-b)<1e-6;
const vals=it=>it.paths?Object.entries(it.paths).map(([p,v])=>[PLABEL[p]||p,v,p]):Object.entries(it.params).map(([k,v])=>[KLABEL[k]||k.replaceAll('_',' '),v,'backbone_helpers.'+it.h+'.'+k]);
function feelNow(it){const now=vals(it).map(([,,p])=>getPath(cfg(),p));if(!it.goal)return {cur:true,a:true,label:'',params:now};
  const g=byId(it.goal),cur=g&&activeAlt(g),a=it.alt===null?null:g?.alts.find(x=>x.k===it.alt);return {cur,a,label:cur?(g.alts.length>1?cur.l:'On'):'Off',params:cur===a?now:null}}
const fkey=it=>it.alt===null?'rm:'+it.goal:(it.goal||it.id);
const fpicks=()=>store.get('norex_feel_pick',{});
const shortWhy=t=>{const m=String(t).match(/^.*?[.!?](?=\s|$)/);return m?m[0]:String(t)};
function feelRow(it,i,ck){const n=feelNow(it),g=it.goal&&byId(it.goal),v=vals(it),off=it.alt===null,new_=v.map(([l,x])=>`${l} <b>${showV(x)}</b>`).join(' · '),
  name=g?esc(g.name)+(n.a&&g.alts.length>1?` · ${esc(n.a.l)}`:''):esc(it.name),now=[n.label,n.params?n.params.map(showV).join(' / '):''].filter(Boolean).join(' · ');
  return `<label class="fl-row${off?' rm':''}"><input type="checkbox" data-fi="${i}" ${ck?'checked':''}><span class="fl-i">${(g?ICONS[it.goal]:FICON[it.id])||'•'}</span><span class="fl-b"><b class="fl-n">${name}${it.opt?' <em class="fl-opt">optional</em>':''}</b><span class="fl-w">${esc(shortWhy(it.why))}${shortWhy(it.why).length<String(it.why).length?` <details class="fl-more"><summary>Why?</summary>${esc(it.why)}</details>`:''}</span></span><span class="fl-v" title="Now: ${esc(now)}"><span class="fl-new">${off?'Turn off':new_}</span></span></label>`}
const starRow=(key,n)=>`<span class="fl-stars" role="radiogroup" aria-label="${key==='stars'?'Skill moves':'Weak foot'} stars">${[1,2,3,4,5].map(i=>`<button type="button" role="radio" aria-checked="${i===n}" class="${i<=n?'on':''}" data-star="${key}" data-n="${i}" aria-label="${i} star${i>1?'s':''}">★</button>`).join('')}</span>`;
const areaChips=(key,val,other)=>`<span class="fl-chips" role="radiogroup" aria-label="${key==='strength'?'Strength':'Weak area'}">${[['','None']].concat(AREAS.map(a=>[a[0],a[2]+' '+a[1]])).map(([id,l])=>`<button type="button" role="radio" aria-checked="${id===val}" class="fl-chip${id===val?' on':''}" data-area="${key}" data-id="${id}" ${id&&id===other?'disabled':''}>${l}</button>`).join('')}</span>`;
function feel(){const s=feelSt(),save=()=>store.set('norex_feel',s),picks=fpicks();const P=feelPlan(s.role,s.remote,s.jitter,{pass_ms:getPath(cfg(),'assists.pass_ms'),cross_ms:getPath(cfg(),'assists.cross_ms'),shot_ms:getPath(cfg(),'assists.shot_ms'),deadzone:cfg().deadzone,curves:cfg().curves},s);
  // this plan owns the helpers: anything that is on but not part of it is offered for removal. Skills is never listed.
  const planned=new Set(P.items.map(i=>i.goal).filter(Boolean)),why=`Not part of the ${P.role.name} setup at ${P.totalMs} ms.`;
  const sweep=P.owned.filter(id=>!planned.has(id)).map(byId).filter(g=>activeAlt(g)).map(g=>({goal:g.id,alt:null,h:null,params:{},group:'sweep',on:false,why}));
  const all=[],done=[];
  [...P.items,...sweep].forEach(it=>{const n=feelNow(it),g=it.goal&&byId(it.goal),v=vals(it),off=it.alt===null;
    if(off&&!n.cur)return;                                                   // already off: nothing to show
    const same=n.cur===n.a&&n.params&&n.params.every((x,j)=>sameV(v[j][1],x)),blk=g&&n.a&&blocked(n.a);
    if(same||blk){done.push({it,blk});return}
    all.push(it)});
  const ck=it=>picks[fkey(it)]??!it.opt,isRm=it=>it.alt===null,rows=f=>all.map((it,i)=>[it,i]).filter(([it])=>f(it));
  const rec=rows(it=>!isRm(it)&&!it.opt),opt=rows(it=>!isRm(it)&&it.opt),rm=rows(isRm);
  let fit='',total='';try{const r=allSkillRows();total=r.length;fit=r.filter(x=>!x.stars||x.stars<=P.spec.stars).length}catch{}
  $('#content').innerHTML=`<section class="feel"><h2 class="phase-h"><span class="ph-i">🎮</span>Feel tuner</h2>
   <p class="fl-lead">Pick your position and delay, check the list, press Apply. Skills are never changed.</p>
   ${state.sections?.Helpers===false?'<p class="fl-warn">The Helpers group is OFF, so none of this takes effect. Turn it on from the Live tab first.</p>':''}
   <h3 class="fl-g">1 · Your position</h3><div class="fl-roles" role="radiogroup" aria-label="Role">${Object.entries(ROLES).map(([id,r])=>`<button type="button" role="radio" aria-checked="${id===s.role}" data-role="${id}" class="fl-role${id===s.role?' on':''}"><span class="fl-ri">${r.icon}</span><b>${r.name}</b><small>${esc(r.needs)}</small><em>Saves to ${r.mode} mode</em></button>`).join('')}</div>
   <h3 class="fl-g">2 · Your delay</h3><div class="fl-delay"><label>Remote Play delay <small>your estimate or slow-motion test</small><span><input type="range" min="0" max="150" step="1" value="${s.remote}" data-fd="remote"><input type="number" min="0" max="400" value="${s.remote}" data-fd="remote" aria-label="Remote Play delay in ms"> ms</span></label>
    <label>Jitter <small>how much it jumps around</small><span><input type="range" min="0" max="40" step="1" value="${s.jitter}" data-fd="jitter"><input type="number" min="0" max="100" value="${s.jitter}" data-fd="jitter" aria-label="Jitter in ms"> ms</span></label>
    <div class="fl-total"><b>${P.totalMs} ms</b><small>total = Remote Play + ${LAB_MS} ms Lab and network</small></div></div>
   <details class="fl-pl"><summary>3 · Your player <small>optional: ${P.spec.stars}★ skill moves · ${P.spec.wf}★ weak foot · ${P.spec.strength?'strong: '+areaName(P.spec.strength).toLowerCase():'no strength set'} · ${P.spec.weak?'weak: '+areaName(P.spec.weak).toLowerCase():'no weak area set'}</small></summary><div class="fl-spec">
    <div class="fl-sp"><b>Skill moves</b><small>Also filters your Skills list</small>${starRow('stars',P.spec.stars)}</div>
    <div class="fl-sp"><b>Weak foot</b><small>Fewer stars = more aim and power help</small>${starRow('wf',P.spec.wf)}</div>
    <div class="fl-sp"><b>One strength</b><small>Helped less, your own touch leads</small>${areaChips('strength',P.spec.strength,P.spec.weak)}</div>
    <div class="fl-sp"><b>One weak area</b><small>Helped more, with extra helpers to try</small>${areaChips('weak',P.spec.weak,P.spec.strength)}</div></div></details>
   <p class="fl-sum"><b>${P.role.name}:</b> ${rec.length} recommended · ${opt.length} optional · ${rm.length} to remove${done.length?` · ${done.length} already fine`:''}</p>
   ${rec.length?`<h3 class="fl-g">4 · Recommended for ${P.role.name} <small>ticked, ready to apply</small></h3>`+FEELG.map(([id,name,ico])=>{const r=rec.filter(([it])=>it.group===id);return r.length?`<h4 class="fl-g2">${ico} ${name}</h4>${r.map(([it,i])=>feelRow(it,i,ck(it))).join('')}`:''}).join(''):''}
   ${opt.length?`<h3 class="fl-g">Optional <small>tick any you like</small></h3>${opt.map(([it,i])=>feelRow(it,i,ck(it))).join('')}`:''}
   ${rm.length?`<h3 class="fl-g">Switch off <small>on now but not needed here · untick to keep one</small></h3>${rm.map(([it,i])=>feelRow(it,i,ck(it))).join('')}`:''}
   ${done.length?`<details class="fl-done"><summary>${done.length} need no change</summary>${done.map(({it,blk})=>{const g=it.goal&&byId(it.goal);return `<p><b>${g?esc(g.name):esc(it.name)}</b> <span>${blk?'Blocked: '+esc(blk.split('\n')[0]):it.alt===null?'Already off':'Already set'}</span></p>`}).join('')}</details>`:''}
   <h3 class="fl-g">✦ Skills <small>works alongside, never changed by Apply</small></h3>
   <div class="fl-sk"><span class="fl-i">✦</span><span class="fl-b"><b class="fl-n">Skills stay fully active</b><span class="fl-w">Bindings, lists, shortcuts and direction are not touched. ${total?`With ${P.spec.stars}★ skill moves, ${fit} of ${total} moves match your player.`:`Your ${P.spec.stars}★ rating decides which moves the Skills list shows.`}</span></span><span class="fl-skb"><button type="button" id="flSkillFit" aria-pressed="${skillFitOn()}" class="${skillFitOn()?'on':''}">${skillFitOn()?'✓ ':''}Only moves up to ${P.spec.stars}★</button><button type="button" id="flOpenSkills">Open Skills</button></span></div>
   <details class="fl-notes-d"><summary>Notes (${P.notes.length})</summary><div class="fl-notes">${P.notes.map(n=>`<p>ℹ ${esc(n)}</p>`).join('')}</div></details>
   <div class="fl-act"><button type="button" id="flApply" class="primary">Apply ticked</button><button type="button" id="flMode">Apply and save as ${P.role.mode} mode</button></div></section>`;
  const root=$('#content');
  root.querySelectorAll('[data-role]').forEach(b=>b.onclick=()=>{s.role=b.dataset.role;save();feel();root.querySelector('.fl-sum')?.scrollIntoView?.({block:'center'})});
  root.querySelectorAll('[data-fd]').forEach(el=>{el.oninput=()=>{const k=el.dataset.fd;s[k]=clampN(Math.round(+el.value||0),0,400);root.querySelectorAll(`[data-fd="${k}"]`).forEach(o=>{if(o!==el)o.value=s[k]});clearTimeout(feel.t);feel.t=setTimeout(()=>{save();feel()},el.type==='range'?120:400)}});
  root.querySelectorAll('[data-star]').forEach(b=>b.onclick=()=>{s[b.dataset.star]=+b.dataset.n;if(b.dataset.star==='stars')setSkillFit(true);save();feel()});
  root.querySelectorAll('[data-area]').forEach(b=>b.onclick=()=>{const k=b.dataset.area,o=k==='strength'?'weak':'strength';s[k]=b.dataset.id;if(s[k]&&s[k]===s[o])s[o]='';save();feel()});
  root.querySelectorAll('[data-fi]').forEach(c=>c.onchange=()=>{const m=fpicks();m[fkey(all[+c.dataset.fi])]=c.checked;store.set('norex_feel_pick',m)});
  $('#flSkillFit').onclick=()=>{setSkillFit(!skillFitOn());feel()};$('#flOpenSkills').onclick=()=>navigate('Skills');
  const chosen=()=>[...root.querySelectorAll('[data-fi]:checked')].map(c=>all[+c.dataset.fi]);
  const apply=async()=>{const list=chosen();if(!list.length)return false;await commit(q=>list.forEach(it=>{const g=it.goal&&byId(it.goal);if(g){g.alts.forEach(x=>setProfilePath(q,x.p,false));const a=it.alt===null?null:g.alts.find(x=>x.k===it.alt);if(a)setProfilePath(q,a.p,true)}
    vals(it).forEach(([,v,p])=>setProfilePath(q,p,v))}));return true};
  $('#flApply').onclick=()=>apply();
  $('#flMode').onclick=async()=>{if(await apply())act('mode_save',{name:P.role.mode},true)}}

/* ---------- command palette (Ctrl+K or /) ---------- */
function commands(){const out=[];const go=(t,fn,k)=>out.push({t,fn,k:k||''});
  [['Live','⚡'],['Tune','🎚'],['Feel','🎮'],['Controller','🕹'],['Skills','✦'],['Setups','🗂'],['Tools','🧰']].forEach(([p,i])=>go(i+' Go to '+p,()=>navigate(p),'page'));
  (referenceUI.pages||[]).forEach(p=>go('📖 Open '+p,()=>navigate(p),'page'));
  ['Overview','Builder','Responses','Actions','Helpers','Timing','Profiles','Recording','Modes','Diagnostics'].forEach(p=>go('Classic page: '+p,()=>navigate(p),'page'));
  go('Normal processing',()=>act('set_mode',{mode:'RAW'}),'mode');go('Custom processing',()=>act('set_mode',{mode:'NOREX'}),'mode');
  go(state.master_enabled?'Turn Controller + Remote Play OFF':'Turn Controller + Remote Play ON',()=>act('master_power',{enabled:!state.master_enabled},true),'power');
  go('🛑 Emergency stop',()=>act('emergency_stop'),'stop');
  toggles().forEach(g=>{const cur=activeAlt(g);go((cur?'Turn off: ':'Turn on: ')+g.name,()=>toggleGoal(g),'toggle');if(g.alts.length>1)g.alts.forEach(a=>go(g.name+' → '+a.l,()=>{rememberAlt(g,a);selectAlt(g,a)},'toggle'))});
  GAMES.forEach(g=>VARIANTS.forEach(v=>{if(savedPreset(g,v))go('🎮 Game: '+g+' · '+v,()=>applyPreset(g,v),'game')}));go('💾 Save current as '+gameSel.game+' · '+gameSel.variant,savePreset,'game');
  (state.play_modes?.names||[]).forEach(n=>go('Mode bank: '+n,()=>act('mode_select',{name:n},true),'mode'));
  ['Helpers','Skills','Controller'].forEach(s=>go(s+' group '+(state.sections?.[s]!==false?'OFF':'ON'),()=>act('section_power',{section:s,enabled:state.sections?.[s]===false},true),'group'));
  (profiles?.profiles||[]).forEach(n=>go('Load profile: '+n,()=>act('profile_load',{name:n}),'profile'));
  go('Save working profile',()=>act('profile_save',{name:effective.profile}),'profile');
  (state.assists?.catalog||[]).filter(s=>s.ready).forEach(s=>go('▶ Play move: '+s.name,async()=>{try{await skillTools.playMove(s.name);notice('Move sent.')}catch(e){notice(e.message,true)}},'skill'));
  return out}
function openPalette(){if(document.querySelector('#cpPalette'))return;closePop();const items=commands();const d=document.createElement('div');d.id='cpPalette';d.innerHTML=`<div class="pal" role="dialog" aria-label="Command palette"><input id="palIn" placeholder="Type a command: toggle, mode, page, move, profile…" aria-label="Command"><div id="palList" role="listbox"></div><small class="muted">↑ ↓ choose · Enter run · Esc close</small></div>`;document.body.append(d);
  const input=d.querySelector('#palIn'),list=d.querySelector('#palList');let sel=0,shown=[];
  const draw=()=>{const q=input.value.toLowerCase().split(/\s+/).filter(Boolean);shown=items.filter(i=>q.every(w=>i.t.toLowerCase().includes(w))).sort((a,b)=>(q.length?a.t.toLowerCase().indexOf(q[0])-b.t.toLowerCase().indexOf(q[0]):0)).slice(0,40);sel=Math.min(sel,Math.max(0,shown.length-1));list.innerHTML=shown.map((i,n)=>`<div role="option" class="pi${n===sel?' sel':''}" data-n="${n}" aria-selected="${n===sel}">${esc(i.t)}<small>${esc(i.k)}</small></div>`).join('')||'<p class="muted pad">No matching command.</p>';list.querySelectorAll('.pi').forEach(el=>el.onclick=()=>run(Number(el.dataset.n)))};
  const close=()=>{d.remove()};const run=n=>{const i=shown[n];close();i&&i.fn()};
  input.oninput=()=>{sel=0;draw()};input.onkeydown=e=>{if(e.key==='ArrowDown'){sel=Math.min(shown.length-1,sel+1);draw();e.preventDefault()}else if(e.key==='ArrowUp'){sel=Math.max(0,sel-1);draw();e.preventDefault()}else if(e.key==='Enter'){run(sel);e.preventDefault()}else if(e.key==='Escape'){close()}};
  d.onclick=e=>{if(e.target===d)close()};draw();input.focus()}
document.addEventListener?.('keydown',e=>{const typing=/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName||'');if((e.key==='k'&&(e.ctrlKey||e.metaKey))||(e.key==='/'&&!typing&&!e.ctrlKey&&!e.metaKey)){if(!effective)return;e.preventDefault();openPalette()}});

feel.api={feelSpec:feelSt,skillFits,skillFitOn,setSkillFit}; // used by the Skills page filter
return {live,tune,feel,feelPlan,ROLES,setups,tools,sync,init,navHtml,refreshPop,goals:GOALS,openPalette,PHASES};
})();
