from unittest.mock import Mock,patch
import unittest
import test_command_center as master_tests
from command_center import power
from section_controls import toggle,SECTIONS
from remoteplay_settings import RemotePlaySettings

class SectionSwitchTests(unittest.TestCase):
    setUp=master_tests.MasterTests.setUp
    def test_helpers_off_restores_without_affecting_controller(self):
        power(self.r,True);p=self.r.profile;p['assists']['precision_pass']=True;p['backbone_helpers']['smoothing']['enabled']=True;p['deadzone']=.2
        toggle(self.r,'Helpers',False)
        self.assertFalse(self.r.profile['assists']['precision_pass']);self.assertFalse(self.r.profile['backbone_helpers']['smoothing']['enabled']);self.assertEqual(self.r.profile['deadzone'],.2)
        toggle(self.r,'Helpers',True);self.assertTrue(self.r.profile['assists']['precision_pass']);self.assertTrue(self.r.profile['backbone_helpers']['smoothing']['enabled'])
    def test_disabled_section_cannot_be_reenabled_by_profile_edit(self):
        power(self.r,True);toggle(self.r,'Helpers',False)
        import copy
        p=copy.deepcopy(self.r.profile);p['assists']['precision_pass']=True;self.r.apply_profile(p)
        self.assertFalse(self.r.profile['assists']['precision_pass'])
    def test_all_sections_switch_and_block_while_master_off(self):
        power(self.r,True)
        for section in SECTIONS:
            toggle(self.r,section,False);self.assertFalse(self.r.sections[section]);toggle(self.r,section,True);self.assertTrue(self.r.sections[section])
        power(self.r,False)
        with self.assertRaises(ValueError):toggle(self.r,'Helpers',False)
        with self.assertRaises(ValueError):self.r.action({'action':'configure','profile':self.r.profile})
    def test_master_restores_custom_settings_next_on(self):
        power(self.r,True);self.r.profile['deadzone']=.23;toggle(self.r,'Helpers',False)
        power(self.r,False);self.assertNotEqual(self.r.profile['deadzone'],.23)
        power(self.r,True);self.assertEqual(self.r.profile['deadzone'],.23);self.assertFalse(self.r.sections['Helpers'])
    def test_master_starts_one_chiaki_and_closes_owned_children(self):
        self.r.require_remoteplay=True;proc=Mock();proc.poll.return_value=None
        self.r.remoteplay.connect=Mock(return_value=proc)
        power(self.r,True);power(self.r,True);self.r.remoteplay.connect.assert_called_once();self.assertIs(self.r.remote_session,proc)
        with patch.object(self.r.owned_sessions,'close',return_value=[]) as close:
            power(self.r,False);close.assert_called_once();self.assertIsNone(self.r.remote_session)
    def test_chiaki_launch_failure_rolls_back(self):
        self.r.require_remoteplay=True;self.r.remoteplay.connect=Mock(side_effect=ValueError('no console'))
        with self.assertRaises(ValueError):power(self.r,True)
        self.assertFalse(self.r.master_enabled);self.assertIsNone(self.r.output)
    def test_qt_registered_identity(self):
        self.assertEqual(RemotePlaySettings.host_identity(r'@ByteArray(\xe8n:hEx)'), 'e86e3a684578')
        self.assertEqual(RemotePlaySettings.host_identity('e8:6e:3a:68:45:78'),'e86e3a684578')
