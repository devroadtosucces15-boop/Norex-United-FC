"""Bounded, local input processing trace; never a console receipt claim."""
import collections,json,time,math
class InputAudit:
 def __init__(self,data):
  self.path=data/'input-audit.jsonl';self.rows=collections.deque(maxlen=100);self.seq=0;self.last_signature=None;self.last_buttons=None;self.last_ns=0;self.error=None
 @staticmethod
 def controls(a,b):return {**{k:round(float(v),2) for k,v in a.items()},**{k:bool(v) for k,v in b.items()}}
 def note(self,text,warning=False):self.append({'input':text,'activated':[],'priority':[],'conflicts':[],'warning':warning,'kind':'setting'})
 def append(self,row):
  self.seq+=1;row={**row,'id':self.seq,'time':time.strftime('%H:%M:%S'),'timestamp':time.time()};self.rows.append(row)
  try:
   if self.path.exists() and self.path.stat().st_size>2*1024*1024:self.path.replace(self.path.with_suffix('.previous.jsonl'))
   with self.path.open('a') as f:f.write(json.dumps(row,separators=(',',':'))+'\n')
  except OSError as e:self.error=str(e)
 def observe(self,a,b,stages,activated,now,context_conflicts=(),metadata=None):
  buttons=tuple(k for k,v in b.items() if v)+tuple(-1 if math.hypot(a.get(x,0),a.get(y,0))<.12 else round(math.atan2(a.get(y,0),a.get(x,0))/(math.pi/4))%8 for x,y in [('LX','LY'),('RX','RY')])
  if buttons==self.last_buttons and now-self.last_ns<200_000_000:return
  physical=self.controls(a,b);signature=json.dumps([physical,stages[-1][1:] if stages else [],activated,metadata],sort_keys=True,default=str)
  if signature==self.last_signature:return
  if buttons==self.last_buttons and now-self.last_ns<200_000_000:return
  self.last_signature=signature;self.last_buttons=buttons;self.last_ns=now
  current=physical;writers={};changed={}
  for label,axes,keys in stages:
   nxt=self.controls(axes,keys)
   for key in set(current)|set(nxt):
    if current.get(key,False)!=nxt.get(key,False):writers.setdefault(key,[]).append(label);changed[key]=nxt.get(key,False)
   current=nxt
  conflicts=[{'control':k,'settings':v,'winner':v[-1]} for k,v in writers.items() if len(v)>1]
  conflicts.extend(context_conflicts)
  pressed=tuple(k for k,v in b.items() if v)
  nonzero=[f'{k}={v:g}' for k,v in a.items() if abs(v)>.04]
  self.append({**(metadata or {}),'kind':'input','input':(' + '.join(pressed+tuple(nonzero)) or 'Released / neutral'),'activated':list(dict.fromkeys(activated)),'priority':[f'{k}: {v[-1]}' for k,v in writers.items()],'conflicts':conflicts,'warning':bool(conflicts),'output_changes':changed})
 def status(self):return {'events':list(self.rows),'error':self.error,'log':'input-audit.jsonl','scope':'Host processing only; PS5 receipt unverified'}
