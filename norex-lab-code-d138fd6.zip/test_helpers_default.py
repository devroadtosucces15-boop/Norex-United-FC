import unittest
from pipeline import default_profile,validate_profile
from helpers_default import helpers_off
from assists import TOGGLES

class HelpersDefaultTests(unittest.TestCase):
 def test_helpers_off_clears_everything_and_stays_valid(self):
  p=default_profile()
  for t in TOGGLES:p['assists'][t]=True
  p['advanced']['contexts']['shoot']['enabled']=True;p['advanced']['triggers']['L2']['enabled']=True;p['advanced']['stick_deadzone']['enabled']=True
  p['play_tools']['outer']['enabled']=True;p['play_tools']['shot_response']['enabled']=True
  for row in p['backbone_helpers'].values():
   if isinstance(row,dict) and 'enabled' in row:row['enabled']=True
  q=helpers_off(p);validate_profile(q)
  self.assertFalse(any(q['assists'][t] for t in TOGGLES))
  self.assertFalse(q['advanced']['contexts']['shoot']['enabled'] or q['advanced']['triggers']['L2']['enabled'] or q['advanced']['stick_deadzone']['enabled'])
  self.assertFalse(q['play_tools']['outer']['enabled'] or q['play_tools']['shot_response']['enabled'])
  self.assertFalse(any(r.get('enabled') for r in q['backbone_helpers'].values() if isinstance(r,dict)))
  self.assertTrue(p['assists']['timed_shot'])  # input untouched
