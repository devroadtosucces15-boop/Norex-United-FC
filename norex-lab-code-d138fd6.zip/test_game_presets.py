import tempfile,unittest
from pathlib import Path
import game_presets as G

class GamePresetTests(unittest.TestCase):
    def setUp(self):self.d=Path(tempfile.mkdtemp())
    def test_save_read_delete(self):
        self.assertEqual(G.read(self.d),{'presets':{}})
        G.save(self.d,'Rush','Base',{'assists.timed_pass':True,'assists.pass_ms':180,'advanced.shortcuts.chip':'Circle'})
        row=G.read(self.d)['presets']['Rush']['Base']['values']
        self.assertEqual(row['assists.pass_ms'],180)
        G.save(self.d,'Rush','Attack',{'assists.timed_pass':False})
        G.delete(self.d,'Rush','Base');self.assertEqual(list(G.read(self.d)['presets']['Rush']),['Attack'])
        G.delete(self.d,'Rush','Attack');self.assertEqual(G.read(self.d)['presets'],{})
    def test_rejects_bad_input(self):
        for game,variant,values in [('Pro','Base',{'a.b':1}),('Rush','Mid',{'a.b':1}),('Rush','Base',{}),('Rush','Base',{'bad key':1}),('Rush','Base',{'a.b':[1]}),('Rush','Base',{'a.b':10**9}),('Rush','Base',{'../x.y':1})]:
            with self.assertRaises(ValueError):G.save(self.d,game,variant,values)
