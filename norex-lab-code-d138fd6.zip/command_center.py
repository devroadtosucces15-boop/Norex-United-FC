"""One process owner and safe cleanup of children created by this Lab."""
import fcntl
import os
from pathlib import Path
import signal
import subprocess

class Owner:
    def __init__(self, path=None, error=SystemExit):
        directory=Path(os.environ.get('XDG_RUNTIME_DIR',f'/run/user/{os.getuid()}'))
        self.file=open(path or directory/'norex-controller-owner.lock','a+')
        try: fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            self.file.close()
            raise error('A Controller Lab engine already owns this session. Open http://127.0.0.1:8790')
    def close(self):self.file.close()

def conflicts():
    found=[]
    for entry in Path('/proc').glob('[0-9]*'):
        if entry.name==str(os.getpid()):continue
        try:
            parts=(entry/'cmdline').read_bytes().decode(errors='replace').split('\0')
            args=' '.join(parts)
            cwd=(entry/'cwd').resolve()
            for arg in parts[1:]:
                if arg.endswith('.py'):args+=' '+str((cwd/arg).resolve())
            executable=Path((entry/'comm').read_text().strip()).name.lower()
            if executable in ('chiaki','chiaki-ng') and len(parts)>1 and parts[1] in ('--help','--help-all','discover','list'):continue
            if executable in ('chiaki','chiaki-ng','remoteplay','psremoteplay') or ('python' in executable and any(x in args for x in ('norex-gateway/app.py','norex-gateway/livebox.py','norex-ps5-gateway/app.py','norex-ps5-gateway/livebox.py','network-console','network_console'))):
                found.append(f'{entry.name}: {executable}')
        except (OSError,ValueError):pass
    return found

class OwnedSessions:
    def __init__(self):self.children=[]
    def start(self,argv):
        # Child process groups belong exclusively to this supervisor.
        p=subprocess.Popen(argv,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        self.children.append(p);return p
    def close(self):
        errors=[]
        for p in self.children:
            if p.poll() is not None:continue
            try:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2)
            except (OSError,subprocess.TimeoutExpired) as e:errors.append(str(e))
        self.children=[p for p in self.children if p.poll() is None]
        return errors

def save_setup(r):
    from profile_store import snapshot,write_atomic
    document={'snapshot':snapshot(r,r.profile),'sections':r.sections,
              'section_saved':{k:[[list(path),value] for path,value in rows.items()] for k,rows in r.section_saved.items()}}
    if r.section_modes is not None:
        import copy
        candidate=copy.copy(r);candidate.mode_bank=r.section_modes
        document['section_modes']=snapshot(candidate,r.profile)
    write_atomic(r.data/'master-saved.json',document)

def power(r,enabled):
    if type(enabled) is not bool:raise ValueError('Expected true/false')
    if enabled and r.master_enabled:return
    if enabled:
        overlap=conflicts()
        if overlap:raise ValueError('Close the existing Lab/network-console/gateway/Remote Play session first: '+', '.join(overlap))
        if r.status!='Connected':raise ValueError('Connect the physical controller first')
        try:
            from profile_store import restore,validate_snapshot
            import json
            saved=r.data/'master-saved.json'
            if saved.exists():
                document=json.loads(saved.read_text())
                r.sections=document['sections']
                r.section_saved={k:{tuple(path):value for path,value in rows} for k,rows in document.get('section_saved',{}).items()}
                restore(r,validate_snapshot(document['snapshot'],r.mode_bank))
                if document.get('section_modes'):
                    r.section_modes=validate_snapshot(document['section_modes'],r.mode_bank)[2]
            elif r.suspended_settings is not None:
                import copy
                r.profile,r.base_profile,r.mode_bank=copy.deepcopy(r.suspended_settings)
            from helpers_default import helpers_off,restore_requested
            if not restore_requested(r.data):
                r.profile=helpers_off(r.profile);r.base_profile=helpers_off(r.base_profile)
            r.custom_enabled=True;r.new_output('physical');r.master_enabled=True;r.arm_current();r.on_frame()
            if r.require_remoteplay:
                r.remote_session=r.remoteplay.connect(spawn=r.owned_sessions.start)
                if r.remote_session.poll() is not None:raise ValueError('Chiaki could not open; custom input returned OFF')
            if r.output is None:raise ValueError(r.output_error or 'Output failed')
        except Exception:
            power(r,False);raise
        return
    if r.master_enabled:
        import copy
        r.suspended_settings=copy.deepcopy((r.profile,r.base_profile,r.mode_bank))
        save_setup(r)
    r.master_enabled=False;r.custom_enabled=False;r.startup_arm_pending=False;r.assists_armed=False
    r.end_record();r.stop_replay();r.finish_frames('Master OFF');r.finish_comparison()
    if r.output:
        try:r.output.neutralize()
        except OSError as e:r.output_error=str(e)
    r.close_output('Master OFF');r.assist_engine.reset();r.advanced_engine.reset();r.helper_engine.reset();r.play_tools.reset();r.processing_pipeline.reset()
    r.compare_state.finish('Master OFF');r.compare_state.set_mode('NOREX')
    from pipeline import default_profile,neutral_frame
    from play_tools import ModeBank
    import copy
    r.profile=default_profile();r.base_profile=copy.deepcopy(r.profile);r.mode_bank=ModeBank(r.data,r.profile,load_saved=False)
    r.active_mode='None';r.defending=False;r.resume_helpers=False;r.cal=None;r.cal_result=None;r.binding_report=[];r.profile_result=None
    r.physical_frame=neutral_frame();r.cleanup_errors=r.owned_sessions.close();r.remote_session=None
    # Clear startup selection without replacing named profile archives.
    from profile_store import write_atomic
    write_atomic(r.data/'startup-profile.json',r.profile)
    write_atomic(r.control_path,{'custom_enabled':False})
    r.revision+=1
