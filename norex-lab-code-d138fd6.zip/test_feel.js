// Feel tuner: every recommendation stays inside the helper's real limits and reacts to delay in the intended direction.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),{execFileSync}=require('child_process');
const ctx={document:{addEventListener(){},querySelector(){return null}},localStorage:{getItem(){return null},setItem(){}},window:{}};vm.createContext(ctx);
vm.runInContext(fs.readFileSync('ui/cockpit.js','utf8')+';this.__c=cockpit',ctx);
const c=ctx.__c,goals=new Map(c.goals.map(g=>[g.id,g]));
const H=JSON.parse(execFileSync('python3',['-c',"import json;from backbone.helper_contract import HELPERS as H;print(json.dumps({k:v.get('parameters',{}) for k,v in H.items()}))"],{encoding:'utf8'}));
const pick=(p,goal)=>p.items.find(i=>i.goal===goal||i.id===goal),plans=[];
for(const role of Object.keys(c.ROLES))for(const d of [0,10,20,40,80,150])for(const j of [0,5,20]){
  const p=c.feelPlan(role,d,j);
  p.items.forEach(it=>{if(it.goal){const g=goals.get(it.goal);assert(g,'unknown goal '+it.goal);if(it.alt===null)return;const a=g.alts.find(x=>x.k===it.alt);assert(a&&(a.h||null)===(it.h||null),`${it.goal}/${it.alt} must be the ${it.h} version`)}
    Object.entries(it.params||{}).forEach(([k,v])=>{const lim=H[it.h]?.[k];assert(lim,`${it.h}.${k} is not a real setting`);assert(v>=lim.min&&v<=lim.max,`${role} ${d}ms ${it.h}.${k}=${v} outside ${lim.min}-${lim.max}`)})});
  plans.push(p);
  ['through','cross','shotmode','jockey','precision'].forEach(id=>assert(pick(p,id),`${role} must still tune ${id}`));
}
assert.equal(pick(c.feelPlan('mid',0,0),'filter').alt,'smooth','low delay keeps light smoothing');
assert.equal(pick(c.feelPlan('mid',60,0),'filter').alt,'lock','high delay swaps smoothing for direction lock');
assert.equal(pick(c.feelPlan('mid',0,20),'filter').alt,'lock','high jitter avoids smoothing');
const ex=(r,d,id)=>pick(c.feelPlan(r,d,5),id).params.exponent;
for(const r of Object.keys(c.ROLES)){assert(ex(r,100,'precision')>=ex(r,0,'precision'),'more delay = finer centre');assert(ex(r,100,'sprintresp')<=ex(r,0,'sprintresp'),'more delay = quicker sprint response')}
assert(pick(c.feelPlan('def',40,5),'jockey').params.strength>pick(c.feelPlan('att',40,5),'jockey').params.strength,'defenders get the strongest jockey tuning');
assert(pick(c.feelPlan('att',20,5),'shotmode').params.strength>pick(c.feelPlan('def',20,5),'shotmode').params.strength,'attackers get the strongest shot tuning');
// power: fixed holds only once the overhit matters; attackers swap to a fixed shot hold at high delay, defenders keep shot aim
assert(!pick(c.feelPlan('mid',10,0),'timed_pass'),'no fixed holds at low delay');
assert(pick(c.feelPlan('mid',40,0),'timed_pass'),'fixed pass hold at 44 ms');
assert.equal(pick(c.feelPlan('att',60,0),'shotmode').alt,'timed');assert.equal(pick(c.feelPlan('def',60,0),'shotmode').alt,'resp');
assert(pick(c.feelPlan('def',40,0,{pass_ms:200}),'timed_pass').paths['assists.pass_ms']<200,'defenders get firmer, shorter passes');
assert(c.feelPlan('mid',40,0).notes[0].includes('44 ms'),'overhit note names the delay');
// sticks: more delay = smaller dead zone and a lighter trigger pull, never below safe floors
assert(pick(c.feelPlan('mid',100,0),'dz').paths.deadzone<=pick(c.feelPlan('mid',0,0),'dz').paths.deadzone);
assert(pick(c.feelPlan('def',100,0),'tdz').paths.trigger_deadzone>=.01);
assert.equal(pick(c.feelPlan('att',100,0),'trig').paths['curves.triggers'].kind,'power');
// every plan, fully applied, must pass the Lab's own profile validation
const set=(o,p,v)=>{const k=p.split('.'),l=k.pop();k.reduce((n,x)=>n[x],o)[l]=v};
const base=JSON.parse(execFileSync('python3',['-c','import json;from pipeline import default_profile as d;print(json.dumps(d()))'],{encoding:'utf8'}));
const out=plans.filter((_,i)=>i%7===0).map(p=>{const q=JSON.parse(JSON.stringify(base));p.items.forEach(it=>{if(it.goal){const g=goals.get(it.goal);g.alts.forEach(x=>set(q,x.p,false));set(q,g.alts.find(x=>x.k===it.alt).p,true)}
  Object.entries(it.paths||{}).forEach(([k,v])=>set(q,k,v));Object.entries(it.params||{}).forEach(([k,v])=>set(q,'backbone_helpers.'+it.h+'.'+k,v))});return q});
execFileSync('python3',['-c','import json,sys;from pipeline import validate_profile as v\nfor q in json.load(sys.stdin):v(q)'],{input:JSON.stringify(out)});
// player facts: stars, weak foot, one strength and one weak area add or remove helpers
const SP=(o)=>Object.assign({stars:3,wf:3,strength:'',weak:''},o),pl=(r,d,o)=>c.feelPlan(r,d,0,{},SP(o)),on=(p,id)=>{const i=pick(p,id);return !!i&&i.alt!==null};
assert(!on(pl('def',10,{stars:1}),'cdr')&&on(pl('def',10,{stars:3}),'cdr'),'1-2 star defenders drop the R1 dribble helper');
assert(on(pl('def',10,{stars:1,weak:'drib'}),'cdr'),'a weak dribbling area keeps it');
assert(on(pl('mid',10,{wf:1}),'precision_pass')&&!on(pl('mid',10,{wf:5}),'precision_pass'),'weak foot decides precision pass');
assert(on(pl('mid',10,{wf:1}),'timed_pass')&&!on(pl('mid',10,{wf:3}),'timed_pass'),'weak foot adds fixed pass holds at low delay');
assert(pick(pl('att',10,{wf:1}),'shotmode').params.strength>pick(pl('att',10,{wf:5}),'shotmode').params.strength,'weaker foot = firmer shot aim');
assert(pick(pl('mid',10,{wf:1}),'through').params.strength>pick(pl('mid',10,{wf:5}),'through').params.strength,'weaker foot = firmer through-ball aim');
assert(pick(pl('mid',10,{stars:5}),'precision').params.strength>pick(pl('mid',10,{stars:1}),'precision').params.strength,'more skill stars = stronger close control');
assert(on(pl('def',10,{weak:'def'}),'auto_jockey')&&!on(pl('att',10,{weak:'def'}),'auto_jockey')&&!on(pl('def',10,{}),'auto_jockey'),'auto jockey only for a weak-defending non-attacker');
assert(pick(pl('def',10,{weak:'def'}),'jockey').params.strength>pick(pl('def',10,{strength:'def'}),'jockey').params.strength,'weak area up, strength down');
assert(!on(pl('mid',10,{strength:'pass'}),'cross')&&!on(pl('mid',10,{strength:'pass'}),'ctx_pass')&&on(pl('mid',10,{weak:'pass'}),'ctx_pass'),'passing strength is left lighter');
assert(on(pl('def',10,{}),'ctx_switch')&&!on(pl('mid',10,{}),'ctx_switch'),'switch response is a defender helper');
assert(on(pl('att',60,{}),'ctx_shoot')&&!on(pl('att',10,{}),'ctx_shoot'),'Shoot response keeps the aim once Timed shot replaces Shot response');
assert.equal(pl('mid',10,{strength:'x',weak:'x'}).spec.strength,'','unknown areas are ignored');
assert.equal(pl('mid',10,{strength:'drib',weak:'drib'}).spec.weak,'','strength and weak area cannot match');
// Skills filter: hides only moves above the rating, only when switched on
{let on=false;const st=new Map();ctx.localStorage.getItem=k=>st.has(k)?st.get(k):null;ctx.localStorage.setItem=(k,v)=>st.set(k,v);c.feel.api.setSkillFit(false);assert(c.feel.api.skillFits({stars:5}));c.feel.api.setSkillFit(true);assert(c.feel.api.skillFits({stars:3})&&!c.feel.api.skillFits({stars:4})&&c.feel.api.skillFits({stars:null}),'3-star player hides 4-5 star moves, keeps unrated')}
// every varied plan, fully applied, must pass the Lab's own validation
const vary=[];for(const r of Object.keys(c.ROLES))for(const d of [0,40,100])for(const o of [{},{stars:1,wf:1,weak:'pass'},{stars:5,wf:5,strength:'pass',weak:'def'},{wf:2,strength:'shoot',weak:'drib'},{strength:'drib',weak:'move'}])vary.push(c.feelPlan(r,d,5,{},SP(o)));
vary.forEach(p=>p.items.forEach(it=>Object.entries(it.params||{}).forEach(([k,v])=>{if(H[it.h]?.[k]){assert(v>=H[it.h][k].min&&v<=H[it.h][k].max,`${it.h}.${k}=${v} out of range`)}})));
const out2=vary.map(p=>{const q=JSON.parse(JSON.stringify(base));p.items.forEach(it=>{if(it.goal){const g=goals.get(it.goal);g.alts.forEach(x=>set(q,x.p,false));if(it.alt!==null)set(q,g.alts.find(x=>x.k===it.alt).p,true)}
  Object.entries(it.paths||{}).forEach(([k,v])=>set(q,k,v));Object.entries(it.params||{}).forEach(([k,v])=>set(q,'backbone_helpers.'+it.h+'.'+k,v))});return q});
execFileSync('python3',['-c','import json,sys;from pipeline import validate_profile as v\nfor q in json.load(sys.stdin):v(q)'],{input:JSON.stringify(out2)});
console.log('Feel tuner: limits, roles, delay, power and stick rules passed; applied plans validate');
