"""Pure calibrated/curved/remapped gamepad frames. No console integration."""
import copy
import math
from dataclasses import dataclass, asdict

AXES = {0:'LX',1:'LY',2:'L2',3:'RX',4:'RY',5:'R2',16:'DX',17:'DY'}
BUTTONS = {304:'Cross',305:'Circle',307:'Triangle',308:'Square',310:'L1',311:'R1',312:'L2 button',313:'R2 button',314:'Create',315:'Options',316:'PS',317:'L3',318:'R3'}
STICKS = ('LX','LY','RX','RY')

def default_profile(name='fc27'):
    from assists import defaults
    from advanced import defaults as advanced_defaults
    from play_tools import defaults as tools_defaults
    from helpers import defaults as helper_defaults
    from backbone.helper_contract import defaults as backbone_defaults
    from backbone.skills import defaults as skill_defaults
    return {'schema':2,'name':name,'description':'FC27 local training profile; automatic assists off by default. Not EA-certified settings.',
            'deadzone':.08,'centers':{},'ranges':{},'trigger_deadzone':.02,
            'curves':{k:{'kind':'linear','exponent':1.,'points':[[0,0],[.5,.5],[1,1]]} for k in ('left','right','triggers')},
            'button_map':{b:b for b in BUTTONS.values()},'axis_map':{a:a for a in STICKS},'invert':[],'arm_on_startup':False,'assists':defaults(),'advanced':advanced_defaults(),'play_tools':tools_defaults(),'helpers':helper_defaults(),'backbone_helpers':backbone_defaults(),'backbone_skills':skill_defaults(),'visual':{'theme':'dark','brightness':10,'screensaver':60,'border':'rounded','selection':'solid','progress':'solid','layout':'spaced','max_items':5}}

def number(x,lo,hi):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not lo<=x<=hi: raise ValueError(f'Expected a number between {lo} and {hi}')
    return x

def validate_profile(profile):
    if not isinstance(profile,dict) or type(profile.get('schema')) is not int or profile.get('schema') not in (1,2): raise ValueError('Unsupported profile schema')
    if set(profile)-set(default_profile()):raise ValueError('Unknown profile setting')
    p=default_profile(profile.get('name','default')); p.update(copy.deepcopy(profile)); p['schema']=2
    import re
    if not isinstance(p['name'],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',p['name']): raise ValueError('Invalid profile name')
    if not isinstance(p['description'],str) or len(p['description'])>500: raise ValueError('Invalid profile description')
    number(p['deadzone'],0,.5); number(p['trigger_deadzone'],0,.5)
    for kind in ('centers','ranges','button_map','axis_map','curves'):
        if not isinstance(p[kind],dict): raise ValueError(f'Invalid {kind}')
    for k,v in p['ranges'].items():
        if k not in AXES.values() or not isinstance(v,list) or len(v)!=2: raise ValueError('Invalid axis range')
        number(v[0],-32768,32767); number(v[1],-32768,32767)
        if v[1]<=v[0]: raise ValueError('Axis maximum must exceed minimum')
    for k,v in p['centers'].items():
        if k not in STICKS: raise ValueError('Invalid center axis')
        number(v,-32768,32767)
        if k in p['ranges'] and not p['ranges'][k][0]<v<p['ranges'][k][1]: raise ValueError('Center must be inside calibrated range')
    if set(p['curves'])!={'left','right','triggers'}: raise ValueError('Curves must cover left, right and triggers')
    for c in p['curves'].values():
        if not isinstance(c,dict) or c.get('kind') not in ('linear','power','smoothstep','custom'): raise ValueError('Invalid curve')
        number(c.get('exponent',1),.25,4)
        points=c.get('points',[[0,0],[1,1]])
        if not isinstance(points,list) or not 2<=len(points)<=16: raise ValueError('Custom curves require 2–16 points')
        for pt in points:
            if not isinstance(pt,list) or len(pt)!=2: raise ValueError('Curve point must be [input, output]')
            number(pt[0],0,1); number(pt[1],0,1)
        if points[0]!=[0,0] or points[-1]!=[1,1]: raise ValueError('Curve endpoints must be [0,0] and [1,1]')
        if any(a[0]>=b[0] or a[1]>b[1] for a,b in zip(points,points[1:])): raise ValueError('Curve must increase monotonically')
    if set(p['button_map'])!=set(BUTTONS.values()) or any(v not in (*BUTTONS.values(),'Disabled') for v in p['button_map'].values()): raise ValueError('Invalid button mapping')
    if set(p['axis_map'])!=set(STICKS) or set(p['axis_map'].values())!=set(STICKS): raise ValueError('Stick axis map must be a permutation')
    if not isinstance(p['invert'],list) or len(p['invert'])!=len(set(p['invert'])) or any(a not in STICKS for a in p['invert']): raise ValueError('Invalid inverted axes')
    from assists import validate
    p['assists']=validate(p['assists'])
    from advanced import validate as validate_advanced
    p['advanced']=validate_advanced(p['advanced'],p['assists'])
    from play_tools import validate as validate_tools
    p['play_tools']=validate_tools(p['play_tools'],p)
    from helpers import validate as validate_helpers
    p['helpers']=validate_helpers(p['helpers'])
    from backbone.helper_contract import validate_config
    from backbone.skills import validate_config as validate_skills
    p['backbone_helpers']=validate_config(p['backbone_helpers'])
    p['backbone_skills']=validate_skills(p['backbone_skills'])
    from backbone.skills import validate_bindings
    validate_bindings(p)
    if type(p['arm_on_startup']) is not bool: raise ValueError('Startup arming must be true/false')
    v=p['visual']
    if not isinstance(v,dict) or set(v)!={'theme','brightness','screensaver','border','selection','progress','layout','max_items'}: raise ValueError('Invalid visual settings')
    for key,allowed in {'theme':('dark','light'),'border':('none','simple','double','rounded'),'selection':('solid','outline','arrows','blink'),'progress':('segments','solid','dots','lines','gradient'),'layout':('compact','spaced','centered')}.items():
        if v[key] not in allowed: raise ValueError('Invalid visual option')
    number(v['brightness'],1,10); number(v['screensaver'],10,60); number(v['max_items'],2,5)
    import json
    if len(json.dumps(p,allow_nan=False).encode())>200000:raise ValueError('Profile exceeds 200000 bytes')
    return p

def normalize(value,lo,hi,center=None):
    if hi<=lo: return 0.
    if center is None: return max(0.,min(1.,(value-lo)/(hi-lo)))
    return max(-1.,min(1.,(value-center)/max(hi-center if value>=center else center-lo,1)))

def radial(x,y,dz):
    r=math.hypot(x,y)
    if r<=dz: return [0.,0.]
    scale=min(1.,(r-dz)/(1-dz))/r
    return [x*scale,y*scale]

def curve(x,c):
    x=max(0.,min(1.,x)); kind=c['kind']
    if kind=='power': return x**c.get('exponent',1)
    if kind=='smoothstep': return x*x*(3-2*x)
    if kind=='custom':
        for (a,b),(d,e) in zip(c['points'],c['points'][1:]):
            if x<=d: return b+(e-b)*(x-a)/(d-a)
        return 1.
    return x

def normalized(raw,bounds,p):
    out={}
    for n in AXES.values():
        default=0 if n not in STICKS else 127.5
        lo,hi=p['ranges'].get(n,bounds.get(n,[-1,1] if n in ('DX','DY') else [0,255]))
        center=p['centers'].get(n,(lo+hi)/2) if n in STICKS else None
        out[n]=max(-1,min(1,raw.get(n,0))) if n in ('DX','DY') else normalize(raw.get(n,default),lo,hi,center)
    return out

def transform(axes,buttons,p):
    shaped=dict(axes)
    for label,x,y in [('left','LX','LY'),('right','RX','RY')]:
        a,b=radial(axes.get(x,0),axes.get(y,0),p['deadzone']); r=math.hypot(a,b)
        factor=curve(r,p['curves'][label])/r if r else 0
        shaped[x]=a*factor; shaped[y]=b*factor
    for name in ('L2','R2'):
        dz=p['trigger_deadzone']; v=max(0,(axes.get(name,0)-dz)/(1-dz)); shaped[name]=curve(v,p['curves']['triggers'])
    result=dict(shaped)
    for src,dest in p['axis_map'].items(): result[dest]=-shaped[src] if dest in p['invert'] else shaped[src]
    mapped={b:False for b in BUTTONS.values()}
    for src,dest in p['button_map'].items():
        if dest!='Disabled': mapped[dest] |= bool(buttons.get(src,False))
    return result,mapped

@dataclass(frozen=True)
class ControllerFrame:
    t_ns: int
    axes: dict
    buttons: dict
    source: str='physical'
    sequence: int=0
    def to_dict(self): return {'kind':'frame',**asdict(self)}

def neutral_frame(t_ns=0,source='neutral',sequence=0):
    return ControllerFrame(t_ns,{a:0. for a in AXES.values()},{b:False for b in BUTTONS.values()},source,sequence)

def validate_frame(row):
    if not isinstance(row,dict) or row.get('kind')!='frame': raise ValueError('Invalid frame')
    t=row.get('t_ns'); seq=row.get('sequence',0)
    if type(t) is not int or not 0<=t<=600_000_000_000 or type(seq) is not int or seq<0: raise ValueError('Invalid frame time or sequence')
    axes=row.get('axes'); buttons=row.get('buttons')
    if not isinstance(axes,dict) or set(axes)!=set(AXES.values()): raise ValueError('Frame must contain all axes')
    for k,v in axes.items(): number(v,0 if k in ('L2','R2') else -1,1)
    if not isinstance(buttons,dict) or set(buttons)!=set(BUTTONS.values()) or any(type(v) is not bool for v in buttons.values()): raise ValueError('Frame must contain all button states')
    return ControllerFrame(t,dict(axes),dict(buttons),'replay',seq)
