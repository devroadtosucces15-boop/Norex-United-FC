"""Compile the on-screen button notation recorded from the FC27 skill menus into bounded local recipes.

Inputs are the printed notation only (ui/fc27-canonical.json). Timings are Lab-chosen; the menus show none.
Anything ambiguous (no stick direction printed, 'opposite direction', free-form arcs) is left uncompiled.
Directions are relative to the player's facing, matching the rest of the Lab (up = forward = negative Y).
"""
import json,math,re
from pathlib import Path

CANON=Path(__file__).with_name('ui')/'fc27-canonical.json'
STATUS='Menu-notation recipe; FC27 timings unverified'
SOURCE='FC27 skill-menu recordings (printed notation); Lab-chosen timings'
VEC={'↑':(0,-1),'↗':(.7071,-.7071),'→':(1,0),'↘':(.7071,.7071),'↓':(0,1),'↙':(-.7071,.7071),'←':(-1,0),'↖':(-.7071,-.7071)}
ARROWS=''.join(VEC)
MODS={'L1':'L1','R1':'R1'}
AXIS_MODS={'L2':'L2','R2':'R2'}

def step(ms,axes=None,buttons=None): return {'ms':ms,'axes':dict(axes or {}),'buttons':dict(buttons or {})}

def _angle(a): x,y=VEC[a]; return math.atan2(y,x)

def _arc(arrows,stick,hold_axes,btns):
    pts=[_angle(a) for a in arrows]; out=[]
    path=[pts[0]]
    for a,b in zip(pts,pts[1:]):
        d=(b-a+math.pi)%(2*math.pi)-math.pi
        n=max(1,round(abs(d)/math.radians(30)))
        path+= [a+d*i/n for i in range(1,n+1)]
    for ang in path: out.append(step(30,{**hold_axes,stick+'X':round(math.cos(ang),4),stick+'Y':round(math.sin(ang),4)},btns))
    return out

def _split_alternatives(text):
    text=text.replace('(Square or Circle)','SQCIR')
    return text.split(' or ')[0]

def compile_notation(notation):
    """Return (steps, notes) or (None, reason)."""
    text=_split_alternatives(notation.strip())
    notes=[]
    if ' or ' in notation.replace('(Square or Circle)',''): notes.append('first printed alternative used')
    if 'SQCIR' in text: notes.append('Square used for "Square or Circle"')
    if re.search(r'direction|opposite|two arcs|full-circle',text,re.I): return None,'direction not fully specified in the menu'
    phases=text.split(' then ')
    mods={}; mod_btns={}; steps=[]; used=set(); last_stick='R'; last_verb='flick'
    for pi,phase in enumerate(phases):
        items=[i.strip() for i in phase.split(' + ')]
        taps=[]; sticks=[]; held_sticks=[]
        for it in items:
            low=it.lower()
            m=re.fullmatch(r'(?:hold )?(L1|R1)',it,re.I)
            a=re.fullmatch(r'(?:hold )?(L2|R2)',it,re.I)
            t=re.fullmatch(r'tap (R1|L1)',it,re.I)
            if t: taps.append([t.group(1).upper()]); continue
            if m: mod_btns[m.group(1).upper()]=True; continue
            if a: mods[a.group(1).upper()]=1.; continue
            if it=='SQCIR': taps.append(['Square']); continue
            if it=='Cross': taps.append(['Cross']); continue
            r=re.fullmatch(r'R3(?: x(\d))?',it)
            if r: taps.append(['R3']*int(r.group(1) or 1)); continue
            s=re.fullmatch(r'(?:(hold|flick) )?(?:(LS|RS)\s*)?(arc )?([%s,\s]+)'%ARROWS,it,re.I)
            if s:
                verb,stick,arc,arrows=s.group(1),s.group(2),bool(s.group(3)),[c for c in s.group(4) if c in ARROWS]
                if not arrows: return None,'stick direction missing'
                stick=(stick or 'RS')[0].upper() if stick else last_stick
                verb=(verb or '').lower()
                sticks.append((verb,stick,arc,arrows)); continue
            if re.fullmatch(r'(?:hold )?(LS|RS)',it,re.I): return None,'stick direction missing'
            return None,'unrecognised notation: '+it
        if phase.strip() and not (taps or sticks) and not any(re.fullmatch(r'(?:hold )?(L1|R1|L2|R2)',i,re.I) for i in items):
            return None,'empty phase'
        if taps:
            # sticks beside button taps are held through the taps (e.g. Cross + hold LS ←)
            held={}
            for verb,stick,arc,arrows in sticks:
                if arc or len(arrows)!=1: return None,'stick pattern beside button taps'
                x,y=VEC[arrows[0]]; held.update({stick+'X':x,stick+'Y':y}); used.update({stick+'X',stick+'Y'}); last_stick=stick
            seq=[b for group in taps for b in group]
            for b in seq:
                steps.append(step(60,{**mods,**held},{**mod_btns,b:True})); steps.append(step(30,{**mods,**held},dict(mod_btns)))
            continue
        if not sticks:
            steps.append(step(100,dict(mods),dict(mod_btns))); continue
        for verb,stick,arc,arrows in sticks:
            if not verb: verb='arc' if arc else ('hold' if len(arrows)==1 and pi==0 and len(phases)==1 else last_verb if pi>0 and len(arrows)==1 else 'flick')
            if arc: verb='arc'
            last_stick=stick; last_verb=verb if verb!='arc' else last_verb
            used.update({stick+'X',stick+'Y'})
            if verb=='arc':
                steps+=_arc(arrows,stick,mods,mod_btns); steps.append(step(40,dict(mods),dict(mod_btns))); continue
            for a in arrows:
                x,y=VEC[a]
                if verb=='hold': steps.append(step(220,{**mods,stick+'X':x,stick+'Y':y},mod_btns))
                else: steps+= [step(80,{**mods,stick+'X':x,stick+'Y':y},mod_btns),step(40,dict(mods),dict(mod_btns))]
            if verb=='hold': steps.append(step(40,{**mods,stick+'X':0,stick+'Y':0},mod_btns))
    if not steps: return None,'nothing to play'
    last=steps[-1]
    if last['buttons'] or any(last['axes'].values()): steps.append(step(40,{k:0 for k in set(used)|set(mods)},{}))
    if len(steps)>128 or sum(s['ms'] for s in steps)>10000: return None,'too long'
    return steps,notes

def video_recipes():
    """name -> row for every complete skill in the recorded catalog that compiles."""
    try: data=json.loads(CANON.read_text())
    except Exception: return {},{}
    out={};skipped={}
    for r in data.get('records',[]):
        if r.get('kind')!='skill' or not r.get('complete'): continue
        steps,info=compile_notation(r['input_notation'])
        if steps is None: skipped[r['name']]=info; continue
        out[r['name']]={'name':r['name'],'relative':True,'status':STATUS,'source':SOURCE+(' ('+'; '.join(info)+')' if info else ''),'steps':steps}
    return out,skipped

def video_names():
    try: names=[r['name'] for r in json.loads(CANON.read_text()).get('records',[]) if r.get('kind')=='skill']
    except Exception: names=[]
    return names+[n for n in SUPPLEMENT if n not in names]


# --- cross-check against published PlayStation guides (fifplay, fifauteam, u7buy; checked 2026-10-13) ---
GUIDES=Path(__file__).with_name('ui')/'fc27-guides.json'
GUIDE_STATUS='Menu-notation recipe; FC27 timings unverified'
# Rows the recordings left incomplete (or that the menu never showed), resolved by agreement between guides.
# Directions are relative to the player facing up. Where the menu only says "direction", the Lab picks a default (noted).
SUPPLEMENT={
 'Roulette Right':('RS arc ↓ ← ↑ →','clockwise 270° from back; fifplay, fifauteam, thespike'),
 'Roulette Left':('RS arc ↓ → ↑ ←','counterclockwise 270° from back; fifplay, fifauteam, thespike'),
 'Spin Right':('Hold L2 + hold R1 + RS arc ↓ ← ↑ →','clockwise 270° from back; recording + fifplay give L2 + R1 (fifauteam lists R1 only)'),
 'Spin Left':('Hold L2 + hold R1 + RS arc ↓ → ↑ ←','counterclockwise 270° from back; recording + fifplay give L2 + R1'),
 'Hocus Pocus':('RS arc ↓ ← ↓ →','back to left, then through back to right; fifplay, driffle, thespike'),
 'Triple Elastico':('RS arc ↓ → ↓ ←','back to right, then through back to left; fifplay, driffle, thespike'),
 'Around the World':('Hold L2 + RS arc ↓ ← ↑ → ↓','full 360°, either direction (clockwise used); start point free'),
 'T. Around the World':('Hold L2 + RS arc ↓ ← ↑ → ↓ then flick RS ↑','clockwise 360° then flick up; thespike, driffle, playhub'),
 'Drag To Drag':('Hold L2 + (Square or Circle) + Cross then hold RS ↓','fake shot, then hold back; fifplay, thespike'),
 'Kneeling Header':('L2 + R2 + flick RS ↑','recording + driffle/realsport101/thespike; fifplay says R1 instead of R2. Trickster PlayStyle move'),
 'Stepover Combo':('Hold L2 + flick RS ↑ then flick RS ←','"direction" after forward = left or right; left used as default'),
 'Flair Roulette':('Hold L1 + RS arc ↓ ← ↑ →','guides give no start or direction; clockwise 270° from back used'),
 'Directional Nutmeg':('Hold L1 + R1 + flick RS ↑','menu says "direction"; forward used as default'),
 'Flair Nutmegs':('Hold L1 + R1 + flick RS ↑','menu says "direction"; forward used as default (fifplay says L2, recording + fifauteam say L1)'),
 'Fake Turn':('(Square or Circle) + Cross + LS ↓','LS opposite to the way you are moving = back'),
 'Standing Scoop Turn':('(Square or Circle) + Cross + LS ←','menu says "direction"; left used as default'),
 'Ball Roll Spin':('Hold L1 + RS ← then flick RS ↑','fifplay adds L1; menu says "direction" so left used as default'),
 'Running Fake Drag':('Hold L2 + (Square or Circle) + Cross + LS ↑','fifplay, fifauteam, u7buy (new 5★ in FC27)'),
 'Spin Flick Left':('Hold L2 + hold R1 + flick RS ↑ then ←','fifplay lists left or right; recording showed right'),
 'Spin Flick Right':('Hold L2 + hold R1 + flick RS ↑ then →','fifplay lists left or right; recording showed right'),
}

def supplement_recipes():
    out={};bad={}
    for name,(notation,why) in SUPPLEMENT.items():
        steps,info=compile_notation(notation)
        if steps is None: bad[name]=info; continue
        out[name]={'name':name,'relative':True,'status':GUIDE_STATUS,'source':'Cross-checked with PlayStation guides ('+why+'); Lab-chosen timings','steps':steps}
    return out,bad

def guide_names():
    try: return [m['name'] for m in json.loads(GUIDES.read_text())['moves']]
    except Exception: return []

def norm(n): return re.sub(r'[^a-z0-9]','',re.sub(r'\s+while\s+(standing|running|jogging)\b','',n.lower().replace('&','and')))
def fc27_keys():
    return {norm(n) for n in video_names()+guide_names()+list(SUPPLEMENT)}
