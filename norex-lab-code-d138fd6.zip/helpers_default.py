"""Helpers start OFF each time the controller is powered on.

Saved profiles keep their tuned helper values on disk; only the in-memory
copy is switched off. Every helper stays individually switchable in the UI,
and `restore_helpers: true` in data/lab-controls.json keeps the saved state.
"""
import copy
from assists import TOGGLES

def helpers_off(profile):
    p=copy.deepcopy(profile)
    for t in TOGGLES:p['assists'][t]=False
    a=p['advanced']
    for k in ('contexts','triggers'):
        for row in a[k].values():row['enabled']=False
    a['stick_deadzone']['enabled']=False;a['defense_only_jockey']=False;a['sprint_toggle']=False
    for row in p['backbone_helpers'].values():
        if isinstance(row,dict) and 'enabled' in row:row['enabled']=False
    for k in ('outer','shot_response'):p['play_tools'][k]['enabled']=False
    return p

def restore_requested(data):
    import json
    try:return json.loads((data/'lab-controls.json').read_text()).get('restore_helpers') is True
    except (OSError,ValueError):return False
