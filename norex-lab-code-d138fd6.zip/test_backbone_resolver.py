import unittest
from backbone.resolver import *
from backbone.api_contract import effective_payload
class ResolverTests(unittest.TestCase):
 def test_priority_and_determinism(self):
  a={'LX':.2};b={'Cross':False};r=ConflictResolver()
  intents=[Intent('helper','LX','SET_AXIS',30,.5),Intent('escape','LX','SET_AXIS',90,-.4)]
  x,y,c=r.resolve(a,b,intents);self.assertEqual(x['LX'],-.4);self.assertEqual(a['LX'],.2);self.assertEqual(c[-1]['winner'],'escape')
 def test_raw_compare(self):
  c=CompareState();self.assertEqual(c.mode,'NOREX');self.assertEqual(c.toggle(),'RAW');c.choose('RAW','better');self.assertEqual(c.results[-1]['winner'],'RAW')
 def test_output_truth(self):
  p=effective_payload('NOREX','fc27',{},True);self.assertEqual(p['output']['ps5_receipt'],'UNVERIFIED')
if __name__=='__main__':unittest.main()
