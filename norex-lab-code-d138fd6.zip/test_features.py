import json, math, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import pipeline as p
import recording
import virtual
import lab

class Features(unittest.TestCase):
 def test_curve_and_profile_validation(self):
  cfg=p.default_profile(); cfg['curves']['left']['kind']='power'; cfg['curves']['left']['exponent']=2
  p.validate_profile(cfg); axes=p.neutral_frame().axes; axes['LX']=.54
  a,b=p.transform(axes,{},cfg); self.assertAlmostEqual(a['LX'],.25)
  cfg['curves']['left']={'kind':'custom','points':[[0,0],[.5,.25],[1,1]]}
  self.assertAlmostEqual(p.curve(.75,cfg['curves']['left']),.625)
  cfg['curves']['left']['points']=[[0,0],[.5,.8],[.7,.3],[1,1]]
  with self.assertRaises(ValueError): p.validate_profile(cfg)
  cfg=p.default_profile(); cfg['axis_map']['LX']='LY'
  with self.assertRaises(ValueError): p.validate_profile(cfg)
 def test_remap_invert_and_trigger_deadzone(self):
  cfg=p.default_profile(); cfg['button_map']['Cross']='Circle'; cfg['button_map']['Triangle']='Circle'; cfg['button_map']['PS']='Disabled'; cfg['invert']=['LX']
  axes=p.neutral_frame().axes; axes['LX']=1; axes['L2']=.01
  a,b=p.transform(axes,{'Cross':True,'PS':True},cfg)
  self.assertEqual(a['LX'],-1); self.assertEqual(a['L2'],0); self.assertTrue(b['Circle']); self.assertFalse(b['Cross']); self.assertFalse(b['PS'])
 def test_schema1_migration(self):
  v=p.validate_profile({'schema':1,'name':'old','deadzone':.1,'centers':{},'ranges':{}})
  self.assertEqual(v['schema'],2); self.assertEqual(v['deadzone'],.1)
 def test_record_replay_neutral_and_timing(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'record.jsonl'
   with patch('recording.time.monotonic_ns',side_effect=[100,10_000_100,50_000_100]):
    rec=recording.FrameRecorder(path,p.default_profile(),{}); f=p.neutral_frame(); f.axes['LX']=1
    rec.frame(f); rec.finish()
   source=recording.ReplaySource(path)
   self.assertEqual(source.duration_ns,50_000_000); self.assertEqual(source.frames[1].axes['LX'],1); self.assertFalse(any(source.frames[-1].axes.values()))
   rows=path.read_text().splitlines(); path.write_text('\n'.join(rows[:-1])+'\n')
   with self.assertRaises(ValueError): recording.ReplaySource(path)
 def test_legacy_and_invalid_replay_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'bad.jsonl'; path.write_text('{"schema":1}\n')
   with self.assertRaises(ValueError): recording.ReplaySource(path)
  row=p.neutral_frame().to_dict(); row['axes']['LX']=float('nan')
  with self.assertRaises(ValueError): p.validate_frame(row)
 def test_uinput_packet_and_teardown(self):
  writes=[]; requests=[]
  def write(fd,data): writes.append(data); return len(data)
  with patch('command_center.Owner'),patch('virtual.os.open',return_value=42),patch('virtual.os.close') as close,patch('virtual.os.write',side_effect=write),patch('virtual.fcntl.ioctl',side_effect=lambda fd,req,*args: requests.append(req)):
   sink=virtual.UInputOutput(); f=p.neutral_frame(); f.axes['LX']=1; f.buttons['Cross']=True; sink.emit(f); sink.close()
   self.assertIn(0x5501,requests); self.assertIn(0x5502,requests); close.assert_called_once_with(42)
   ev=[virtual.EVENT.unpack(writes[1][i:i+virtual.EVENT.size]) for i in range(0,len(writes[1]),virtual.EVENT.size)]
   self.assertIn((0,0,3,0,32767),ev); self.assertIn((0,0,1,304,1),ev); self.assertEqual(ev[-1],(0,0,0,0,0))
   final=[virtual.EVENT.unpack(writes[-1][i:i+virtual.EVENT.size])[-1] for i in range(0,len(writes[-1]),virtual.EVENT.size)]
   self.assertFalse(any(final))
 def test_runtime_exclusion_and_stop(self):
  with tempfile.TemporaryDirectory() as d,patch.object(lab,'DATA',Path(tempfile.gettempdir())/'unused-controller-test'):
   with patch.object(lab,'DATA',Path(d)):
    l=lab.Lab(); l.status='Connected'; l.raw={'LX':255}; l.bounds={'LX':[0,255]}
    l.action({'action':'record_frames'}); l.feed(10,0,0,0,0)
    with self.assertRaises(ValueError): l.action({'action':'configure','profile':p.default_profile()})
    l.action({'action':'stop_frames'}); name=l.frame_record_name
    l.action({'action':'replay','name':name,'speed':1,'local_only':True})
    self.assertIsNotNone(l.replay)
    with self.assertRaises(ValueError): l.action({'action':'record_frames'})
    l.action({'action':'emergency_stop'}); self.assertIsNone(l.replay); self.assertFalse(any(l.replay_frame.buttons.values()))
 def test_disconnect_neutralizes_output(self):
  with tempfile.TemporaryDirectory() as d,patch.object(lab,'DATA',Path(d)):
   l=lab.Lab(); l.status='Connected'
   with patch('runtime.UInputOutput') as cls:
    l.action({'action':'output_start','local_only':True}); self.assertIsNotNone(l.output)
    l.disconnect_runtime('unplugged'); cls.return_value.close.assert_called_once(); self.assertIsNone(l.output)
if __name__=='__main__': unittest.main()
