import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import lab
from backbone.api_contract import catalog_payload,helpers_payload
class ApiContracts(unittest.TestCase):
 def test_catalog_and_helpers_are_json_safe(self):
  c=catalog_payload();h=helpers_payload();json.dumps(c);json.dumps(h)
  self.assertEqual(c['schema'],1);self.assertEqual(h['schema'],1)
  self.assertIn('skills',c);self.assertIn('helpers',h)
 def test_original_lab_profile_contract_still_valid(self):
  with tempfile.TemporaryDirectory() as d:
   with patch.object(lab,'DATA',Path(d)):
    l=lab.Lab();self.assertIn('helpers',l.profile);self.assertEqual(l.profile['schema'],2)
if __name__=='__main__':unittest.main()
