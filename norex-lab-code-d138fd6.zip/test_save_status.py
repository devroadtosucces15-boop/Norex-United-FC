import copy
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from lab import Lab
from backbone.save_status import save_status

def test_complete_saved_status_detects_edits_and_external_save():
    with TemporaryDirectory(dir=Path(__file__).parent/'work') as directory:
        with patch('lab.DATA',Path(directory)):r=Lab()
        assert save_status(r)['state']=='legacy'
        r.action({'action':'save','name':'status_test'})
        assert save_status(r)['state']=='saved'
        original=copy.deepcopy(r.profile)
        r.profile['backbone_helpers']['precision_stick']['strength']=33
        assert save_status(r)['state']=='modified'
        r.profile=original
        r.mode_bank.enabled=not r.mode_bank.enabled
        assert save_status(r)['state']=='modified'
        r.action({'action':'save','name':'status_test'})
        assert save_status(r)['state']=='saved'
        r.action({'action':'load','name':'status_test'})
        assert save_status(r)['state']=='saved'
