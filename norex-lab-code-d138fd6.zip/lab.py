#!/usr/bin/env python3
"""Local DualSense lab with explicit opt-in virtual output. Python standard library only."""
import argparse, collections, copy, csv, fcntl, glob, io, json, math, os, re, select, signal, statistics, struct, threading, time
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pipeline import default_profile, validate_profile
from runtime import Runtime

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
EVENT = struct.Struct('@llHHi')
AXES = {0:'LX',1:'LY',2:'L2',3:'RX',4:'RY',5:'R2',16:'DX',17:'DY'}
BUTTONS = {304:'Cross',305:'Circle',307:'Triangle',308:'Square',310:'L1',311:'R1',312:'L2 button',313:'R2 button',314:'Create',315:'Options',316:'PS',317:'L3',318:'R3'}

def ioctl_read(fd, nr, size):
    b = bytearray(size)
    fcntl.ioctl(fd, (2<<30)|(size<<16)|(ord('E')<<8)|nr, b, True)
    return b

def discover():
    devices=[]
    for p in sorted(glob.glob('/sys/class/input/event*')):
        d=Path(p)/'device'
        try:
            if (d/'id/vendor').read_text().strip()!='054c' or (d/'id/product').read_text().strip()!='0ce6': continue
            name=(d/'name').read_text().strip()
            bus=(d/'id/bustype').read_text().strip()
            devices.append({'path':'/dev/input/'+Path(p).name,'name':name,'main': name.endswith('Wireless Controller'),'bus':'usb' if bus=='0003' else 'bluetooth' if bus=='0005' else bus})
        except OSError: pass
    devices.sort(key=lambda x:(x.get('bus')!='usb',x['path']))  # wired first: Bluetooth adds noticeable delay
    return devices

def normalize(value, lo, hi, center=None):
    if hi<=lo: return 0.0
    if center is None: return max(0., min(1., (value-lo)/(hi-lo)))
    span=hi-center if value>=center else center-lo
    return max(-1.,min(1.,(value-center)/max(span,1)))

def radial(x,y,dz):
    r=math.hypot(x,y)
    if r<=dz: return [0.,0.]
    scale=min(1.,(r-dz)/(1-dz))/r
    return [x*scale,y*scale]

def percentile(values,q):
    if not values: return None
    a=sorted(values); return a[round((len(a)-1)*q)]

class Lab(Runtime):
    def __init__(self):
        self.data=DATA
        self.data.mkdir(exist_ok=True)
        self.lock=threading.RLock(); self.stop=threading.Event()
        self.devices=[]; self.device=None; self.status='Searching'; self.raw={}; self.bounds={}; self.buttons={}
        self.profile={'name':'default','deadzone':.08,'centers':{},'ranges':{},'schema':1}
        self.intervals=collections.deque(maxlen=4096); self.events=collections.deque(maxlen=200); self.last_frame=None
        self.count=0; self.frames=0; self.dropped=0; self.reconnects=0; self.last_seen=None
        self.cal=None; self.cal_result=None; self.record=None; self.record_name=None; self.record_bytes=0
        self.error=None; self.started=time.monotonic(); self.clock="kernel realtime"
        self.init_runtime(self.data)
        from section_controls import SECTIONS
        self.sections={s:True for s in SECTIONS};self.section_saved={};self.section_modes=None;self.suspended_settings=None
        self.require_remoteplay=False;self.remote_session=None
        self.command_center=False; self.master_enabled=False; self.revision=0; self.cleanup_errors=[]
        from command_center import OwnedSessions
        self.owned_sessions=OwnedSessions()
    def sync(self,fd):
        for code,name in AXES.items():
            try:
                v,lo,hi,fuzz,flat,res=struct.unpack('6i',ioctl_read(fd,0x40+code,24))
                self.raw[name]=v; self.bounds[name]=[lo,hi]
            except OSError: pass
        keys=ioctl_read(fd,0x18,96)
        self.buttons={name:bool(keys[c//8] & (1<<(c%8))) for c,name in BUTTONS.items()}
    def values(self):
        vals={}
        for name,v in self.raw.items():
            lo,hi=self.profile['ranges'].get(name,self.bounds.get(name,[0,255]))
            center=self.profile['centers'].get(name,(lo+hi)/2) if name in ('LX','LY','RX','RY') else None
            vals[name]=normalize(v,lo,hi,center) if name not in ('DX','DY') else v
        return vals
    def feed(self,sec,usec,typ,code,value,fd=None):
        ts=sec+usec/1e6
        if typ==0 and code==3:
            self.dropped+=1; self.error='Input queue overrun; resynchronizing'; self._dropping=True; self.last_frame=None; self.resync_input(); return
        if getattr(self,'_dropping',False):
            if typ==0 and code==0:
                if fd is not None: self.sync(fd)
                self._dropping=False;self.error=None
                if self.command_center and self.master_enabled:self.arm_current()
                self.on_frame()
            return
        self.count+=1; self.last_seen=time.monotonic()
        event={'timestamp':ts,'type':typ,'code':code,'value':value}
        self.events.append(event)
        if self.record:
            line=json.dumps(event)+'\n'; self.record.write(line); self.record_bytes+=len(line)
            if self.record_bytes>=20*1024*1024: self.end_record(); self.error='Recording stopped at 20 MiB limit'
        if typ==3 and code in AXES: self.raw[AXES[code]]=value
        if typ==1 and code in BUTTONS: self.buttons[BUTTONS[code]]=bool(value)
        if typ==0 and code==0:
            self.frames+=1
            if self.last_frame is not None and ts>self.last_frame: self.intervals.append((ts-self.last_frame)*1000)
            self.last_frame=ts
            self.on_frame()
    def tick_cal(self):
        if not self.cal: return
        self.cal['samples'].append(dict(self.raw))
        if time.monotonic()<self.cal['until']: return
        samples=self.cal['samples']; mode=self.cal['mode']; result={'mode':mode,'samples':len(samples),'axes':{}}
        for name in ('LX','LY','RX','RY','L2','R2'):
            a=[s[name] for s in samples if name in s]
            if not a: continue
            result['axes'][name]={'mean':statistics.mean(a),'min':min(a),'max':max(a),'stddev':statistics.pstdev(a)}
            if mode=='center' and name in ('LX','LY','RX','RY'): self.profile['centers'][name]=statistics.mean(a)
            if mode=='range' and max(a)-min(a)>=.5*(self.bounds.get(name,[0,255])[1]-self.bounds.get(name,[0,255])[0]):
                self.profile['ranges'][name]=[min(a),max(a)]
                if name in self.profile['centers'] and not min(a)<self.profile['centers'][name]<max(a): self.profile['centers'].pop(name)
        if mode=='center':
            radii=[]
            for s in samples:
                for x,y in [('LX','LY'),('RX','RY')]:
                    if x in s and y in s:
                        bx=self.bounds[x]; by=self.bounds[y]
                        radii.append(math.hypot(normalize(s[x],*bx,(bx[0]+bx[1])/2),normalize(s[y],*by,(by[0]+by[1])/2)))
            result['uncorrected_rest_radius_p99']=percentile(radii,.99)
            result['suggested_deadzone']=min(.5,(result['uncorrected_rest_radius_p99'] or 0)+.02)
        self.cal_result=result; self.cal=None
        if self.command_center and self.master_enabled:self.arm_current()
        self.on_frame()
    def run(self):
        while not self.stop.is_set():
            fd=None
            try:
                if self.command_center and not self.master_enabled:
                    self.devices=discover()
                    with self.lock:
                        self.device=next((d for d in self.devices if d['main']),None); self.status='Connected' if self.device else 'Disconnected'
                    self.stop.wait(.2); continue
                self.devices=discover(); main=next((d for d in self.devices if d['main']),None)
                if not main:
                    with self.lock:
                        self.status='Disconnected'; self.raw={}; self.buttons={}; self.device=None; self.disconnect_runtime('Controller disconnected')
                    self.stop.wait(1); continue
                fd=os.open(main['path'],os.O_RDONLY|os.O_NONBLOCK)
                with self.lock:
                    self.device=main; self.raw={}; self.bounds={}
                    try:
                        fcntl.ioctl(fd,0x400445a0,struct.pack('i',1)); self.clock='kernel monotonic'
                    except OSError: self.clock='kernel realtime'
                    self.sync(fd); self.status='Connected'; self.error=None; self.first_connection()
                    self.last_frame=None; self.intervals.clear(); self.reconnects+=1; self._dropping=False; self.on_frame()
                buf=b''; next_tick=0; next_probe=time.monotonic()+1
                while not self.stop.is_set():
                    if self.command_center and not self.master_enabled:break
                    ready,_,_=select.select([fd],[],[],max(0,min(.02,next_tick-time.monotonic())))
                    if ready:
                        chunk=os.read(fd,EVENT.size*64)
                        if not chunk: raise OSError('Controller disconnected')
                        buf+=chunk
                        with self.lock:
                            while len(buf)>=EVENT.size:
                                self.feed(*EVENT.unpack(buf[:EVENT.size]),fd=fd); buf=buf[EVENT.size:]
                    if time.monotonic()>=next_tick:
                        with self.lock: self.tick_cal()
                        next_tick=time.monotonic()+.02
                    if time.monotonic()>=next_probe:
                        ioctl_read(fd,0x02,8); next_probe=time.monotonic()+1
            except OSError as e:
                with self.lock:
                    self.status='Disconnected or permission denied'; self.error=str(e); self.cal=None; self.raw={}; self.buttons={}; self.end_record(); self.device=None; self.disconnect_runtime(str(e))
                self.stop.wait(1)
            finally:
                if fd is not None: os.close(fd)
    def end_record(self):
        if self.record: self.record.flush(); self.record.close()
        self.record=None
    def snapshot(self):
        with self.lock:
            vals=self.values(); filtered={}
            for label,x,y in [('left','LX','LY'),('right','RX','RY')]: filtered[label]=radial(vals.get(x,0),vals.get(y,0),self.profile['deadzone'])
            ints=list(self.intervals); mean=statistics.mean(ints) if ints else None
            return copy.deepcopy({**self.runtime_state(),'master_enabled':self.master_enabled,'sections':self.sections,'chiaki_running':bool(self.remote_session and self.remote_session.poll() is None),'revision':self.revision,'cleanup_errors':self.cleanup_errors,'profile_result':copy.deepcopy(self.profile_result),'status':self.status,'error':self.error,'device':self.device,'devices':self.devices,'raw':self.raw.copy(),'bounds':self.bounds.copy(),'normalized':vals,'filtered':filtered,'buttons':self.buttons.copy(),'profile':self.profile,'metrics':{'clock':self.clock,'events':self.count,'frames':self.frames,'dropped':self.dropped,'connections':self.reconnects,'window_intervals':len(ints),'mean_ms':mean,'p50_ms':percentile(ints,.5),'p95_ms':percentile(ints,.95),'p99_ms':percentile(ints,.99),'jitter_ms':statistics.pstdev(ints) if ints else None,'observed_frame_hz':1000/mean if mean else None,'last_event_age_s':time.monotonic()-self.last_seen if self.last_seen else None},'calibration':{'mode':self.cal['mode'],'remaining_s':max(0,self.cal['until']-time.monotonic())} if self.cal else None,'calibration_result':self.cal_result,'recording':self.record_name if self.record else None,'record_bytes':self.record_bytes,'profiles':sorted([p.stem for p in self.data.glob('profile-*.json')],key=lambda x:(x!='profile-fc27',x)),'logs':[p.name for p in self.data.glob('capture-*.jsonl')],'recent_events':list(self.events)})
    def action(self,b):
        with self.lock:
            managed=self.command_center and self.master_enabled and b.get('action') in ('skill_save','skill_from_capture','skill_mapping_set','load','calibrate','deadzone')
            if managed:
                self.assists_armed=False;self.assist_engine.reset();self.advanced_engine.reset();self.play_tools.reset()
            try:return self._action(b)
            finally:
                if managed and self.master_enabled and not self.cal:self.arm_current();self.on_frame()
    def _action(self,b):
        with self.lock:
            action=b.get('action')
            from section_controls import check_action
            check_action(self,action)
            if self.command_center:
                from command_center import power
                if action in ('master_power','custom_power','output_start','output_stop','emergency_stop'):
                    enabled=b.get('enabled') if action in ('master_power','custom_power') else action=='output_start'
                    power(self,enabled); self.revision+=1; return self.snapshot()
                if not self.master_enabled and action in ('arm_assists','delivery_test_start','replay','remoteplay_connect','skill_run'):
                    raise ValueError('Turn virtual controller ON first')
                if action=='remoteplay_connect':
                    power(self,True);return self.snapshot()
                if action=='section_power':
                    from section_controls import toggle
                    toggle(self,b.get('section'),b.get('enabled'));return self.snapshot()
                if not self.master_enabled and action not in ('skill_get',):raise ValueError('Turn Custom + Chiaki ON before changing settings')
                if action=='arm_assists':
                    self.arm_current();self.on_frame();return self.snapshot()
                if action=='disarm_assists':
                    power(self,False);return self.snapshot()
                self.revision+=1
            runtime_result=self.runtime_action(b)
            if isinstance(runtime_result,dict): return runtime_result
            if runtime_result: return self.snapshot()
            if action in ('calibrate','deadzone','load') and (self.frame_rec or self.replay or (self.assists_armed and action!='load')): raise ValueError('Disarm assists and stop frame recording/replay before changing profiles or calibrating')
            if action=='calibrate':
                if self.status!='Connected': raise ValueError('Connect controller first')
                mode=b.get('mode','center')
                if mode not in ('center','range'): raise ValueError('Invalid calibration mode')
                self.cal={'mode':mode,'until':time.monotonic()+10,'samples':[]}
            elif action=='deadzone':
                dz=float(b['value'])
                if not math.isfinite(dz) or not 0<=dz<=.5: raise ValueError('Deadzone must be 0–0.5')
                self.profile['deadzone']=dz; self.on_frame()
            elif action in ('save','load'):
                name=b.get('name','default')
                if not isinstance(name,str) or not re.fullmatch('[A-Za-z0-9_-]{1,40}',name): raise ValueError('Use 1–40 letters, numbers, underscores or hyphens')
                path=self.data/('profile-'+name+'.json')
                from profile_store import prepare_save,validate_snapshot,write_atomic,restore,commit_save
                if action=='save':
                    if self.frame_rec or self.replay: raise ValueError('Stop frame recording/replay before saving edited settings')
                    document,validated=prepare_save(self,b.get('profile',self.profile),name)
                    warning=commit_save(self.data,path,document)
                    was_armed=self.assists_armed
                    restore(self,validated)
                    if was_armed:self.arm_current()
                    self.on_frame()
                    self.profile_result={'operation':'saved','name':name,'saved_at':document['saved_at'],'snapshot_schema':document['snapshot_schema'],'startup_recovery_pending':warning is not None,'warning':warning}
                else:
                    document=json.loads(path.read_text());validated=validate_snapshot(document,self.mode_bank,previous=self.profile)
                    # Persist the selection before changing live state. Legacy
                    # documents become a complete migration snapshot on load.
                    if 'snapshot_schema' not in document:
                        from profile_store import snapshot
                        document=snapshot(self,validated[0]);document['selection']={'active_mode':'None','base_profile':copy.deepcopy(validated[0])}
                        validated=validate_snapshot(document,self.mode_bank,previous=self.profile)
                    else:
                        from profile_store import migrate
                        document=migrate(document)
                    write_atomic(self.data/'startup-profile.json',document)
                    restore(self,validated)
                    self.profile_result={'operation':'loaded','name':name,'saved_at':document.get('saved_at'),'snapshot_schema':2 if 'snapshot_schema' in json.loads(path.read_text()) else 0}
                    self.on_frame()
            elif action=='record':
                if self.status!='Connected': raise ValueError('Connect controller first')
                if self.record: raise ValueError('Already recording')
                if sum(p.stat().st_size for p in self.data.glob('capture-*'))>200*1024*1024: raise ValueError('200 MiB archive limit reached; archive old logs')
                self.record_name='capture-'+time.strftime('%Y%m%d-%H%M%S')+'-'+str(time.time_ns()%1000000)+'.jsonl'
                self.record=(self.data/self.record_name).open('x'); self.record_bytes=0
                self.record.write(json.dumps({'schema':1,'device':self.device,'profile':self.profile,'initial_raw':self.raw,'initial_buttons':self.buttons,'bounds':self.bounds,'clock':self.clock})+'\n')
            elif action=='stop': self.end_record()
            elif action=='reset': self.intervals.clear(); self.count=0; self.frames=0; self.last_frame=None
            else: raise ValueError('Unknown action')
        return self.snapshot()

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def reply(self,data,status=200,kind='application/json'):
        if not isinstance(data,bytes): data=json.dumps(data,allow_nan=False).encode()
        self.send_response(status); self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
    def allowed(self):
        host=self.headers.get('Host','')
        return host in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}') and self.headers.get('Origin',f'http://{host}')==f'http://{host}'
    def do_GET(self):
        if not self.allowed():
            if self.path.startswith('/api/v2/'):
                from backbone.api_contract import envelope
                return self.reply(envelope(ok=False,error={'code':'LOCAL_ORIGIN_REQUIRED','message':'Local origin required'}),403)
            return self.reply({'error':'Local origin required'},403)
        from network_integration import serve
        if hasattr(self.server,'network') and serve(self):return
        pages={'/':'home.html','/lab':'console.html','/help':'help.html'}
        if self.path in pages:
            return self.reply((ROOT/pages[self.path]).read_bytes(),kind='text/html; charset=utf-8')
        if self.path=='/legacy':
            return self.reply(b'<!doctype html><meta http-equiv="refresh" content="0; url=/lab"><title>NOREX Controller Lab</title><a href="/lab">Continue to Controller Lab</a>',kind='text/html; charset=utf-8')
        assets={**{'/ui/'+p.name:('ui/'+p.name,'application/json' if p.suffix=='.json' else 'image/jpeg' if p.suffix=='.jpg' else 'text/css' if p.suffix=='.css' else 'text/javascript; charset=utf-8') for p in (Path(__file__).parent/'ui').glob('fc27-*')},'/ui/live-controllers.js':('ui/live-controllers.js','text/javascript; charset=utf-8'),'/ui/plain.js':('ui/plain.js','text/javascript; charset=utf-8'),'/ui/inter.ttf':('ui/inter.ttf','font/ttf'),'/ui/oswald.ttf':('ui/oswald.ttf','font/ttf'),'/ui/norex-crest.png':('ui/norex-crest.png','image/png'),'/ui/app.js':('ui/app.js','text/javascript; charset=utf-8'),'/ui/skill-tools.js':('ui/skill-tools.js','text/javascript; charset=utf-8'),'/ui/skill-tools.css':('ui/skill-tools.css','text/css; charset=utf-8'),'/ui/cockpit.js':('ui/cockpit.js','text/javascript; charset=utf-8'),'/ui/cockpit.css':('ui/cockpit.css','text/css; charset=utf-8'),'/ui/style.css':('ui/style.css','text/css; charset=utf-8')}
        if self.path in assets:
            filename,kind=assets[self.path]
            return self.reply((ROOT/filename).read_bytes(),kind=kind)
        if self.path=='/api/telemetry':
            from live_telemetry import telemetry
            with self.server.lab.lock:return self.reply(telemetry(self.server.lab))
        if self.path=='/api/state': return self.reply(self.server.lab.snapshot())
        if self.path=='/api/center':
            from backbone.api_contract import runtime_effective_payload
            with self.server.lab.lock:
                r=self.server.lab
                return self.reply({'state':r.snapshot(),'effective':runtime_effective_payload(r),'profiles':{'profiles':sorted(p.stem.removeprefix('profile-') for p in r.data.glob('profile-*.json'))},'skill_preferences':__import__('skill_preferences').read(r.data),'skill_lists':{'lists':__import__('skill_lists').snapshot()},'skill_notes':__import__('skill_notes').read(r.data),'game_presets':__import__('game_presets').read(r.data)})
        if self.path.startswith('/api/v2/'):
            return self.v2_get()
        if self.path=='/api/inputlog':
            with self.server.lab.lock:
                path=self.server.lab.audit.path; content=path.read_bytes() if path.exists() else b''
            return self.reply(content,kind='application/x-ndjson')
        if self.path=='/api/export': return self.reply(self.server.lab.snapshot(),kind='application/json')
        if self.path.startswith(('/api/log/','/api/csv/')):
            name=self.path.split('/',3)[-1]
            if not re.fullmatch(r'capture-[0-9-]+\.jsonl',name): return self.reply({'error':'Invalid log'},400)
            p=self.server.lab.data/name
            if not p.exists(): return self.reply({'error':'Missing log'},404)
            with self.server.lab.lock:
                if self.server.lab.record: self.server.lab.record.flush()
                if self.server.lab.frame_rec: self.server.lab.frame_rec.file.flush()
                content=p.read_bytes()
            if self.path.startswith('/api/csv/'):
                rows=[json.loads(line) for line in content.decode().splitlines()]
                out=io.StringIO(); writer=csv.writer(out)
                if rows and rows[0].get('schema')==2:
                    writer.writerow(['t_ns','sequence',*AXES.values(),*BUTTONS.values()])
                    for row in rows[1:]:
                        if row.get('kind')=='frame': writer.writerow([row['t_ns'],row['sequence'],*[row['axes'][a] for a in AXES.values()],*[int(row['buttons'][b]) for b in BUTTONS.values()]])
                else:
                    writer.writerow(['timestamp','type','code','value'])
                    for row in rows[1:]: writer.writerow([row.get(k,'') for k in ('timestamp','type','code','value')])
                return self.reply(out.getvalue().encode(),kind='text/csv; charset=utf-8')
            return self.reply(content,kind='application/x-ndjson')
        return self.reply({'error':'Not found'},404)
    def v2_get(self):
        from urllib.parse import urlsplit,parse_qs
        from backbone.api_contract import catalog_payload,helpers_payload,runtime_effective_payload,contracts_payload,envelope
        path=urlsplit(self.path).path;query=parse_qs(urlsplit(self.path).query,keep_blank_values=True)
        try:
            with self.server.lab.lock:
                r=self.server.lab
                if path=='/api/v2/fc27':data=catalog_payload()
                elif path=='/api/v2/helpers':data=helpers_payload()
                elif path=='/api/v2/effective':data=runtime_effective_payload(r)
                elif path=='/api/v2/contracts':data=contracts_payload()
                elif path=='/api/v2/comparison':data=envelope(comparison=r.compare_state.status())
                elif path=='/api/v2/profiles':
                    data=envelope(profiles=sorted(p.stem.removeprefix('profile-') for p in r.data.glob('profile-*.json')),last_operation=r.profile_result)
                elif path=='/api/v2/skills':
                    if set(query)-{'q','stars','status','kind','ready'} or any(len(v)!=1 for v in query.values()):raise ValueError('Unknown or repeated skill filter')
                    from backbone.skills import catalog_rows
                    one=lambda k:query.get(k,[None])[0]
                    rows=catalog_rows(r.profile['backbone_skills'],query=one('q') or '',stars=int(one('stars')) if one('stars') is not None else None,status=one('status'),kind=one('kind'))
                    ready=one('ready')
                    if ready not in (None,'true','false'):raise ValueError('ready must be true or false')
                    if ready is not None:rows=[row for row in rows if row['executable']==(ready=='true')]
                    data=envelope(skills=rows,count=len(rows))
                else:return self.reply(envelope(ok=False,error={'code':'NOT_FOUND','message':'Not found'}),404)
                if query and path!='/api/v2/skills':raise ValueError('This route does not accept query parameters')
            return self.reply(data)
        except (ValueError,TypeError,KeyError) as e:
            return self.reply(envelope(ok=False,error={'code':'INVALID_REQUEST','message':str(e)}),400)
    def do_POST(self):
        from network_integration import post
        if hasattr(self.server,"network") and post(self):return
        if not self.allowed():
            if self.path.startswith('/api/v2/'):
                from backbone.api_contract import envelope
                return self.reply(envelope(ok=False,error={'code':'LOCAL_ORIGIN_REQUIRED','message':'Local origin required'}),403)
            return self.reply({'error':'Local origin required'},403)
        if self.path=='/api/skill-favorites':
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=4096:raise ValueError('Invalid request length')
                b=json.loads(self.rfile.read(size))
                if not isinstance(b,dict) or set(b)!={'key','favorite'}:raise ValueError('Invalid favorite fields')
                from skill_preferences import update
                with self.server.lab.lock:result=update(self.server.lab.data,b['key'],b['favorite'])
                return self.reply(result)
            except (ValueError,TypeError,KeyError,OSError) as error:
                return self.reply({'error':str(error)},400)
        if self.path=='/api/game-presets':
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=32768:raise ValueError('Invalid request length')
                b=json.loads(self.rfile.read(size))
                if not isinstance(b,dict) or b.get('action') not in ('save','delete') or set(b)-{'action','game','variant','values'}:raise ValueError('Invalid preset request')
                import game_presets
                with self.server.lab.lock:
                    result=game_presets.save(self.server.lab.data,b.get('game'),b.get('variant'),b.get('values')) if b['action']=='save' else game_presets.delete(self.server.lab.data,b.get('game'),b.get('variant'))
                return self.reply(result)
            except (ValueError,TypeError,KeyError,OSError) as error:
                return self.reply({'error':str(error)},400)
        if self.path=='/api/skill-notes':
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=2048:raise ValueError('Invalid request length')
                b=json.loads(self.rfile.read(size))
                if not isinstance(b,dict) or set(b)-{'name','status','note'} or 'name' not in b:raise ValueError('Invalid note request')
                import skill_notes
                with self.server.lab.lock:result=skill_notes.save(self.server.lab.data,b['name'],b.get('status'),b.get('note',''))
                return self.reply(result)
            except (ValueError,TypeError,KeyError,OSError) as error:
                return self.reply({'error':str(error)},400)
        if self.path=='/api/skill-lists':
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=16384:raise ValueError('Invalid request length')
                b=json.loads(self.rfile.read(size))
                if not isinstance(b,dict) or b.get('action') not in ('save','delete'):raise ValueError('Invalid list request')
                import skill_lists
                with self.server.lab.lock:
                    if b['action']=='save':result=skill_lists.save(self.server.lab.data,b.get('name'),b.get('members'),b.get('mode'),b.get('old_name'))
                    else:result=skill_lists.delete(self.server.lab.data,b.get('name'))
                return self.reply(result)
            except (ValueError,TypeError,KeyError,OSError) as error:
                return self.reply({'error':str(error)},400)
        v2=self.path=='/api/v2/action'
        if self.path not in ('/api/action','/api/v2/action'):
            if self.path.startswith('/api/v2/'):
                from backbone.api_contract import envelope
                return self.reply(envelope(ok=False,error={'code':'NOT_FOUND','message':'Not found'}),404)
            return self.reply({'error':'Not found'},404)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=262144: raise ValueError('Invalid request length')
            b=json.loads(self.rfile.read(size))
            if not isinstance(b,dict): raise ValueError('Action must be a JSON object')
            with self.server.lab.lock:
                expected=b.pop('expected_revision',None)
                if expected is not None and expected!=self.server.lab.revision:raise ValueError('Settings changed in another tab. Refresh and apply again.')
                if v2:
                    from backbone.actions import act
                    data=act(self.server.lab,b); self.server.lab.revision+=1
                else:data=self.server.lab.action(b)
            with self.server.lab.lock:
                if self.server.lab.command_center and self.server.lab.master_enabled:
                    from command_center import save_setup
                    save_setup(self.server.lab)
            self.reply(data)
        except (ValueError,KeyError,TypeError,OSError) as e:
            if v2:
                from backbone.api_contract import envelope
                code='NOT_FOUND' if isinstance(e,FileNotFoundError) else 'IO_ERROR' if isinstance(e,OSError) else 'INVALID_REQUEST'
                status=404 if code=='NOT_FOUND' else 500 if code=='IO_ERROR' else 400
                self.reply(envelope(ok=False,error={'code':code,'message':str(e)}),status)
            else:self.reply({'error':str(e)},400)

if __name__=='__main__':
    if os.environ.get('NOREX_CENTER_OWNED')!='1':
        import subprocess
        subprocess.run([str(ROOT/'labs'),'start'],check=True)
        raise SystemExit(0)
    ap=argparse.ArgumentParser(); ap.add_argument('--port',type=int,default=8790); args=ap.parse_args()
    from command_center import Owner, power
    owner=Owner()
    lab=Lab(); lab.command_center=True; lab.require_remoteplay=True; power(lab,False)
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler); server.lab=lab
    # Network work belongs to its separate managed service.
    worker=threading.Thread(target=lab.run,daemon=True); worker.start()
    replay_worker=threading.Thread(target=lab.run_replay,daemon=True); replay_worker.start()
    def terminate(signum,frame): raise KeyboardInterrupt
    signal.signal(signal.SIGTERM,terminate)
    print(f'NOREX Controller Lab: http://127.0.0.1:{args.port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        lab.stop.set(); worker.join(timeout=2); replay_worker.join(timeout=2)
        with lab.lock: lab.end_record(); lab.finish_frames('shutdown'); lab.stop_replay(); lab.close_output()
        power(lab,False)
        if hasattr(server,'network'):server.network.close()
        server.server_close(); owner.close()
